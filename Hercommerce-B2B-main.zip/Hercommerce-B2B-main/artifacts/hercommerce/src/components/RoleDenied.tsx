import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { ShieldOff } from "lucide-react";

// Four screens rendered a single unstyled sentence with no heading, no icon and
// no way onward, which read as a broken page rather than a deliberate answer.
// The 404 next door is fully designed; being told "not for you" deserves the
// same treatment, and above all an exit.
export function RoleDenied({ message, hint }: { message: string; hint?: string }) {
  return (
    <Layout>
      <div className="max-w-md mx-auto text-center py-16 space-y-4">
        <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-muted">
          <ShieldOff className="h-6 w-6 text-muted-foreground" />
        </div>
        <h1 className="text-xl font-semibold">{message}</h1>
        <p className="text-sm text-muted-foreground">
          {hint ?? "Your account doesn't have access to this area."}
        </p>
        <div className="flex flex-wrap justify-center gap-2 pt-2">
          <Button asChild><Link href="/dashboard">Go to dashboard</Link></Button>
          <Button asChild variant="outline"><Link href="/sellers">Browse exporters</Link></Button>
        </div>
      </div>
    </Layout>
  );
}
