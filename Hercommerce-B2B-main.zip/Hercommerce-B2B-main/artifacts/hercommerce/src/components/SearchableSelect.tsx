import { useState } from "react";
import { ALL_COUNTRIES } from "@workspace/vocab";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Check, ChevronsUpDown, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface Props {
  id?: string;
  options: readonly string[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  /** Offers a clear control. Leave off for required fields. */
  clearable?: boolean;
  "aria-invalid"?: boolean;
}

// A single-select you can type into. A plain <Select> over a couple of hundred
// options means scrolling a list on a phone; a free-text <Input> meant typos
// that silently never matched (one buyer's country was stored as "Thaiti").
// This keeps the constraint of the first and the speed of the second.
export function SearchableSelect({
  id,
  options,
  value,
  onChange,
  placeholder = "Select…",
  searchPlaceholder = "Search…",
  clearable = false,
  "aria-invalid": ariaInvalid,
}: Props) {
  const [open, setOpen] = useState(false);

  // A value stored before this field was constrained may not be in the list.
  // Show it, flagged, rather than rendering an empty trigger that makes the
  // user think nothing was saved; the server will refuse it until replaced.
  const unrecognised = value !== "" && !options.includes(value);

  return (
    <div className="space-y-1">
      <Popover open={open} onOpenChange={setOpen}>
        {/* The clear control is a sibling of the trigger, not a child: an
            interactive element inside a <button> is invalid HTML, and screen
            readers announce the pair as one control. */}
        <div className="relative">
          <PopoverTrigger asChild>
            <button
              id={id}
              type="button"
              role="combobox"
              aria-expanded={open}
              aria-invalid={ariaInvalid || unrecognised || undefined}
              className={cn(
                // h-11: a 44px target, matching the tap-target rule used elsewhere.
                "flex h-11 w-full items-center justify-between gap-2 rounded-md border bg-background pl-3 text-left text-sm",
                clearable && value ? "pr-16" : "pr-3",
                "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2",
                unrecognised || ariaInvalid ? "border-amber-500" : "border-input",
              )}
            >
              <span className={cn("truncate", !value && "text-muted-foreground")}>
                {value || placeholder}
              </span>
              <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" />
            </button>
          </PopoverTrigger>
          {clearable && value && (
            <button
              type="button"
              aria-label="Clear selection"
              onClick={() => onChange("")}
              className="absolute right-8 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <PopoverContent className="w-(--radix-popover-trigger-width) p-0" align="start">
          <Command>
            <CommandInput placeholder={searchPlaceholder} />
            <CommandList>
              <CommandEmpty>No match.</CommandEmpty>
              <CommandGroup>
                {options.map((option) => (
                  <CommandItem
                    key={option}
                    value={option}
                    // Close over `option` rather than using onSelect's argument:
                    // cmdk has changed whether that argument is normalised
                    // between versions, and a lowercased "united kingdom" would
                    // fail validation against the vocabulary.
                    onSelect={() => {
                      onChange(option);
                      setOpen(false);
                    }}
                  >
                    <Check className={cn("mr-2 h-4 w-4", value === option ? "opacity-100" : "opacity-0")} />
                    {option}
                  </CommandItem>
                ))}
              </CommandGroup>
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {unrecognised && (
        <p className="text-xs text-amber-700 dark:text-amber-500">
          "{value}" isn't a recognised option. Choose one from the list.
        </p>
      )}
    </div>
  );
}

/** Every country a company can be based in or ship to. */
export function CountrySelect(props: Omit<Props, "options" | "placeholder" | "searchPlaceholder">) {
  return (
    <SearchableSelect
      {...props}
      options={ALL_COUNTRIES}
      placeholder="Select a country"
      searchPlaceholder="Search countries…"
    />
  );
}
