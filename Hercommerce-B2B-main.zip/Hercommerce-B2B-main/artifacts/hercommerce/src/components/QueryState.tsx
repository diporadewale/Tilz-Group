import type { ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, AlertTriangle } from "lucide-react";

/**
 * The error arm on its own, for pages that already have a
 * `isLoading ? … : empty ? … : list` chain and just need a failure branch
 * inserted. Distinguishing "nothing matched" from "the request failed" is the
 * whole point, an empty state shown on a network error is a lie.
 */
export function ErrorState({
  label,
  onRetry,
}: {
  label?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="text-center py-12 border rounded-lg bg-white space-y-3">
      <div className="h-10 w-10 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
        <AlertTriangle className="h-5 w-5 text-destructive" />
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-medium">{label ?? "Couldn't load this"}</h3>
        <p className="text-muted-foreground text-sm">Check your connection and try again.</p>
      </div>
      {onRetry && (
        <Button variant="outline" size="sm" onClick={onRetry}>
          Retry
        </Button>
      )}
    </div>
  );
}

/**
 * Renders the loading and error arms of a React Query call so pages don't have
 * to. The important half is the error arm: without it a failed request falls
 * through to the empty state and tells the user "no results" when the truth is
 * "we couldn't reach the server".
 */
export function QueryState({
  isLoading,
  isError,
  onRetry,
  loadingLabel,
  errorLabel,
  children,
}: {
  isLoading: boolean;
  isError: boolean;
  onRetry?: () => void;
  loadingLabel?: string;
  errorLabel?: string;
  children: ReactNode;
}) {
  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-12 text-muted-foreground">
        <Loader2 className="h-8 w-8 animate-spin" />
        {loadingLabel && <p className="text-sm">{loadingLabel}</p>}
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
        <div className="h-10 w-10 rounded-full bg-destructive/10 flex items-center justify-center">
          <AlertTriangle className="h-5 w-5 text-destructive" />
        </div>
        <div className="space-y-1">
          <p className="font-medium">{errorLabel ?? "Couldn't load this"}</p>
          <p className="text-sm text-muted-foreground">
            Check your connection and try again.
          </p>
        </div>
        {onRetry && (
          <Button variant="outline" size="sm" onClick={onRetry}>
            Retry
          </Button>
        )}
      </div>
    );
  }

  return <>{children}</>;
}
