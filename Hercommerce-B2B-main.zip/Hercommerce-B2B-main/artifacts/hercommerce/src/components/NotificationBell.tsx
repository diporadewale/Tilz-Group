import { useState } from "react";
import { Link } from "wouter";
import {
  useGetUnreadCount,
  useListNotifications,
  useMarkNotificationsRead,
  getGetUnreadCountQueryKey,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Bell } from "lucide-react";
import { format } from "date-fns";

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const queryClient = useQueryClient();

  // An unread badge is not worth a retry storm. React Query retries three times
  // with backoff by default, so a single failed poll became four failed requests
  // every 30s while the API was unreachable. One attempt is enough: the next
  // poll is the retry. `refetchIntervalInBackground` is left off so a tab left
  // open in the background stops polling entirely.
  const countQuery = useGetUnreadCount({
    query: {
      queryKey: getGetUnreadCountQueryKey(),
      refetchInterval: 30000,
      refetchIntervalInBackground: false,
      retry: false,
    },
  });
  const { data: notifications } = useListNotifications({
    query: { enabled: open, queryKey: getListNotificationsQueryKey() },
  });
  const markRead = useMarkNotificationsRead();
  const count = countQuery.data?.count ?? 0;

  const onOpenChange = (o: boolean) => {
    setOpen(o);
    if (o && count > 0) {
      markRead.mutate(undefined, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetUnreadCountQueryKey() }),
      });
    }
  };

  return (
    <Popover open={open} onOpenChange={onOpenChange}>
      <PopoverTrigger asChild>
        <button className="relative flex h-11 w-11 items-center justify-center rounded-md hover:bg-muted text-foreground" aria-label="Notifications">
          <Bell className="h-5 w-5" />
          {count > 0 && (
            <span className="absolute top-0.5 right-0.5 h-4 min-w-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-medium flex items-center justify-center">
              {count > 9 ? "9+" : count}
            </span>
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="px-4 py-3 border-b font-medium text-sm">Notifications</div>
        <div className="max-h-96 overflow-y-auto">
          {!notifications?.length ? (
            <p className="px-4 py-8 text-center text-sm text-muted-foreground">No notifications yet.</p>
          ) : (
            notifications.map((n) => {
              const content = (
                <>
                  <p className="text-sm font-medium leading-tight">{n.title}</p>
                  {n.body && <p className="text-xs text-muted-foreground mt-0.5">{n.body}</p>}
                  <p className="text-[10px] text-muted-foreground mt-1">{format(new Date(n.createdAt), "MMM d, h:mm a")}</p>
                </>
              );
              const cls = `block px-4 py-3 border-b last:border-0 hover:bg-muted ${!n.readAt ? "bg-primary/5" : ""}`;
              return n.link ? (
                <Link key={n.id} href={n.link} onClick={() => setOpen(false)} className={cls}>
                  {content}
                </Link>
              ) : (
                <div key={n.id} className={cls}>{content}</div>
              );
            })
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
