import { useGetClientConfig, getGetClientConfigQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";

// Renders nothing unless the server reports Google credentials are configured,
// so a deployment without them never shows a button that cannot work.
export function GoogleSignInButton({
  role,
  label = "Continue with Google",
}: {
  /** Carried through the flow so a Google sign-up honours the role picker. */
  role?: "buyer" | "seller";
  label?: string;
}) {
  const { data: config } = useGetClientConfig({
    query: { queryKey: getGetClientConfigQueryKey(), staleTime: Infinity },
  });

  if (!config?.googleAuth) return null;

  const start = () => {
    const params = new URLSearchParams();
    if (role) params.set("role", role);
    // Preserve where the user was headed before they hit the sign-in wall.
    const redirect = new URLSearchParams(window.location.search).get("redirect");
    if (redirect?.startsWith("/") && !redirect.startsWith("//")) {
      params.set("redirect", redirect);
    }
    const qs = params.toString();
    // A full navigation, not fetch, this is an OAuth redirect, and the session
    // cookie must be set on a top-level request.
    window.location.assign(`/api/auth/google${qs ? `?${qs}` : ""}`);
  };

  return (
    <div className="space-y-4">
      <Button type="button" variant="outline" className="w-full" onClick={start}>
        <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" aria-hidden="true">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.76h3.57c2.08-1.92 3.28-4.74 3.28-8.09Z" />
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.76c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84A11 11 0 0 0 12 23Z" />
          <path fill="#FBBC05" d="M5.84 14.11a6.6 6.6 0 0 1 0-4.22V7.05H2.18a11 11 0 0 0 0 9.9l3.66-2.84Z" />
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1a11 11 0 0 0-9.82 6.05l3.66 2.84c.87-2.6 3.3-4.51 6.16-4.51Z" />
        </svg>
        {label}
      </Button>

      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-2 text-muted-foreground">or</span>
        </div>
      </div>
    </div>
  );
}
