import { useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Plus, X } from "lucide-react";

// Multi-select chip picker over a controlled vocabulary. Shared by onboarding
// and the profile editor so the two can't drift, the profile form previously
// offered none of these fields at all, which left every self-onboarded seller
// invisible to category filters and RFQ matching.
export function ChipSelect({
  options,
  moreOptions,
  moreLabel = "Add another",
  value,
  onChange,
  suggested,
  ariaLabel,
  labelledBy,
}: {
  /** Shown as chips: the short list most people pick from. */
  options: readonly string[];
  /**
   * The rest of the vocabulary, reachable through a search rather than as a
   * wall of chips. Country pickers feature the 24 main trade markets but must
   * still reach every country, or an exporter in Uganda could never be matched
   * by a buyer's preferred-origin filter.
   */
  moreOptions?: readonly string[];
  moreLabel?: string;
  value: string[];
  onChange: (v: string[]) => void;
  /** Values pre-selected by intent extraction, ringed until the user edits. */
  suggested?: ReadonlySet<string>;
  ariaLabel?: string;
  /** id of the visible label, preferred over ariaLabel so the two cannot differ. */
  labelledBy?: string;
}) {
  const [adding, setAdding] = useState(false);
  const toggle = (opt: string) =>
    onChange(value.includes(opt) ? value.filter((v) => v !== opt) : [...value, opt]);

  const known = new Set<string>([...options, ...(moreOptions ?? [])]);
  // Picked from the search, so not among the featured chips: render them as
  // selected chips too, or the selection would be invisible after closing.
  const extraSelected = value.filter((v) => !options.includes(v) && known.has(v));
  // Stored before this field was validated ("Organic" rather than "EU Organic"
  // or "USDA Organic"). The server now refuses them, so they must be visible
  // and removable here: hidden, they would block every save with no way for
  // the user to see what to take out.
  const unrecognised = value.filter((v) => !known.has(v));
  const searchable = (moreOptions ?? []).filter((o) => !options.includes(o) && !value.includes(o));

  return (
    <div className="space-y-2">
      <div
        className="flex flex-wrap gap-2"
        role="group"
        aria-label={labelledBy ? undefined : ariaLabel}
        aria-labelledby={labelledBy}
      >
        {options.map((opt) => {
          const active = value.includes(opt);
          const isSuggested = active && suggested?.has(opt);
          return (
            <button
              key={opt}
              type="button"
              onClick={() => toggle(opt)}
              aria-pressed={active}
              title={isSuggested ? "Suggested from your description. Click to remove." : undefined}
              className={`min-h-9 px-3 py-1.5 rounded-full text-sm border transition-colors ${
                active
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background hover:bg-muted border-input text-foreground"
              } ${isSuggested ? "ring-2 ring-offset-1 ring-amber-400" : ""}`}
            >
              {opt}
            </button>
          );
        })}

        {extraSelected.map((opt) => (
          <button
            key={opt}
            type="button"
            onClick={() => toggle(opt)}
            aria-pressed
            aria-label={`${opt}, selected. Remove`}
            className="inline-flex min-h-9 items-center gap-1 px-3 py-1.5 rounded-full text-sm border bg-primary text-primary-foreground border-primary"
          >
            {opt}
            <X className="h-3.5 w-3.5" />
          </button>
        ))}

        {searchable.length > 0 && (
          <Popover open={adding} onOpenChange={setAdding}>
            <PopoverTrigger asChild>
              <button
                type="button"
                className="inline-flex min-h-9 items-center gap-1 px-3 py-1.5 rounded-full text-sm border border-dashed border-input text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <Plus className="h-3.5 w-3.5" /> {moreLabel}
              </button>
            </PopoverTrigger>
            <PopoverContent className="w-64 p-0" align="start">
              <Command>
                <CommandInput placeholder="Search…" />
                <CommandList>
                  <CommandEmpty>No match.</CommandEmpty>
                  <CommandGroup>
                    {searchable.map((opt) => (
                      <CommandItem
                        key={opt}
                        value={opt}
                        onSelect={() => {
                          onChange([...value, opt]);
                          setAdding(false);
                        }}
                      >
                        {opt}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>
        )}
      </div>

      {unrecognised.length > 0 && (
        <div className="rounded-md border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
          <p className="mb-2">
            These were saved before this list was fixed and aren't recognised. Remove them, then
            choose the closest match above.
          </p>
          <div className="flex flex-wrap gap-2">
            {unrecognised.map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => toggle(v)}
                aria-label={`Remove ${v}`}
                className="inline-flex min-h-9 items-center gap-1 rounded-full border border-amber-400 bg-background px-3 py-1 text-amber-900 dark:text-amber-200"
              >
                {v} <X className="h-3.5 w-3.5" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
