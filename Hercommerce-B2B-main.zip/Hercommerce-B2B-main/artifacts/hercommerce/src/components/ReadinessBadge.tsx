import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface ReadinessBadgeProps {
  tier?: 'bronze' | 'silver' | 'gold' | 'platinum' | null;
  score?: number;
  showLabel?: boolean;
}

export function ReadinessBadge({ tier, score, showLabel = true }: ReadinessBadgeProps) {
  if (!tier) return <Badge variant="outline" className="text-muted-foreground">Unrated</Badge>;

  const config = {
    bronze: { label: 'Bronze', color: 'bg-amber-700/20 text-amber-900 border-amber-700/30', icon: '🟫' },
    silver: { label: 'Silver', color: 'bg-slate-200 text-slate-700 border-slate-300', icon: '⬜' },
    gold: { label: 'Gold', color: 'bg-yellow-400/20 text-yellow-700 border-yellow-400/50', icon: '🟡' },
    platinum: { label: 'Platinum', color: 'bg-slate-800 text-slate-100 border-slate-900', icon: '⬛' },
  };

  const { label, color, icon } = config[tier];

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Badge variant="outline" className={`font-semibold cursor-help ${color}`}>
          <span className="mr-1.5" aria-hidden="true">{icon}</span>
          {showLabel && label}
        </Badge>
      </TooltipTrigger>
      <TooltipContent>
        <p className="text-sm font-medium">Readiness: {label}</p>
        {score !== undefined && <p className="text-xs text-muted-foreground">Score: {score}/100</p>}
      </TooltipContent>
    </Tooltip>
  );
}