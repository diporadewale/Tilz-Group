import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { NotificationBell } from "@/components/NotificationBell";
import { useLogout, useResendVerification } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Loader2, Menu, LayoutDashboard, Users, FileText, MessageSquare, ShieldCheck, UserCircle, LogOut, Package, ClipboardList } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user: me, isSignedIn, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const logout = useLogout();
  const resendVerification = useResendVerification();
  // Every page renders its own <Layout>, so plain component state reset on each
  // navigation and the dismissed banner kept coming back. Persist for the tab.
  const [bannerDismissed, setBannerDismissed] = useState(
    () => sessionStorage.getItem("verifyBannerDismissed") === "1",
  );
  const [verifyResent, setVerifyResent] = useState(
    () => sessionStorage.getItem("verifyEmailResent") === "1",
  );

  const dismissBanner = () => {
    sessionStorage.setItem("verifyBannerDismissed", "1");
    setBannerDismissed(true);
  };
  const [mobileOpen, setMobileOpen] = useState(false);
  const [location] = useLocation();
  const logoUrl = `${import.meta.env.BASE_URL.replace(/\/$/, "")}/logo.svg`;

  // Sign out, then hard-reload to a clean app state. The reload re-runs
  // /auth/me from scratch (now 401), avoiding any stale-cache/race where
  // React Query briefly serves the old user and bounces back to the dashboard.
  const signOut = async () => {
    try {
      await logout.mutateAsync(undefined);
    } catch {
      // Even if the request errors, reset the client and leave.
    }
    queryClient.clear();
    const base = import.meta.env.BASE_URL.replace(/\/$/, "");
    window.location.assign(base ? `${base}/` : "/");
  };

  if (isSignedIn && isLoading) {
    return <div className="flex min-h-[100dvh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  // Public layout for signed-out visitors
  if (!isSignedIn) {
    return (
      <div className="min-h-[100dvh] bg-background flex flex-col">
        <header className="border-b bg-white sticky top-0 z-50">
          <div className="h-16 flex items-center justify-between gap-3 px-4 sm:px-6 lg:px-12">
            <Link href="/" className="shrink-0">
              <img src={logoUrl} alt="Originance" className="h-8" />
            </Link>
            <nav className="hidden md:flex gap-6 items-center text-sm font-medium text-muted-foreground">
              <Link href="/sellers" className="hover:text-primary transition-colors">Find Exporters</Link>
              <Link href="/products" className="hover:text-primary transition-colors">Products</Link>
            </nav>
            <div className="flex items-center gap-2 sm:gap-3 shrink-0">
              <Link href="/sign-in" className="text-sm font-medium text-primary hover:underline">Sign In</Link>
              <Button asChild size="sm">
                <Link href="/sign-up">Get Started</Link>
              </Button>
            </div>
          </div>
          {/* The primary nav was `hidden md:flex` with no mobile fallback, so on a
              phone a visitor could not reach the directory or the catalogue at
              all, the two things the public site exists to show. */}
          <nav className="md:hidden flex items-center gap-4 px-4 sm:px-6 pb-3 -mt-1 text-sm font-medium text-muted-foreground overflow-x-auto">
            <Link href="/sellers" className="whitespace-nowrap hover:text-primary transition-colors">Find Exporters</Link>
            <Link href="/products" className="whitespace-nowrap hover:text-primary transition-colors">Products</Link>
          </nav>
        </header>
        <div className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {children}
        </div>
      </div>
    );
  }

  const role = me?.role;
  const isSeller = role === "seller";
  const isBuyer = role === "buyer";
  const isAdmin = role === "admin";

  const navItems = [
    { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard, show: true },
    // The directory and product catalogue are public pages. Sellers were
    // previously locked out of both, so they had no way to see how buyers see
    // them or what else is listed.
    { name: "Exporters", href: "/sellers", icon: Users, show: true },
    { name: "Products", href: "/products", icon: Package, show: true },
    { name: "My Matches", href: "/matches", icon: ShieldCheck, show: isBuyer },
    { name: "My RFQs", href: "/rfqs", icon: ClipboardList, show: isBuyer },
    { name: "RFQ Market", href: "/rfq-market", icon: ClipboardList, show: isSeller },
    { name: "My Products", href: "/my-products", icon: Package, show: isSeller },
    { name: "Documents", href: "/documents", icon: FileText, show: isSeller },
    // Admins can already read every thread server-side (enquiry access checks
    // allow the admin role); without a nav entry that moderation view was
    // unreachable.
    { name: "Enquiries", href: "/enquiries", icon: MessageSquare, show: true },
    { name: "Admin Dashboard", href: "/admin", icon: ShieldCheck, show: isAdmin },
    { name: "Manage Users", href: "/admin/users", icon: Users, show: isAdmin },
    { name: "Manage Exporters", href: "/admin/sellers", icon: Users, show: isAdmin },
    { name: "Review Queue", href: "/admin/documents", icon: FileText, show: isAdmin },
  ];

  // Shared by the desktop sidebar and the mobile drawer. `onNavigate` closes
  // the drawer when a link is tapped on mobile.
  const NavBody = ({ onNavigate }: { onNavigate?: () => void }) => (
    <div className="flex flex-col h-full bg-sidebar">
      <div className="h-16 flex items-center px-6 border-b border-sidebar-border shrink-0">
        <img src={logoUrl} alt="Originance" className="h-8" />
      </div>
      <div className="flex-1 overflow-y-auto py-6 px-4">
        <div className="space-y-1">
          {navItems.filter(item => item.show).map((item) => (
            <Link key={item.name} href={item.href} onClick={onNavigate} className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${location === item.href ? 'bg-sidebar-primary text-sidebar-primary-foreground' : 'text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'}`}>
              <item.icon className="h-4 w-4" />
              {item.name}
            </Link>
          ))}
        </div>
      </div>
      <div className="p-4 border-t border-sidebar-border shrink-0">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
            {me?.firstName?.[0] || me?.email?.[0]?.toUpperCase() || "?"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{me?.firstName} {me?.lastName}</p>
            <p className="text-xs text-muted-foreground truncate capitalize">{role || 'No role'}</p>
          </div>
        </div>
        <div className="space-y-1">
          <Link href="/profile" onClick={onNavigate} className="flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-sidebar-foreground hover:bg-sidebar-accent">
            <UserCircle className="h-4 w-4" /> Profile
          </Link>
          <button onClick={signOut} disabled={logout.isPending} className="w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium text-destructive hover:bg-destructive/10 disabled:opacity-50">
            <LogOut className="h-4 w-4" /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-[100dvh] md:h-[100dvh] bg-muted/30">
      {/* Desktop sidebar */}
      <aside className="w-64 border-r border-sidebar-border hidden md:flex flex-col shrink-0">
        <NavBody />
      </aside>

      {/* Mobile drawer */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-72 p-0">
          <SheetTitle className="sr-only">Navigation menu</SheetTitle>
          <NavBody onNavigate={() => setMobileOpen(false)} />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 md:overflow-hidden">
        {me && !me.emailVerified && !bannerDismissed && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-x-4 gap-y-1 text-sm">
            <span className="text-amber-800">Please verify your email address to secure your account.</span>
            <div className="flex items-center gap-4 shrink-0">
              <button
                onClick={() =>
                  resendVerification.mutate(undefined, {
                    onSuccess: () => {
                      sessionStorage.setItem("verifyEmailResent", "1");
                      setVerifyResent(true);
                    },
                  })
                }
                disabled={resendVerification.isPending || verifyResent}
                className="font-medium text-amber-900 hover:underline disabled:opacity-50 min-h-[44px] sm:min-h-0 sm:py-2 px-2 -mx-2"
              >
                {verifyResent ? "Sent ✓" : resendVerification.isPending ? "Sending…" : "Resend email"}
              </button>
              <button
                onClick={dismissBanner}
                className="flex h-11 w-11 sm:h-8 sm:w-8 items-center justify-center rounded-md text-amber-700 hover:bg-amber-100 hover:text-amber-900"
                aria-label="Dismiss verification reminder"
              >
                ✕
              </button>
            </div>
          </div>
        )}
        <header className="h-16 bg-white border-b border-border flex items-center gap-3 px-4 sm:px-6 shrink-0 sticky top-0 z-40 md:static">
          <button
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
            className="p-2 -ml-2 rounded-md hover:bg-muted text-foreground md:hidden"
          >
            <Menu className="h-6 w-6" />
          </button>
          <img src={logoUrl} alt="Originance" className="h-8 md:hidden" />
          <div className="ml-auto">
            <NotificationBell />
          </div>
        </header>
        <div className="flex-1 md:overflow-auto p-4 sm:p-6 lg:p-8">
          {children}
        </div>
      </main>
    </div>
  );
}
