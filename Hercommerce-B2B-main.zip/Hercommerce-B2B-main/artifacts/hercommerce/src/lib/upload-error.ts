// Vercel Blob's client `upload()` rejects with an Error whose message wraps the
// server's response body. Both upload call sites used to discard it and show a
// fixed "please try again", which meant a misconfigured server looked identical
// to a rejected file and could only be diagnosed from devtools.
export function uploadErrorMessage(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err ?? "");

  // The server sends {"error":"..."}, pull the sentence out of whatever
  // wrapping the Blob client applied.
  const match = raw.match(/"error"\s*:\s*"([^"]+)"/);
  const message = match?.[1] ?? raw;

  if (!message) return "Something went wrong. Please try again.";

  // Missing BLOB_READ_WRITE_TOKEN is an operator problem, not a user one, say
  // so rather than implying retrying will help.
  if (/not configured|BLOB_READ_WRITE_TOKEN/i.test(message)) {
    return "File uploads aren't set up on this server yet. Contact an administrator.";
  }
  if (/content type|allowedContentTypes/i.test(message)) {
    return "That file type isn't accepted. Use a PDF, PNG, JPEG or WebP.";
  }
  if (/size|too large|maximumSize/i.test(message)) {
    return "That file is too large. The limit is 10MB.";
  }

  return message;
}
