// Product categories come from the shared vocabulary package so listings,
// onboarding, the directory filters and the matching algorithm all score
// against the same terms. This list used to be duplicated here and in
// Onboarding.tsx with nothing keeping the two in step.
export { CATEGORIES } from "@workspace/vocab";

// Pricing options are presentation-only, no matching depends on them, so they
// stay local rather than joining the shared vocabulary.
// Moved to @workspace/vocab so the API validates against the same lists.
export { CURRENCIES, UNITS, INCOTERMS } from "@workspace/vocab";

// Format a product's price range for display, e.g. "$3.80 - $4.20 / kg".
export function formatPrice(p: {
  priceMin?: string | null;
  priceMax?: string | null;
  currency?: string | null;
  unit?: string | null;
}): string | null {
  if (!p.priceMin && !p.priceMax) return null;
  const cur = p.currency || "USD";
  const range =
    p.priceMin && p.priceMax && p.priceMin !== p.priceMax
      ? `${p.priceMin} - ${p.priceMax}`
      : p.priceMin || p.priceMax;
  return `${cur} ${range}${p.unit ? ` / ${p.unit}` : ""}`;
}
