import { ApiError } from "@workspace/api-client-react";

// Several handlers refuse a request for a reason the user can act on: "Only
// buyers with a profile can post RFQs", "Verify your email address before
// leaving a review". Those reasons were being thrown away by `catch { toast(
// "Could not post RFQ") }`, leaving the user with a dead button and no idea
// why. `ApiError` already carries the parsed response body, so read it.

/** The server's own explanation, when it gave one. */
export function serverMessage(error: unknown): string | undefined {
  if (!(error instanceof ApiError)) return undefined;
  const data = error.data;
  if (!data || typeof data !== "object") return undefined;
  const reason = (data as Record<string, unknown>).error;
  return typeof reason === "string" && reason.trim() !== "" ? reason : undefined;
}

/**
 * A description for a failure toast: the server's reason where there is one,
 * otherwise wording that matches what actually went wrong. A request that never
 * reached the server is not an `ApiError`, and telling someone to "try again"
 * is only useful advice when the problem is transient.
 */
export function failureReason(error: unknown, fallback = "Please try again."): string {
  const reason = serverMessage(error);
  if (reason) return reason;
  if (error instanceof ApiError) return fallback;
  return "We couldn't reach the server. Check your connection and try again.";
}

/**
 * True when the server refused because of rate limiting. Auth screens hardcode
 * a friendly message for the expected failure ("Invalid email or password"),
 * which would be actively misleading after eight wrong guesses: the credentials
 * may be fine and the account simply throttled.
 */
export function isRateLimited(error: unknown): boolean {
  return error instanceof ApiError && error.status === 429;
}
