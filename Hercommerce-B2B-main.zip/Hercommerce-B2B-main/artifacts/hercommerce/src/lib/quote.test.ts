import { describe, it, expect } from "vitest";
import { formatAmount, formatQuotePrice, formatTarget, rankQuotes } from "./quote";

const q = (id: number, unitPrice: string | null, currency = "USD", unit = "kg", extra = {}) =>
  ({ id, unitPrice, currency, unit, ...extra });

describe("formatting", () => {
  it("matches the catalogue's product price shape", () => {
    expect(formatAmount("4.10", "USD", "kg")).toBe("USD 4.10 / kg");
  });

  it("adds the Incoterm and named place", () => {
    expect(formatQuotePrice(q(1, "4.10", "USD", "kg", { incoterm: "FOB", incotermPlace: "Lagos" })))
      .toBe("USD 4.10 / kg · FOB Lagos");
  });

  // The one live quote predates structuring and must still read correctly.
  it("shows a legacy free-text price exactly as the seller wrote it", () => {
    expect(formatQuotePrice({ id: 1, price: "$4.10/kg FOB Lagos" })).toBe("$4.10/kg FOB Lagos");
  });

  it("formats a target with its currency, and a legacy one as stored", () => {
    expect(formatTarget({ targetPrice: "4.00", targetCurrency: "GBP", unit: "tonne" })).toBe("GBP 4.00 / tonne");
    expect(formatTarget({ targetPrice: "abc" })).toBe("abc");
    expect(formatTarget({ targetPrice: null })).toBeNull();
  });
});

describe("rankQuotes", () => {
  it("sorts comparable quotes by unit price, lowest first", () => {
    const ranked = rankQuotes([q(1, "4.50"), q(2, "3.90"), q(3, "4.10")]);
    expect(ranked.map((r) => r.quote.id)).toEqual([2, 3, 1]);
  });

  it("marks the lowest only when there is something to compare it with", () => {
    expect(rankQuotes([q(1, "4.00")])[0]!.lowest).toBe(false);
    expect(rankQuotes([q(1, "4.00"), q(2, "5.00")]).map((r) => r.lowest)).toEqual([true, false]);
  });

  it("treats a tie as a tie rather than favouring one seller", () => {
    expect(rankQuotes([q(1, "4.00"), q(2, "4.00"), q(3, "5")]).map((r) => r.lowest)).toEqual([true, true, false]);
  });

  // USD per kg and GBP per tonne are different numbers; comparing them would
  // need an exchange rate and a conversion we do not have.
  it("never compares across currencies or units", () => {
    const ranked = rankQuotes([q(1, "3.00", "GBP"), q(2, "4.00", "USD"), q(3, "5.00", "USD", "tonne")]);
    expect(ranked.every((r) => !r.lowest)).toBe(true);
  });

  it("puts the largest comparable group first", () => {
    const ranked = rankQuotes([q(1, "1.00", "GBP"), q(2, "5.00"), q(3, "4.00")]);
    expect(ranked.map((r) => r.quote.id)).toEqual([3, 2, 1]);
  });

  it("puts legacy free-text quotes last, in arrival order", () => {
    const ranked = rankQuotes([{ id: 9, price: "$4/kg" }, q(1, "5"), { id: 8, price: "call me" }, q(2, "4")]);
    expect(ranked.map((r) => r.quote.id)).toEqual([2, 1, 9, 8]);
  });

  it("treats a non-numeric unit price as not comparable instead of NaN-sorting it", () => {
    const ranked = rankQuotes([q(1, "abc"), q(2, "4"), q(3, "3")]);
    expect(ranked.map((r) => r.quote.id)).toEqual([3, 2, 1]);
    expect(ranked[2]!.lowest).toBe(false);
  });

  it("shows percent versus target only when currency and unit match", () => {
    const target = { targetPrice: "4.00", targetCurrency: "USD", unit: "kg" };
    const ranked = rankQuotes([q(1, "3.60"), q(2, "4.40"), q(3, "3.00", "GBP")], target);
    const byId = Object.fromEntries(ranked.map((r) => [r.quote.id, r.vsTargetPct]));
    expect(byId).toEqual({ 1: -10, 2: 10, 3: null });
  });

  it("does not divide by a zero or unparseable target", () => {
    expect(rankQuotes([q(1, "4")], { targetPrice: "0", targetCurrency: "USD", unit: "kg" })[0]!.vsTargetPct).toBeNull();
    expect(rankQuotes([q(1, "4")], { targetPrice: "abc", targetCurrency: "USD", unit: "kg" })[0]!.vsTargetPct).toBeNull();
  });
});
