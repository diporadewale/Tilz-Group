// Formatting and comparison for RFQ target prices and quotes.
//
// Quotes used to be a single free-text price ("$4.10/kg FOB Lagos"), so a buyer
// with five of them had five strings in five formats and no way to line them
// up. They are now structured, and this is where that pays off: quotes that
// share a currency and unit are sorted by unit price and the lowest is marked.
//
// Deliberately deterministic arithmetic. Nothing here judges an exporter; it
// orders numbers the exporters themselves supplied.

/** "USD 4.10 / kg", the same shape as a product's price on the catalogue. */
export function formatAmount(
  amount: string | null | undefined,
  currency: string | null | undefined,
  unit?: string | null,
): string | null {
  if (!amount) return null;
  const money = currency ? `${currency} ${amount}` : amount;
  return unit ? `${money} / ${unit}` : money;
}

interface QuoteLike {
  id: number;
  price?: string | null;
  unitPrice?: string | null;
  currency?: string | null;
  unit?: string | null;
  incoterm?: string | null;
  incotermPlace?: string | null;
}

/**
 * The price line for a quote. Quotes submitted before structuring have only the
 * seller's original free text, shown exactly as written: parsing
 * "$4.10/kg FOB Lagos" back into parts would mean guessing.
 */
export function formatQuotePrice(q: QuoteLike): string {
  const structured = formatAmount(q.unitPrice, q.currency, q.unit);
  if (!structured) return q.price ?? "Price not given";
  const terms = q.incoterm ? ` · ${q.incoterm}${q.incotermPlace ? ` ${q.incotermPlace}` : ""}` : "";
  return `${structured}${terms}`;
}

interface TargetLike {
  targetPrice?: string | null;
  targetCurrency?: string | null;
  unit?: string | null;
}

/** "USD 4.00 / kg", or the raw value for RFQs posted before currency existed. */
export function formatTarget(rfq: TargetLike): string | null {
  if (!rfq.targetPrice) return null;
  return formatAmount(rfq.targetPrice, rfq.targetCurrency, rfq.unit);
}

export interface RankedQuote<Q> {
  quote: Q;
  /** Lowest unit price among at least two quotes in the same currency and unit. */
  lowest: boolean;
  /** Percent above (+) or below (-) the buyer's target, when directly comparable. */
  vsTargetPct: number | null;
}

function amountOf(value: string | null | undefined): number | null {
  if (value === null || value === undefined || value.trim() === "") return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

const keyOf = (q: QuoteLike): string | null =>
  amountOf(q.unitPrice) !== null && q.currency && q.unit ? `${q.currency}|${q.unit}` : null;

/**
 * Orders quotes for a buyer.
 *
 * Only quotes with the same currency and unit are compared: USD per kg and GBP
 * per tonne are not the same number, and converting would need an exchange rate
 * we do not have. The largest comparable group comes first, ascending by unit
 * price; other groups follow; legacy free-text quotes come last, in the order
 * they arrived.
 */
export function rankQuotes<Q extends QuoteLike>(quotes: Q[], target?: TargetLike): RankedQuote<Q>[] {
  const groups = new Map<string, Q[]>();
  const legacy: Q[] = [];
  for (const q of quotes) {
    const key = keyOf(q);
    if (key === null) legacy.push(q);
    else groups.set(key, [...(groups.get(key) ?? []), q]);
  }

  const targetAmount = amountOf(target?.targetPrice);
  const targetKey =
    targetAmount !== null && targetAmount > 0 && target?.targetCurrency && target?.unit
      ? `${target.targetCurrency}|${target.unit}`
      : null;

  const orderedGroups = [...groups.entries()].sort(
    ([ka, a], [kb, b]) => b.length - a.length || ka.localeCompare(kb),
  );

  const ranked: RankedQuote<Q>[] = [];
  for (const [key, group] of orderedGroups) {
    const sorted = [...group].sort((a, b) => amountOf(a.unitPrice)! - amountOf(b.unitPrice)!);
    const min = amountOf(sorted[0]!.unitPrice)!;
    for (const q of sorted) {
      const amount = amountOf(q.unitPrice)!;
      ranked.push({
        quote: q,
        // A single quote is not "the lowest" of anything. Ties all qualify, so
        // two sellers at the same price are shown as equals.
        lowest: group.length > 1 && amount === min,
        vsTargetPct:
          key === targetKey ? Math.round(((amount - targetAmount!) / targetAmount!) * 100) : null,
      });
    }
  }
  for (const q of legacy) ranked.push({ quote: q, lowest: false, vsTargetPct: null });
  return ranked;
}
