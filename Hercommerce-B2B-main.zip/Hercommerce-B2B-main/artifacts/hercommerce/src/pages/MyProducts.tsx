import { usePageMeta } from "@/hooks/use-page-meta";
import { useState } from "react";
import { Link } from "wouter";
import {
  useGetMe,
  useListSellerProfiles,
  useListProducts,
  useCreateProduct,
  useUpdateProduct,
  useDeleteProduct,
  getListProductsQueryKey,
  getListSellerProfilesQueryKey,
} from "@workspace/api-client-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Layout } from "@/components/Layout";
import { RoleDenied } from "@/components/RoleDenied";
import { ApiError } from "@workspace/api-client-react";
import { failureReason } from "@/lib/server-error";
import { uploadErrorMessage } from "@/lib/upload-error";
import { ErrorState } from "@/components/QueryState";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Plus, Trash2, Pencil, Package, UploadCloud } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { upload } from "@vercel/blob/client";
import { CATEGORIES, CURRENCIES, UNITS, formatPrice } from "@/lib/catalog";

const EMPTY = {
  name: "", category: "", description: "",
  priceMin: "", priceMax: "", currency: "USD", unit: "", moq: "",
};

// Two different things fail on this screen and they need different mappers.
// A rejected file comes back from the Blob client; a rejected product comes
// back from our own API as an ApiError whose `message` is prefixed with
// "HTTP 400 Bad Request: ". Feeding the latter through the upload mapper put
// that prefix in front of an otherwise well-written sentence.
function productError(err: unknown): string {
  return err instanceof ApiError ? failureReason(err) : uploadErrorMessage(err);
}

export default function MyProducts() {
  usePageMeta("My products");
  const { data: me, isLoading: meLoading } = useGetMe();
  const isSeller = me?.role === "seller";

  const { data: sellerProfiles, isLoading: profileLoading } = useListSellerProfiles(
    {},
    { query: { enabled: !!me?.id && isSeller, queryKey: getListSellerProfilesQueryKey({}) } },
  );
  const myProfile = sellerProfiles?.find((p) => p.userId === me?.id);
  const sellerId = myProfile?.id;

  const productsParams = { sellerId };
  const { data: products, isLoading: productsLoading, isError: productsError, refetch: refetchProducts } = useListProducts(productsParams, {
    query: { enabled: !!sellerId, queryKey: getListProductsQueryKey(productsParams) },
  });

  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [form, setForm] = useState({ ...EMPTY });
  const [file, setFile] = useState<File | null>(null);
  const [editFile, setEditFile] = useState<File | null>(null);
  const [editImageUrl, setEditImageUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const [editId, setEditId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ ...EMPTY });
  const setEdit = <K extends keyof typeof editForm>(k: K, v: (typeof editForm)[K]) =>
    setEditForm((f) => ({ ...f, [k]: v }));

  // Deleting a product used to happen on a single unconfirmed click.
  const [pendingDelete, setPendingDelete] = useState<{ id: number; name: string } | null>(null);

  const refresh = () => queryClient.invalidateQueries({ queryKey: getListProductsQueryKey(productsParams) });

  const handleAdd = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formEl = e.currentTarget;
    if (!form.name) return;
    setUploading(true);
    try {
      let imageUrl: string | undefined;
      if (file) {
        // "products/" keeps this on the public store: the catalogue renders
        // these in an <img> for signed-out visitors.
        const blob = await upload(`products/${file.name}`, file, {
          access: "public",
          handleUploadUrl: "/api/documents/blob-upload",
          contentType: file.type || undefined,
        });
        imageUrl = blob.url;
      }
      await createProduct.mutateAsync({
        data: {
          name: form.name,
          category: form.category || undefined,
          description: form.description || undefined,
          priceMin: form.priceMin || undefined,
          priceMax: form.priceMax || undefined,
          currency: form.currency || undefined,
          unit: form.unit || undefined,
          moq: form.moq ? Number(form.moq) : undefined,
          imageUrl,
        },
      });
      toast({ title: "Product added" });
      setForm({ ...EMPTY });
      setFile(null);
      formEl.reset();
      refresh();
    } catch (err) {
      // The photo upload is the usual failure here, and its reason is
      // actionable (wrong type, too big, uploads not configured), show it.
      toast({
        title: "Could not add product",
        description: productError(err),
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteProduct.mutateAsync({ id });
      toast({ title: "Product deleted" });
      setPendingDelete(null);
      refresh();
    } catch (err) {
      toast({ title: "Could not delete product", description: productError(err), variant: "destructive" });
    }
  };

  // Editing was never wired up even though PATCH /products/{id} already existed
  // and enforced ownership, so a typo meant deleting and re-creating a product.
  const startEdit = (p: NonNullable<typeof products>[number]) => {
    setEditId(p.id);
    setEditFile(null);
    setEditImageUrl(p.imageUrl ?? null);
    setEditForm({
      name: p.name,
      category: p.category ?? "",
      description: p.description ?? "",
      priceMin: p.priceMin ?? "",
      priceMax: p.priceMax ?? "",
      currency: p.currency ?? "USD",
      unit: p.unit ?? "",
      moq: p.moq != null ? String(p.moq) : "",
    });
  };

  const handleEditSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editId === null || !editForm.name) return;
    try {
      // Upload first: if the new photo is rejected, the rest of the edit is
      // left untouched rather than half-applied.
      // null, not undefined: an omitted key means "leave the photo as it is",
      // so "Remove photo" has to send an explicit null to clear the column.
      let imageUrl: string | null = editImageUrl;
      if (editFile) {
        const blob = await upload(`products/${editFile.name}`, editFile, {
          access: "public",
          handleUploadUrl: "/api/documents/blob-upload",
          contentType: editFile.type || undefined,
        });
        imageUrl = blob.url;
      }

      await updateProduct.mutateAsync({
        id: editId,
        data: {
          imageUrl,
          name: editForm.name,
          category: editForm.category || undefined,
          description: editForm.description || undefined,
          priceMin: editForm.priceMin || undefined,
          priceMax: editForm.priceMax || undefined,
          currency: editForm.currency || undefined,
          unit: editForm.unit || undefined,
          moq: editForm.moq ? Number(editForm.moq) : undefined,
        },
      });
      toast({ title: "Product updated" });
      setEditId(null);
      refresh();
    } catch (err) {
      toast({ title: "Could not update product", description: productError(err), variant: "destructive" });
    }
  };

  if (meLoading || profileLoading) {
    return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div></Layout>;
  }
  if (!isSeller) {
    return <RoleDenied message="Only exporters can manage products." hint="Product listings belong to an exporter profile." />;
  }
  if (!myProfile) {
    // Previously a plain sentence with no way to act on it, onboarding was only
    // reachable from the post-signup redirect.
    return (
      <Layout>
        <div className="p-8 text-center space-y-4 max-w-md mx-auto">
          <Package className="h-10 w-10 mx-auto text-muted-foreground opacity-40" />
          <div className="space-y-1">
            <h2 className="text-lg font-medium">Complete your exporter profile first</h2>
            <p className="text-muted-foreground text-sm">
              Buyers need a company profile to find your products.
            </p>
          </div>
          <Button asChild>
            <Link href="/onboarding">Complete profile</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">My Products</h1>
          <p className="text-muted-foreground">List the products buyers can discover and enquire about.</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Add form */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Plus className="h-5 w-5" /> Add Product</CardTitle>
                <CardDescription>Photos and prices help buyers reach out.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAdd} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input id="name" required value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="e.g. Dried Mango Slices" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={form.category} onValueChange={(v) => set("category", v)}>
                      <SelectTrigger id="category"><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="priceMin">Price from</Label>
                      <Input id="priceMin" type="number" min="0" step="0.01" inputMode="decimal" value={form.priceMin} onChange={(e) => set("priceMin", e.target.value)} placeholder="3.80" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="priceMax">Price to</Label>
                      <Input id="priceMax" type="number" min="0" step="0.01" inputMode="decimal" value={form.priceMax} onChange={(e) => set("priceMax", e.target.value)} placeholder="4.20" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label htmlFor="currency">Currency</Label>
                      <Select value={form.currency} onValueChange={(v) => set("currency", v)}>
                        <SelectTrigger id="currency"><SelectValue /></SelectTrigger>
                        <SelectContent>{CURRENCIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="unit">Unit</Label>
                      <Select value={form.unit} onValueChange={(v) => set("unit", v)}>
                        <SelectTrigger id="unit"><SelectValue placeholder="Select unit" /></SelectTrigger>
                        <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="moq">Minimum order qty</Label>
                    <Input id="moq" type="number" min="0" step="1" inputMode="numeric" value={form.moq} onChange={(e) => set("moq", e.target.value)} placeholder="e.g. 500" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea id="description" rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="image">Photo</Label>
                    <Input id="image" type="file" accept=".png.jpg.jpeg.webp" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                  </div>
                  <Button type="submit" className="w-full" disabled={uploading || createProduct.isPending}>
                    {uploading || createProduct.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                    {uploading ? "Uploading…" : "Add Product"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* List */}
          <div className="lg:col-span-2">
            {productsLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
            ) : productsError ? (
              <ErrorState label="Couldn't load your products" onRetry={() => refetchProducts()} />
            ) : !products?.length ? (
              <div className="text-center py-12 border border-dashed rounded-lg text-muted-foreground">
                <Package className="h-8 w-8 mx-auto mb-2 opacity-50" />
                No products yet. Add your first on the left.
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 gap-4">
                {products.map((p) => {
                  const price = formatPrice(p);
                  return (
                    <Card key={p.id} className="overflow-hidden flex flex-col">
                      {p.imageUrl ? (
                        <img src={p.imageUrl} alt={p.name} className="h-36 w-full object-cover" />
                      ) : (
                        <div className="h-36 w-full bg-muted flex items-center justify-center"><Package className="h-8 w-8 text-muted-foreground" /></div>
                      )}
                      <CardContent className="p-4 flex-1 flex flex-col">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-semibold leading-tight">{p.name}</h3>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => startEdit(p)}
                              aria-label={`Edit ${p.name}`}
                              className="text-muted-foreground hover:text-primary p-1"
                            >
                              <Pencil className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => setPendingDelete({ id: p.id, name: p.name })}
                              aria-label={`Delete ${p.name}`}
                              className="text-muted-foreground hover:text-destructive p-1"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                        {p.category && <p className="text-xs text-muted-foreground mt-1">{p.category}</p>}
                        {price && <p className="text-sm font-medium text-primary mt-2">{price}</p>}
                        {p.moq != null && <p className="text-xs text-muted-foreground mt-1">MOQ: {p.moq}</p>}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit product */}
      <Dialog open={editId !== null} onOpenChange={(open) => !open && setEditId(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit product</DialogTitle>
            <DialogDescription>
              Changes go live on your public profile as soon as you save.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleEditSave} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Name *</Label>
              <Input id="edit-name" required value={editForm.name} onChange={(e) => setEdit("name", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-category">Category</Label>
              <Select value={editForm.category} onValueChange={(v) => setEdit("category", v)}>
                <SelectTrigger id="edit-category"><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="edit-priceMin">Price from</Label>
                <Input id="edit-priceMin" type="number" min="0" step="0.01" inputMode="decimal" value={editForm.priceMin} onChange={(e) => setEdit("priceMin", e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-priceMax">Price to</Label>
                <Input id="edit-priceMax" type="number" min="0" step="0.01" inputMode="decimal" value={editForm.priceMax} onChange={(e) => setEdit("priceMax", e.target.value)} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="edit-currency">Currency</Label>
                <Select value={editForm.currency} onValueChange={(v) => setEdit("currency", v)}>
                  <SelectTrigger id="edit-currency"><SelectValue /></SelectTrigger>
                  <SelectContent>{CURRENCIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-unit">Unit</Label>
                <Select value={editForm.unit} onValueChange={(v) => setEdit("unit", v)}>
                  <SelectTrigger id="edit-unit"><SelectValue placeholder="Select unit" /></SelectTrigger>
                  <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-moq">Minimum order qty</Label>
              <Input id="edit-moq" type="number" min="0" step="1" inputMode="numeric" value={editForm.moq} onChange={(e) => setEdit("moq", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea id="edit-description" rows={3} value={editForm.description} onChange={(e) => setEdit("description", e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-image">Photo</Label>
              {editImageUrl && !editFile && (
                <div className="flex items-center gap-3">
                  <img src={editImageUrl} alt="" className="h-16 w-16 rounded border object-cover" />
                  <Button type="button" variant="outline" size="sm" onClick={() => setEditImageUrl(null)}>
                    Remove photo
                  </Button>
                </div>
              )}
              <Input
                id="edit-image"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => setEditFile(e.target.files?.[0] ?? null)}
                className="file:mr-3 file:rounded-md file:border-0 file:bg-primary file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-primary-foreground hover:file:bg-primary/90 cursor-pointer"
              />
              <p className="text-xs text-muted-foreground">
                {editFile ? `Replacing with ${editFile.name}` : "Choose a file to replace the current photo. PNG, JPEG or WebP, up to 10MB."}
              </p>
            </div>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2">
              <Button type="button" variant="outline" onClick={() => setEditId(null)}>Cancel</Button>
              <Button type="submit" disabled={updateProduct.isPending}>
                {updateProduct.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Save changes
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirm delete */}
      <AlertDialog open={pendingDelete !== null} onOpenChange={(open) => !open && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this product?</AlertDialogTitle>
            <AlertDialogDescription>
              “{pendingDelete?.name}” will be removed from your listings and buyers will
              no longer see it. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={(e) => {
                e.preventDefault();
                if (pendingDelete) handleDelete(pendingDelete.id);
              }}
              disabled={deleteProduct.isPending}
            >
              {deleteProduct.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Layout>
  );
}
