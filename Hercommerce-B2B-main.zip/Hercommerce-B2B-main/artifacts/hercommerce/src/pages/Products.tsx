import { usePageMeta } from "@/hooks/use-page-meta";
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useListProducts, getListProductsQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Search, Package } from "lucide-react";
import { CATEGORIES, formatPrice } from "@/lib/catalog";

export default function Products() {
  usePageMeta("Browse products", "Browse products from verified exporters in emerging markets.");
  const [search, setSearch] = useState(
    () => new URLSearchParams(window.location.search).get("search") ?? "",
  );
  const [category, setCategory] = useState("all");

  // This list had no server-side cap at all, so a growing catalogue would have
  // run past the 10s serverless budget rather than returning anything. One more
  // than we show tells us whether another page exists.
  const [limit, setLimit] = useState(50);
  const params = {
    search: search || undefined,
    category: category !== "all" ? category : undefined,
    limit: limit + 1,
  };
  const { data: page, isLoading, isError, refetch } = useListProducts(params, {
    query: { queryKey: getListProductsQueryKey(params) },
  });
  const hasMore = (page?.length ?? 0) > limit;
  const products = hasMore ? page?.slice(0, limit) : page;

  useEffect(() => { setLimit(50); }, [search, category]);

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Browse Products</h1>
          {/* /sellers shows a count and a reset; this page showed neither, so a
              filter that matched nothing looked the same as a failed load. */}
          {!isLoading && !isError && (
            <p className="text-sm text-muted-foreground mt-1">
              {products?.length
                ? `Showing ${products.length} product${products.length === 1 ? "" : "s"}${hasMore ? " so far" : ""}`
                : "No products match these filters"}
            </p>
          )}
          <p className="text-muted-foreground">
            Browse products listed by exporters on Originance. Check each exporter's
            readiness tier on their profile before making contact.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search products…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="w-full sm:w-[200px]">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : isError ? (
          <ErrorState label="Couldn't load products" onRetry={() => refetch()} />
        ) : !products?.length ? (
          <div className="text-center py-12 border rounded-lg bg-white">
            <Package className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No products found</h3>
            <p className="text-muted-foreground">{search || category !== "all" ? "Try a different search or category." : "No products have been listed yet."}</p>
          </div>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {products.map((p) => {
              const price = formatPrice(p);
              return (
                <Link key={p.id} href={`/products/${p.id}`} className="group">
                  <Card className="h-full flex flex-col overflow-hidden transition-all hover:border-primary/50 hover:shadow-md cursor-pointer">
                    {p.imageUrl ? (
                      <img src={p.imageUrl} alt={p.name} className="h-40 w-full object-cover" />
                    ) : (
                      <div className="h-40 w-full bg-muted flex items-center justify-center">
                        <Package className="h-8 w-8 text-muted-foreground" />
                      </div>
                    )}
                    <CardContent className="p-4 flex-1 flex flex-col">
                      <h3 className="font-semibold leading-tight line-clamp-2">{p.name}</h3>
                      {p.category && (
                        <Badge variant="secondary" className="mt-2 w-fit text-xs font-normal">{p.category}</Badge>
                      )}
                      {p.description && (
                        <p className="mt-2 text-xs text-muted-foreground line-clamp-2">{p.description}</p>
                      )}
                      <div className="mt-auto pt-3">
                        {price && <p className="text-sm font-medium text-primary">{price}</p>}
                        {p.moq != null && <p className="text-xs text-muted-foreground">MOQ: {p.moq}</p>}
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}

        {hasMore && (
          <div className="flex justify-center pt-6">
            <Button variant="outline" onClick={() => setLimit((n) => n + 50)}>
              Load more products
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
}
