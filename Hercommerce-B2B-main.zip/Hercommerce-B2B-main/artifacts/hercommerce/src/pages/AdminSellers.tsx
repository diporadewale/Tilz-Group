import {
  useListSellerProfiles,
  useUpdateReadiness,
  type ReadinessTierUpdateTier,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Download, Search } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListSellerProfilesQueryKey } from "@workspace/api-client-react";

export default function AdminSellers() {
  const [search, setSearch] = useState("");
  
  const { data: sellers, isLoading, isError, refetch } = useListSellerProfiles({ search: search || undefined });
  const updateTier = useUpdateReadiness();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleExport = async () => {
    try {
      const resp = await fetch(`${import.meta.env.BASE_URL}api/admin/exports/sellers`);
      if (!resp.ok) throw new Error("Export failed");
      const csvData = await resp.text();
      const blob = new Blob([csvData], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `sellers_export_${format(new Date(), 'yyyyMMdd')}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      toast({ title: "Export failed", variant: "destructive" });
    }
  };

  const handleTierOverride = async (sellerId: number, newTier: ReadinessTierUpdateTier) => {
    try {
      await updateTier.mutateAsync({
        sellerId,
        data: { tier: newTier, adminNote: "Manual override by admin" }
      });
      toast({ title: "Tier updated" });
      queryClient.invalidateQueries({ queryKey: getListSellerProfilesQueryKey() });
    } catch (e) {
      toast({ title: "Failed to update tier", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Manage Exporters</h1>
          </div>
          <Button onClick={handleExport} variant="outline"><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
        </div>

        <Card className="p-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input type="search" aria-label="Search exporters by company name" placeholder="Search company name..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
        </Card>

        {/* Same treatment as the users table: below md each exporter is a card
            with the tier override full-width, instead of a sideways scroll that
            hid the only control on the screen. */}
        {isLoading ? (
          <Card className="flex justify-center p-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </Card>
        ) : isError ? (
          <ErrorState label="Couldn't load exporters" onRetry={() => refetch()} />
        ) : !sellers?.length ? (
          <Card className="p-12 text-center text-muted-foreground">No exporters found.</Card>
        ) : (
          <>
            <div className="space-y-3 md:hidden">
              {sellers.map((s) => (
                <Card key={s.id} className="space-y-3 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <p className="min-w-0 truncate font-medium">{s.companyName}</p>
                    <ReadinessBadge tier={s.readinessTier} />
                  </div>
                  <p className="text-sm text-muted-foreground">{s.country}</p>
                  <div className="space-y-1">
                    <p className="text-xs font-medium text-muted-foreground">Override tier</p>
                    <Select
                      value={s.readinessTier || undefined}
                      onValueChange={(val) => handleTierOverride(s.id, val as ReadinessTierUpdateTier)}
                    >
                      <SelectTrigger className="h-11 w-full">
                        <SelectValue placeholder="Select Tier" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bronze">Bronze</SelectItem>
                        <SelectItem value="silver">Silver</SelectItem>
                        <SelectItem value="gold">Gold</SelectItem>
                        <SelectItem value="platinum">Platinum</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </Card>
              ))}
            </div>

            <Card className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Company</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Current Tier</TableHead>
                    <TableHead className="text-right">Override Tier</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sellers.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="font-medium">{s.companyName}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{s.country}</TableCell>
                      <TableCell><ReadinessBadge tier={s.readinessTier} /></TableCell>
                      <TableCell className="text-right">
                        <Select
                          value={s.readinessTier || undefined}
                          onValueChange={(val) => handleTierOverride(s.id, val as ReadinessTierUpdateTier)}
                        >
                          <SelectTrigger className="ml-auto h-8 w-[130px] text-xs">
                            <SelectValue placeholder="Select Tier" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="bronze">Bronze</SelectItem>
                            <SelectItem value="silver">Silver</SelectItem>
                            <SelectItem value="gold">Gold</SelectItem>
                            <SelectItem value="platinum">Platinum</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </>
        )}
      </div>
    </Layout>
  );
}