import { Link, useLocation } from "wouter";
import { usePageMeta } from "@/hooks/use-page-meta";
import { Layout } from "@/components/Layout";

// The footer linked Privacy Policy and Terms of Service to `href="#"`, and no
// legal pages existed. The platform collects company data, revenue bands,
// employee counts and uploaded registration documents across borders, so
// shipping without these is a compliance exposure rather than a content gap.
//
// ⚠️ These are placeholders written to be honest about what the product
// actually does, they are NOT legal advice and have not been reviewed by a
// lawyer. Have counsel review before launch, and fill in the bracketed fields.

// Support goes to the operating company, not the brand domain. Originance is
// the marketplace; Tilz Group is the entity users are contracting with, and the
// one that has to answer a data-protection request.
const CONTACT = "hello@tilzgroup.com";
const ENTITY = "Tilz Group";
// The registered office. UK consumer and e-commerce rules require a trading
// entity to publish this, and sign-up asks users to agree to these documents,
// so it has to be the real one. Still rendered conditionally: if it is ever
// blanked, the sentence stays grammatical instead of showing a stray comma.
const ADDRESS = "Unit 3A, Eagle Industrial Estate, 4 Torre Road, Leeds, LS9 7QL";

function LegalShell({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  // "See also Terms of Service" on /terms pointed at /terms. Only offer the
  // document the reader is not already on.
  const [path] = useLocation();
  usePageMeta(title);
  return (
    <Layout>
      <article className="max-w-3xl mx-auto space-y-6 pb-12">
        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{title}</h1>
          <p className="text-sm text-muted-foreground">Last updated: {updated}</p>
        </div>

        <div className="rounded-lg border border-amber-300 bg-amber-50 p-4 text-sm text-amber-900">
          <strong>Draft.</strong> This document is a placeholder pending legal review. It describes
          how the platform currently behaves but does not yet constitute a binding agreement.
        </div>

        <div className="space-y-6 text-sm leading-relaxed text-muted-foreground [&_h2]:text-base [&_h2]:font-semibold [&_h2]:text-foreground [&_h2]:mt-6">
          {children}
        </div>

        <p className="text-sm text-muted-foreground pt-4 border-t">
          Questions? Contact {CONTACT}. See also{" "}
          {path === "/privacy" ? (
            <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>
          ) : (
            <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>
          )}.
        </p>
      </article>
    </Layout>
  );
}

export function Privacy() {
  return (
    <LegalShell title="Privacy Policy" updated="13 August 2026">
      <h2>Who we are</h2>
      <p>
        Originance is operated by {ENTITY}{ADDRESS ? `, registered office ${ADDRESS}` : ""}. We are the data controller for the
        personal data described below.
      </p>

      <h2>What we collect</h2>
      <p>
        <strong>Account data:</strong> your name, email address and a hashed password. We record
        whether your email has been verified.
      </p>
      <p>
        <strong>Company profile data:</strong> company name, country, city, website, description,
        and, depending on your role, product categories, export markets, certifications, annual
        revenue band, employee count band, sourcing categories, preferred origins and annual
        sourcing budget band.
      </p>
      <p>
        <strong>Verification documents:</strong> files you upload for verification, such as business
        registration certificates, tax certificates and export licences. These may contain personal
        data about directors or owners.
      </p>
      <p>
        <strong>Activity data:</strong> enquiries and messages you send, requests for quote, quotes,
        reviews you leave, and in-app notifications.
      </p>

      <h2>How we use it</h2>
      <p>
        To operate your account; to verify exporters and assign readiness tiers; to match buyers
        with exporters; to deliver enquiries, quotes and notifications; and to send transactional
        email such as email verification and password resets.
      </p>

      <h2>Who can see what</h2>
      <p>
        <strong>Exporter profiles are public.</strong> Company name, country, city, description,
        categories, export markets, certifications and readiness tier are visible to anyone,
        including visitors who are not signed in.
      </p>
      <p>
        <strong>Buyer profiles are private.</strong> They are visible only to you and to our
        administrators.
      </p>
      <p>
        <strong>Uploaded documents are private.</strong> They are visible only to you and to our
        administrators. The verification outcome (your readiness tier) is public; the documents
        themselves are not.
      </p>
      <p>
        <strong>Messages are private to the two companies in the conversation.</strong> Our
        administrators can read enquiry threads in order to investigate disputes and abuse
        reports. They cannot post into a conversation: only the buyer and the exporter can
        add messages, so anything you see in a thread was written by the other company.
      </p>
      <p>
        <strong>Reviews are public,</strong> and are attributed to your company name.
      </p>

      <h2>Processors</h2>
      <p>
        We use third parties to run the service: Vercel (hosting and file storage), Neon
        (database hosting), Resend (transactional email) and Anthropic (optional assistance in
        interpreting a business description you type during onboarding, where enabled).
      </p>

      <h2>International transfers</h2>
      <p>
        The platform connects parties across borders, and our processors operate internationally,
        so your data may be transferred outside your country of residence.
      </p>

      <h2>Retention</h2>
      <p>
        We keep account and profile data while your account is active. Verification documents are
        retained for as long as they support a current readiness tier.
      </p>

      <h2>Your rights</h2>
      <p>
        Depending on where you live, you may have rights to access, correct, delete, export or
        restrict the processing of your personal data, and to object to it. Contact {CONTACT} to
        exercise them.
      </p>

      <h2>Cookies</h2>
      <p>
        We set a single essential cookie to keep you signed in. We do not use advertising or
        third-party tracking cookies.
      </p>
    </LegalShell>
  );
}

export function Terms() {
  return (
    <LegalShell title="Terms of Service" updated="13 August 2026">
      <h2>Agreement</h2>
      <p>
        By creating an account you agree to these terms. If you are using Originance on behalf of
        a company, you confirm you are authorised to bind that company.
      </p>

      <h2>What Originance is and is not</h2>
      <p>
        Originance is a directory and introduction service. We verify that exporters have supplied
        certain business documents, and we publish a readiness tier reflecting how much has been
        verified.
      </p>
      <p>
        <strong>We are not a party to any transaction between a buyer and an exporter.</strong> We
        do not process payments, hold funds, arrange shipping, inspect goods, or guarantee the
        quality, safety, legality or delivery of anything offered. Verification is a check of
        submitted documents at a point in time, not a warranty about a company's conduct or the
        goods it supplies. Carry out your own due diligence before entering a contract.
      </p>

      <h2>Your account</h2>
      <p>
        Keep your credentials secure and provide accurate information. We may suspend or remove
        accounts that supply false information, upload documents they have no right to share, or
        misuse the platform.
      </p>

      <h2>Content you submit</h2>
      <p>
        You keep ownership of what you upload. You grant us the licence needed to host and display
        it in order to run the service, including displaying exporter profile information
        publicly. You confirm you have the right to share everything you upload.
      </p>

      <h2>Reviews</h2>
      <p>
        Reviews must reflect genuine experience. You may review an exporter only after contacting
        them through the platform, and only once per exporter; submitting again replaces your
        previous review. We may remove reviews that are false, abusive or manipulative.
      </p>

      <h2>Acceptable use</h2>
      <p>
        Do not scrape the platform, attempt to access data belonging to others, interfere with its
        operation, or use it to send unsolicited commercial messages.
      </p>

      <h2>Availability</h2>
      <p>
        The service is provided "as is". We do not guarantee uninterrupted availability and may
        change or discontinue features.
      </p>

      <h2>Liability</h2>
      <p>
        To the fullest extent permitted by law, we are not liable for losses arising from dealings
        between buyers and exporters, including non-delivery, defective goods or non-payment.
      </p>

      <h2>Termination</h2>
      <p>You may stop using the platform at any time and ask us to delete your account.</p>

      <h2>Contact</h2>
      <p>{ENTITY}{ADDRESS ? `, ${ADDRESS}` : ""}. {CONTACT}</p>
    </LegalShell>
  );
}
