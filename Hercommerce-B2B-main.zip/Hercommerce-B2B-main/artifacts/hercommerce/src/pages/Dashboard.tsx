import { usePageMeta } from "@/hooks/use-page-meta";
import { Link } from "wouter";
import {
  useGetMe,
  useListEnquiries,
  useListSellerProfiles,
  useListBuyerProfiles,
  useGetReadiness,
  useListRfqs,
  getGetMeQueryKey,
  getListEnquiriesQueryKey,
  getListSellerProfilesQueryKey,
  getListBuyerProfilesQueryKey,
  getGetReadinessQueryKey,
  getListRfqsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Layout } from "@/components/Layout";
import { QueryState } from "@/components/QueryState";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { ArrowRight, UserCircle } from "lucide-react";

function StatCard({
  title,
  value,
  hint,
}: {
  title: string;
  value: React.ReactNode;
  hint?: string;
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {/* "Account Status: Approved" alongside a profile whose own status was
            still "pending" read as a contradiction. Name which one this is. */}
        {hint && <p className="text-xs text-muted-foreground mt-1">{hint}</p>}
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  usePageMeta("Dashboard");
  const meQuery = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const me = meQuery.data;

  const isSeller = me?.role === "seller";
  const isBuyer = me?.role === "buyer";
  const canHaveEnquiries = isSeller || isBuyer;

  const enquiriesQuery = useListEnquiries(
    {},
    { query: { enabled: canHaveEnquiries, queryKey: getListEnquiriesQueryKey({}) } },
  );

  // Find this user's own profile so we can tell them whether onboarding is done
  // and, for sellers, resolve the profile id the readiness endpoint is keyed by.
  // (GET /buyer-profiles returns only the caller's own profile for non-admins.)
  const sellerProfilesQuery = useListSellerProfiles(
    {},
    { query: { enabled: isSeller, queryKey: getListSellerProfilesQueryKey({}) } },
  );
  const buyerProfilesQuery = useListBuyerProfiles(
    {},
    { query: { enabled: isBuyer, queryKey: getListBuyerProfilesQueryKey({}) } },
  );

  const myProfileId = isSeller
    ? sellerProfilesQuery.data?.find((p) => p.userId === me?.id)?.id
    : buyerProfilesQuery.data?.find((p) => p.userId === me?.id)?.id;

  const hasProfile = myProfileId !== undefined;

  const readinessQuery = useGetReadiness(myProfileId ?? 0, {
    query: {
      enabled: isSeller && hasProfile,
      queryKey: getGetReadinessQueryKey(myProfileId ?? 0),
    },
  });

  const rfqParams = { scope: isSeller ? ("market" as const) : ("mine" as const) };
  const rfqsQuery = useListRfqs(rfqParams, {
    query: { enabled: canHaveEnquiries, queryKey: getListRfqsQueryKey(rfqParams) },
  });

  const openEnquiries = (enquiriesQuery.data ?? []).filter((e) => e.status !== "closed").length;
  const openRfqs = (rfqsQuery.data ?? []).filter((r) => r.status === "open").length;

  return (
    <Layout>
      <QueryState
        isLoading={meQuery.isLoading}
        isError={meQuery.isError}
        onRetry={() => meQuery.refetch()}
        errorLabel="Couldn't load your account"
      >
        <div className="space-y-6">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Dashboard</h1>
            <p className="text-muted-foreground mt-1">
              Welcome back{me?.firstName ? `, ${me.firstName}` : ""}.
            </p>
          </div>

          {/* Onboarding was previously only reachable straight after sign-up, so
              anyone who abandoned it had no route back and every action failed
              with an unexplained error. */}
          {canHaveEnquiries && !hasProfile && !sellerProfilesQuery.isLoading && !buyerProfilesQuery.isLoading && (
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="flex flex-col sm:flex-row sm:items-center gap-4 pt-6">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <UserCircle className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">Finish setting up your company profile</p>
                  <p className="text-sm text-muted-foreground">
                    {isSeller
                      ? "You need a company profile before you can list products or quote on RFQs."
                      : "You need a company profile before you can contact exporters or post RFQs."}
                  </p>
                </div>
                <Button asChild className="shrink-0">
                  <Link href="/onboarding">
                    Complete profile <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <StatCard
              title="Account Status"
              value={<span className="capitalize">{me?.status ?? "N/A"}</span>}
              hint={
                hasProfile
                  ? "Your sign-in account. Your company profile is verified separately."
                  : undefined
              }
            />

            {isSeller && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Readiness Tier
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {hasProfile ? (
                    <ReadinessBadge
                      tier={readinessQuery.data?.tier ?? null}
                      score={readinessQuery.data?.score}
                    />
                  ) : (
                    <div className="text-2xl font-bold text-muted-foreground">N/A</div>
                  )}
                </CardContent>
              </Card>
            )}

            {canHaveEnquiries && (
              <StatCard
                title="Open Enquiries"
                value={enquiriesQuery.isError ? "N/A" : openEnquiries}
              />
            )}

            {canHaveEnquiries && (
              <StatCard
                title={isSeller ? "Matching RFQs" : "My Open RFQs"}
                value={rfqsQuery.isError ? "N/A" : openRfqs}
              />
            )}
          </div>

          <div className="flex flex-wrap gap-3">
            {isBuyer && (
              <>
                <Button asChild variant="outline">
                  <Link href="/sellers">Browse exporters</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/rfqs">My RFQs</Link>
                </Button>
              </>
            )}
            {isSeller && (
              <>
                <Button asChild variant="outline">
                  <Link href="/my-products">My products</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/rfq-market">RFQ market</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link href="/documents">Documents</Link>
                </Button>
              </>
            )}
            {me?.role === "admin" && (
              <Button asChild variant="outline">
                <Link href="/admin">Admin dashboard</Link>
              </Button>
            )}
          </div>
        </div>
      </QueryState>
    </Layout>
  );
}
