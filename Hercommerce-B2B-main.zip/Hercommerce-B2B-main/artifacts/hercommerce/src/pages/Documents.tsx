import { usePageMeta } from "@/hooks/use-page-meta";
import {
  useGetMe,
  useListDocuments,
  useUploadDocument,
  getListDocumentsQueryKey,
  type DocumentDocumentType,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { RoleDenied } from "@/components/RoleDenied";
import { uploadErrorMessage } from "@/lib/upload-error";
import { ErrorState } from "@/components/QueryState";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, UploadCloud, CheckCircle2, AlertCircle, Clock } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { upload } from "@vercel/blob/client";

export default function Documents() {
  usePageMeta("Documents");
  const { data: me } = useGetMe();
  const isSeller = me?.role === 'seller';
  const docsParams = { userId: isSeller ? me?.id : undefined };
  const { data: documents, isLoading: docsLoading, isError: docsError, refetch: refetchDocs } = useListDocuments(docsParams, { query: { enabled: !!me?.id, queryKey: getListDocumentsQueryKey(docsParams) } });
  const uploadDoc = useUploadDocument();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [docType, setDocType] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    if (!docType || !file) return;

    setUploading(true);
    try {
      // Upload the file straight to Vercel Blob; the server only mints a token.
      // Private. A business registration or tax certificate served from a
      // public URL is readable by anyone holding the link, and links leak
      // through history, referrers and support tickets.
      //
      // Vercel Blob sets access per STORE, so the "documents/" prefix is what
      // tells /documents/blob-upload to mint a token for the private store
      // rather than the public one the product catalogue uses. Reading one back
      // goes through GET /documents/:id/file, which checks ownership.
      const blob = await upload(`documents/${file.name}`, file, {
        access: "private",
        handleUploadUrl: "/api/documents/blob-upload",
        contentType: file.type || undefined,
      });

      await uploadDoc.mutateAsync({
        data: {
          documentType: docType as DocumentDocumentType,
          fileName: file.name,
          fileUrl: blob.url,
          storageAccess: "private",
        },
      });

      toast({ title: "Document uploaded", description: "It is now pending admin review." });
      setDocType("");
      setFile(null);
      form.reset();
      queryClient.invalidateQueries({ queryKey: getListDocumentsQueryKey({ userId: me?.id }) });
    } catch (err) {
      // Surface the server's reason. "Please try again" sent people to devtools
      // to discover the real cause (e.g. uploads not configured on the server).
      toast({
        title: "Upload failed",
        description: uploadErrorMessage(err),
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'approved': return <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200"><CheckCircle2 className="h-3 w-3 mr-1"/> Approved</Badge>;
      case 'rejected': return <Badge variant="destructive"><AlertCircle className="h-3 w-3 mr-1"/> Rejected</Badge>;
      default: return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1"/> Pending</Badge>;
    }
  };

  if (!isSeller) {
    return <RoleDenied message="Only exporters can manage documents." hint="Verification documents belong to an exporter profile." />;
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Document Center</h1>
          <p className="text-muted-foreground">Upload and manage verification documents for your readiness tier.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Upload Document</CardTitle>
                <CardDescription>Submit documents for review.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleUpload} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="docType">Document type</Label>
                    <Select value={docType} onValueChange={setDocType} required>
                      <SelectTrigger id="docType">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="business_registration">Business Registration</SelectItem>
                        <SelectItem value="tax_certificate">Tax Certificate</SelectItem>
                        <SelectItem value="export_license">Export License</SelectItem>
                        <SelectItem value="product_catalog">Product Catalog</SelectItem>
                        <SelectItem value="quality_certificate">Quality Certificate</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="file">File</Label>
                    <Input
                      id="file"
                      type="file"
                      required
                      accept=".pdf,.png,.jpg,.jpeg,.webp"
                      onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                    />
                    <p className="text-xs text-muted-foreground">PDF or image, up to 10MB.</p>
                  </div>
                  <Button type="submit" disabled={uploading || uploadDoc.isPending} className="w-full">
                    {uploading || uploadDoc.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UploadCloud className="mr-2 h-4 w-4" />}
                    {uploading ? "Uploading…" : "Submit Document"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>My Documents</CardTitle>
              </CardHeader>
              <CardContent>
                {docsLoading ? (
                  <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
                ) : docsError ? (
                  <ErrorState label="Couldn't load your documents" onRetry={() => refetchDocs()} />
                ) : documents?.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground border border-dashed rounded-md">
                    <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    No documents uploaded yet.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {documents?.map(doc => (
                      <div key={doc.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border rounded-lg gap-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-primary/10 p-2 rounded-md"><FileText className="h-5 w-5 text-primary" /></div>
                          <div>
                            <p className="font-medium text-sm break-words">{doc.fileName}</p>
                            <p className="text-xs text-muted-foreground mt-1 capitalize">{doc.documentType.replace('_', ' ')}</p>
                            {doc.status === 'rejected' && doc.rejectionReason && (
                              <p className="text-xs text-destructive mt-1">Reason: {doc.rejectionReason}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <a href={`/api/documents/${doc.id}/file`} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline">View File</a>
                          {getStatusBadge(doc.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}