import { formatTarget } from "@/lib/quote";
import { usePageMeta } from "@/hooks/use-page-meta";
import { Link } from "wouter";
import { useListRfqs, getListRfqsQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { RoleDenied } from "@/components/RoleDenied";
import { ErrorState } from "@/components/QueryState";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Inbox, MapPin, MessageSquare } from "lucide-react";

export default function RfqMarket() {
  usePageMeta("RFQ market");
  const { user: me, isLoading: meLoading } = useAuth();
  const params = { scope: "market" as const };
  const { data: rfqs, isLoading, isError, refetch } = useListRfqs(params, {
    query: { enabled: me?.role === "seller", queryKey: getListRfqsQueryKey(params) },
  });

  if (meLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div></Layout>;
  if (me?.role !== "seller") return <RoleDenied message="Only exporters can browse the RFQ market." hint="The market shows buyer requests matched to what you export." />;

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">RFQ Market</h1>
          <p className="text-muted-foreground">Open buyer requests matching your product categories.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load the RFQ market" onRetry={() => refetch()} />
        ) : !rfqs?.length ? (
          <div className="text-center py-12 border border-dashed rounded-lg text-muted-foreground">
            <Inbox className="h-8 w-8 mx-auto mb-2 opacity-50" />
            No open requests match your categories yet. Add categories to your profile to see more.
          </div>
        ) : (
          <div className="space-y-3">
            {rfqs.map((r) => (
              <Link key={r.id} href={`/rfqs/${r.id}`}>
                <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="min-w-0">
                        <h3 className="font-semibold">{r.title}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5">{r.buyerCompany || "A buyer"}</p>
                      </div>
                      {r.category && <Badge variant="secondary" className="shrink-0">{r.category}</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mt-2">{r.description}</p>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-3 text-xs text-muted-foreground">
                      {r.quantity && <span>Qty: {r.quantity}{r.unit ? ` ${r.unit}` : ""}</span>}
                      {formatTarget(r) && <span>Target: {formatTarget(r)}</span>}
                      {r.destinationCountry && <span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> {r.destinationCountry}</span>}
                      <span className="flex items-center gap-1 text-primary font-medium ml-auto"><MessageSquare className="h-3.5 w-3.5" /> Quote</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
