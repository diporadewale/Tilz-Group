import { usePageMeta } from "@/hooks/use-page-meta";
import {
  useGetMe,
  useListBuyerProfiles,
  useGetBuyerMatches,
  getListBuyerProfilesQueryKey,
  getGetBuyerMatchesQueryKey,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowRight } from "lucide-react";

export default function Matches() {
  usePageMeta("My matches");
  const { data: me } = useGetMe();
  const isBuyer = me?.role === "buyer";

  const {
    data: buyerProfiles,
    isLoading: profileLoading,
    isError: profileError,
    refetch: refetchProfile,
  } = useListBuyerProfiles(
    {},
    { query: { enabled: !!me?.id && isBuyer, queryKey: getListBuyerProfilesQueryKey({}) } },
  );
  const myProfile = buyerProfiles?.find((p) => p.userId === me?.id);
  const buyerProfileId = myProfile?.id || 0;

  const {
    data: matches,
    isLoading: matchesLoading,
    isError: matchesError,
    refetch: refetchMatches,
  } = useGetBuyerMatches(
    buyerProfileId,
    { query: { enabled: !!buyerProfileId, queryKey: getGetBuyerMatchesQueryKey(buyerProfileId) } },
  );

  const isLoading = profileLoading || matchesLoading;
  const isError = profileError || matchesError;
  const refetch = () => {
    if (profileError) refetchProfile();
    if (matchesError) refetchMatches();
  };

  if (!isBuyer && me) {
    return <Layout><div className="p-8 text-center">Only buyers have access to match recommendations.</div></Layout>;
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">My Matches</h1>
          <p className="text-muted-foreground">Smart exporter recommendations based on your sourcing profile.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load your matches" onRetry={() => refetch()} />
        ) : !myProfile ? (
          <Card className="py-12 text-center">
            <CardContent>
              <h3 className="text-lg font-medium">No buyer profile found</h3>
              <p className="text-muted-foreground mt-2">Complete your buyer profile to get personalized recommendations.</p>
              {/* This was a dead end: the only link to onboarding was the
                  post-signup redirect. */}
              <Button asChild className="mt-4">
                <Link href="/onboarding">Complete profile</Link>
              </Button>
            </CardContent>
          </Card>
        ) : !matches?.length ? (
          <Card className="py-12 text-center">
            <CardContent>
              <h3 className="text-lg font-medium">No matches yet</h3>
              <p className="text-muted-foreground mt-2">Update your interested categories and preferred origins to get recommendations.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {matches.map(({ seller, matchScore, matchReasons }) => (
              <Card key={seller.id} className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="p-6 flex-1">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold font-serif">{seller.companyName}</h3>
                        <p className="text-sm text-muted-foreground mt-1">{seller.country}</p>
                      </div>
                      <ReadinessBadge tier={seller.readinessTier} />
                    </div>
                    <p className="mt-4 text-sm line-clamp-2">{seller.description}</p>

                    <div className="mt-4">
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-2">Match Reasons</p>
                      <div className="flex flex-wrap gap-2">
                        {matchReasons.map((reason, i) => (
                          <Badge key={i} variant="secondary" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                            {reason}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="bg-muted/30 p-6 md:w-64 border-t md:border-t-0 md:border-l flex flex-col items-center justify-center text-center">
                    <div className="text-4xl font-bold text-primary mb-1">{matchScore}%</div>
                    <div className="text-sm font-medium text-muted-foreground mb-4">Match Score</div>
                    <Link href={`/sellers/${seller.id}`} className="w-full">
                      <Button className="w-full" variant="outline">
                        View Profile <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
