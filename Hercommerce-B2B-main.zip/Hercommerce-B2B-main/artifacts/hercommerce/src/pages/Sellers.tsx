import { usePageMeta } from "@/hooks/use-page-meta";
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { getListSellerProfilesQueryKey, useListSellerProfiles, type ListSellerProfilesTier } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { Stars } from "@/components/Stars";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Search, MapPin, Building2, BadgeCheck, ArrowRight } from "lucide-react";

function SellerAvatar({ name, logoUrl }: { name: string; logoUrl?: string | null }) {
  if (logoUrl) {
    return (
      <img
        src={logoUrl}
        alt={name}
        className="h-12 w-12 rounded-lg object-cover border shrink-0"
      />
    );
  }
  return (
    <div className="h-12 w-12 rounded-lg bg-primary/10 text-primary flex items-center justify-center font-bold text-lg shrink-0">
      {name.charAt(0).toUpperCase()}
    </div>
  );
}

export default function Sellers() {
  usePageMeta("Find exporters", "Browse verified exporters by category, country and readiness tier.");
  // Seed from the ?search= query so the landing-page hero search lands here.
  const [search, setSearch] = useState(
    () => new URLSearchParams(window.location.search).get("search") ?? "",
  );
  const params = new URLSearchParams(window.location.search);
  const [tier, setTier] = useState<string>(() => params.get("tier") ?? "all");
  const [country, setCountry] = useState<string>(() => params.get("country") ?? "all");

  // Keep the URL in step so a filtered directory can be shared, bookmarked and
  // survives a refresh. replaceState avoids polluting back-button history.
  useEffect(() => {
    const next = new URLSearchParams();
    if (search) next.set("search", search);
    if (tier !== "all") next.set("tier", tier);
    if (country !== "all") next.set("country", country);
    const qs = next.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }, [search, tier, country]);

  // The API used to truncate at a hard 200 with nothing in the response to say
  // so, which made the 201st exporter unreachable. Ask for one more than we
  // intend to show: if it comes back, there is another page.
  const [limit, setLimit] = useState(50);
  const listParams = {
    search: search || undefined,
    tier: tier !== "all" ? (tier as ListSellerProfilesTier) : undefined,
    country: country !== "all" ? country : undefined,
    limit: limit + 1,
  };
  const { data: page, isLoading, isError, refetch } = useListSellerProfiles(listParams, {
    query: { queryKey: getListSellerProfilesQueryKey(listParams) },
  });
  const hasMore = (page?.length ?? 0) > limit;
  const sellers = hasMore ? page?.slice(0, limit) : page;

  // Changing a filter restarts paging, otherwise a narrow filter would keep
  // requesting the deep page the previous filter had reached.
  useEffect(() => { setLimit(50); }, [search, tier, country]);

  // Unfiltered list purely to populate the country filter options.
  const { data: allSellers } = useListSellerProfiles();
  const countries = Array.from(
    new Set((allSellers ?? []).map((s) => s.country).filter(Boolean)),
  ).sort();

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Exporter Directory</h1>
          <p className="text-muted-foreground">Find and connect with verified exporters.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by company name…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={country} onValueChange={setCountry}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Country" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Countries</SelectItem>
              {countries.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={tier} onValueChange={setTier}>
            <SelectTrigger className="w-full sm:w-[160px]">
              <SelectValue placeholder="Readiness Tier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Tiers</SelectItem>
              <SelectItem value="platinum">Platinum</SelectItem>
              <SelectItem value="gold">Gold</SelectItem>
              <SelectItem value="silver">Silver</SelectItem>
              <SelectItem value="bronze">Bronze</SelectItem>
              <SelectItem value="unrated">Unrated</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : isError ? (
          <ErrorState label="Couldn't load exporters" onRetry={() => refetch()} />
        ) : !sellers?.length ? (
          <div className="text-center py-12 border rounded-lg bg-white">
            <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No exporters found</h3>
            <p className="text-muted-foreground">Try adjusting your search or filters.</p>
          </div>
        ) : (
          <>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <p className="text-sm text-muted-foreground">
              Showing {sellers.length} exporter{sellers.length === 1 ? "" : "s"}{hasMore ? " so far" : ""}
            </p>
            {(search || tier !== "all" || country !== "all") && (
              <button
                type="button"
                onClick={() => { setSearch(""); setTier("all"); setCountry("all"); }}
                className="text-sm text-primary hover:underline"
              >
                Clear filters
              </button>
            )}
          </div>
          <div className="grid gap-4 sm:gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {sellers.map((seller) => (
              <Link key={seller.id} href={`/sellers/${seller.id}`} className="group">
                <Card className="h-full flex flex-col p-5 transition-all hover:border-primary/50 hover:shadow-md cursor-pointer">
                  <div className="flex items-start gap-3">
                    <SellerAvatar name={seller.companyName} logoUrl={seller.logoUrl} />
                    <div className="min-w-0 flex-1">
                      <h3 className="font-semibold leading-tight line-clamp-2" title={seller.companyName}>
                        {seller.companyName}
                      </h3>
                      <div className="flex items-center text-xs text-muted-foreground mt-1">
                        <MapPin className="h-3.5 w-3.5 mr-1 shrink-0" />
                        <span className="truncate">
                          {seller.city ? `${seller.city}, ` : ""}{seller.country}
                        </span>
                      </div>
                    </div>
                    <ReadinessBadge tier={seller.readinessTier} />
                  </div>

                  {seller.reviewCount ? (
                    <div className="flex items-center gap-1.5 mt-3">
                      <Stars rating={seller.avgRating ?? 0} />
                      <span className="text-xs text-muted-foreground">{seller.avgRating} ({seller.reviewCount})</span>
                    </div>
                  ) : null}

                  <p className="text-sm text-muted-foreground line-clamp-2 mt-4 flex-1">
                    {seller.description || "No description provided."}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mt-4">
                    {(seller.categories || []).slice(0, 3).map((cat) => (
                      <Badge key={cat} variant="secondary" className="text-xs font-normal">{cat}</Badge>
                    ))}
                    {(seller.categories?.length || 0) > 3 && (
                      <Badge variant="secondary" className="text-xs font-normal">
                        +{seller.categories!.length - 3}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-4 border-t">
                    {seller.status === "approved" ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-600">
                        <BadgeCheck className="h-4 w-4" /> Verified
                      </span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Under review</span>
                    )}
                    <span className="inline-flex items-center gap-1 text-sm font-medium text-primary">
                      View profile
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
          {hasMore && (
            <div className="flex justify-center pt-6">
              <Button variant="outline" onClick={() => setLimit((n) => n + 50)}>
                Load more exporters
              </Button>
            </div>
          )}
          </>
        )}
      </div>
    </Layout>
  );
}
