import { usePageMeta } from "@/hooks/use-page-meta";
import { useState } from "react";
import { Link } from "wouter";
import { useListRfqs, useCreateRfq, useUpdateRfq, getListRfqsQueryKey, type RfqInputTargetCurrency } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { RoleDenied } from "@/components/RoleDenied";
import { failureReason } from "@/lib/server-error";
import { CountrySelect } from "@/components/SearchableSelect";
import { ErrorState } from "@/components/QueryState";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, FileText, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { CATEGORIES, UNITS, CURRENCIES } from "@/lib/catalog";

// Currency defaults to USD but is always shown beside the amount, so it is a
// visible choice rather than an assumption baked into the number.
const EMPTY = { title: "", category: "", description: "", quantity: "", unit: "", targetPrice: "", targetCurrency: "USD", destinationCountry: "" };

export default function Rfqs() {
  usePageMeta("My RFQs");
  const { user: me, isLoading: meLoading } = useAuth();
  const params = { scope: "mine" as const };
  const { data: rfqs, isLoading, isError, refetch } = useListRfqs(params, {
    query: { enabled: me?.role === "buyer", queryKey: getListRfqsQueryKey(params) },
  });
  const createRfq = useCreateRfq();
  const updateRfq = useUpdateRfq();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ ...EMPTY });
  const [showForm, setShowForm] = useState(false);
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.description) return;
    try {
      await createRfq.mutateAsync({
        data: {
          title: form.title,
          description: form.description,
          category: form.category || undefined,
          quantity: form.quantity || undefined,
          unit: form.unit || undefined,
          targetPrice: form.targetPrice || undefined,
          targetCurrency: form.targetPrice ? (form.targetCurrency as RfqInputTargetCurrency) : undefined,
          destinationCountry: form.destinationCountry || undefined,
        },
      });
      toast({ title: "RFQ posted", description: "Matching exporters can now quote." });
      setForm({ ...EMPTY });
      setShowForm(false);
      queryClient.invalidateQueries({ queryKey: getListRfqsQueryKey(params) });
    } catch (err) {
      toast({
        title: "Could not post RFQ",
        description: failureReason(err),
        variant: "destructive",
      });
    }
  };

  if (meLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div></Layout>;
  if (me?.role !== "buyer") return <RoleDenied message="Only buyers can post RFQs." hint="Requests for quote are posted from a buyer profile." />;

  return (
    <Layout>
      <div className="space-y-6 max-w-4xl mx-auto">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">My RFQs</h1>
            <p className="text-muted-foreground">Post what you're sourcing and receive quotes.</p>
          </div>
          <Button onClick={() => setShowForm((s) => !s)}><Plus className="h-4 w-4 mr-1" /> Post RFQ</Button>
        </div>

        {showForm && (
          <Card>
            <CardHeader>
              <CardTitle>New Request for Quote</CardTitle>
              <CardDescription>Exporters whose categories match will see this.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title <span className="text-destructive" aria-hidden="true">*</span></Label>
                  <Input id="title" required value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="e.g. 5 tonnes dried mango, monthly" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={form.category} onValueChange={(v) => set("category", v)}>
                      <SelectTrigger id="category"><SelectValue placeholder="Select category" /></SelectTrigger>
                      <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dest">Destination country</Label>
                    <CountrySelect id="dest" clearable value={form.destinationCountry} onChange={(v) => set("destinationCountry", v)} />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="qty">Quantity</Label>
                    <Input id="qty" inputMode="decimal" value={form.quantity} onChange={(e) => set("quantity", e.target.value)} placeholder="e.g. 5" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="unit">Unit</Label>
                    <Select value={form.unit} onValueChange={(v) => set("unit", v)}>
                      <SelectTrigger id="unit"><SelectValue placeholder="Select unit" /></SelectTrigger>
                      <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="target">Target price{form.unit ? ` per ${form.unit}` : ""}</Label>
                    {/* Sellers used to read a bare "Target: 4" and could not tell
                        dollars from pounds. The currency now travels with it. */}
                    <div className="flex gap-2">
                      <Select value={form.targetCurrency} onValueChange={(v) => set("targetCurrency", v)}>
                        <SelectTrigger className="w-24 shrink-0" aria-label="Target price currency">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>{CURRENCIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                      </Select>
                      <Input id="target" inputMode="decimal" value={form.targetPrice} onChange={(e) => set("targetPrice", e.target.value)} placeholder="e.g. 4.00" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="desc">Details <span className="text-destructive" aria-hidden="true">*</span></Label>
                  <Textarea id="desc" required rows={3} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="Specs, certifications, delivery terms…" />
                </div>
                <div className="flex justify-end gap-2">
                  <Button type="button" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
                  <Button type="submit" disabled={createRfq.isPending}>
                    {createRfq.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Post RFQ
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load your RFQs" onRetry={() => refetch()} />
        ) : !rfqs?.length ? (
          <div className="text-center py-12 border border-dashed rounded-lg text-muted-foreground">
            <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
            No RFQs yet. Post your first to start receiving quotes.
          </div>
        ) : (
          <div className="space-y-3">
            {rfqs.map((r) => (
              <Link key={r.id} href={`/rfqs/${r.id}`}>
                <Card className="hover:border-primary/50 transition-colors cursor-pointer">
                  <CardContent className="p-4 flex items-center justify-between gap-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold truncate">{r.title}</h3>
                        <Badge variant={r.status === "open" ? "secondary" : "outline"} className="capitalize shrink-0">{r.status}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {[r.category, r.quantity && `${r.quantity}${r.unit ? ` ${r.unit}` : ""}`, r.destinationCountry].filter(Boolean).join(" · ") || "N/A"}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className="flex items-center gap-1.5 text-sm font-medium text-primary">
                        <MessageSquare className="h-4 w-4" /> {r.quoteCount ?? 0} quote{(r.quoteCount ?? 0) === 1 ? "" : "s"}
                      </span>
                      {/* Close/Reopen already worked on the detail page, but from
                          the list an RFQ looked permanently Open. The card is a
                          Link, so this must not navigate. */}
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={updateRfq.isPending}
                        onClick={async (e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          const status = r.status === "open" ? "closed" : "open";
                          try {
                            await updateRfq.mutateAsync({ id: r.id, data: { status } });
                            toast({ title: status === "closed" ? "RFQ closed" : "RFQ reopened" });
                            queryClient.invalidateQueries({ queryKey: getListRfqsQueryKey(params) });
                          } catch (err) {
                            toast({ title: "Could not update this RFQ", description: failureReason(err), variant: "destructive" });
                          }
                        }}
                      >
                        {r.status === "open" ? "Close" : "Reopen"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
