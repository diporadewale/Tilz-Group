import {
  useListUsers,
  useUpdateUser,
  type ListUsersRole,
  type UserUpdateStatus,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Download, Search } from "lucide-react";
import { useGetMe } from "@workspace/api-client-react";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListUsersQueryKey } from "@workspace/api-client-react";

export default function AdminUsers() {
  const { data: me } = useGetMe();
  const [search, setSearch] = useState("");
  const [role, setRole] = useState<string>("all");
  
  const { data: users, isLoading, isError, refetch } = useListUsers({
    search: search || undefined,
    role: role !== "all" ? (role as ListUsersRole) : undefined
  });
  
  const updateUser = useUpdateUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleExport = async () => {
    try {
      const params = new URLSearchParams();
      if (role !== "all") params.set("role", role);
      const resp = await fetch(`${import.meta.env.BASE_URL}api/admin/exports/users?${params}`);
      if (!resp.ok) throw new Error("Export failed");
      const csvData = await resp.text();
      const blob = new Blob([csvData], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `users_export_${format(new Date(), 'yyyyMMdd')}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      toast({ title: "Export failed", variant: "destructive" });
    }
  };

  const handleStatusChange = async (userId: number, status: UserUpdateStatus) => {
    try {
      await updateUser.mutateAsync({ id: userId, data: { status } });
      toast({ title: "Status updated" });
      queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
    } catch (e) {
      toast({ title: "Failed to update", variant: "destructive" });
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-6xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Manage Users</h1>
          </div>
          <Button onClick={handleExport} variant="outline"><Download className="mr-2 h-4 w-4" /> Export CSV</Button>
        </div>

        <Card className="p-4 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input type="search" aria-label="Search users by email or name" placeholder="Search email or name..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={role} onValueChange={setRole}>
            {/* Full width once the filter bar stacks on mobile, matching the
                exporter and product directories. */}
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter by Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="buyer">Buyer</SelectItem>
              <SelectItem value="seller">Seller</SelectItem>
              <SelectItem value="admin">Admin</SelectItem>
            </SelectContent>
          </Select>
        </Card>

        {/* A 6-column table on a 375px screen scrolled sideways inside its own
            box, and Actions was the rightmost column, so the status control was
            the part hidden off-screen. Below md each row becomes a card with
            that control full-width at the bottom. Handling the loading, error
            and empty states out here also drops the colSpan rows the table
            needed to host them. */}
        {isLoading ? (
          <Card className="flex justify-center p-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </Card>
        ) : isError ? (
          <ErrorState label="Couldn't load users" onRetry={() => refetch()} />
        ) : !users?.length ? (
          <Card className="p-12 text-center text-muted-foreground">No users found.</Card>
        ) : (
          <>
            <div className="space-y-3 md:hidden">
              {users.map((u) => (
                <Card key={u.id} className="space-y-3 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-medium truncate">{u.firstName} {u.lastName}</p>
                      <p className="text-xs text-muted-foreground break-all">{u.email}</p>
                    </div>
                    <Badge
                      variant={u.status === "approved" ? "default" : u.status === "suspended" ? "destructive" : "secondary"}
                      className="capitalize shrink-0"
                    >
                      {u.status}
                    </Badge>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    <Badge variant="outline" className="capitalize">{u.role}</Badge>
                    <span>Joined {format(new Date(u.createdAt), "MMM d, yyyy")}</span>
                  </div>
                  <Select
                    value={u.status}
                    disabled={u.id === me?.id}
                    onValueChange={(val) => handleStatusChange(u.id, val as UserUpdateStatus)}
                  >
                    {/* h-11 for a 44px tap target, rather than the h-8 that suits a dense table row. */}
                    <SelectTrigger className="h-11 w-full">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                    </SelectContent>
                  </Select>
                  {u.id === me?.id && (
                    <p className="text-xs text-muted-foreground">You cannot change your own account status.</p>
                  )}
                </Card>
              ))}
            </div>

            <Card className="hidden md:block">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell>
                        <div className="font-medium">{u.firstName} {u.lastName}</div>
                        <div className="text-xs text-muted-foreground">{u.email}</div>
                      </TableCell>
                      <TableCell><Badge variant="outline" className="capitalize">{u.role}</Badge></TableCell>
                      <TableCell className="text-sm text-muted-foreground">{format(new Date(u.createdAt), "MMM d, yyyy")}</TableCell>
                      <TableCell>
                        <Badge
                          variant={u.status === "approved" ? "default" : u.status === "suspended" ? "destructive" : "secondary"}
                          className="capitalize"
                        >
                          {u.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        {/* The API refuses to let an admin suspend or demote
                            themselves, but the control stayed live, so the only
                            feedback was an error after the fact. */}
                        <Select
                          value={u.status}
                          disabled={u.id === me?.id}
                          onValueChange={(val) => handleStatusChange(u.id, val as UserUpdateStatus)}
                        >
                          <SelectTrigger
                            className="ml-auto h-8 w-[120px] text-xs"
                            title={u.id === me?.id ? "You cannot change your own account status" : undefined}
                          >
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="approved">Approved</SelectItem>
                            <SelectItem value="suspended">Suspended</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </>
        )}
      </div>
    </Layout>
  );
}