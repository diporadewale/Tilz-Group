import { failureReason, isRateLimited } from "@/lib/server-error";
import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useRegister, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { PasswordInput } from "@/components/PasswordInput";
import { GoogleSignInButton } from "@/components/GoogleSignInButton";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function Register() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const register = useRegister();
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  // Honour ?role= from the entry CTA so the choice the user already made on the
  // homepage or footer isn't discarded. Defaults to buyer.
  const [role, setRole] = useState<"buyer" | "seller">(() => {
    const requested = new URLSearchParams(window.location.search).get("role");
    return requested === "seller" ? "seller" : "buyer";
  });
  const [acceptedTerms, setAcceptedTerms] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError("Those passwords don't match.");
      return;
    }
    register.mutate(
      { data: { email, password, firstName, lastName, role } },
      {
        onSuccess: async () => {
          await queryClient.invalidateQueries({
            queryKey: getGetMeQueryKey(),
          });
          setLocation("/onboarding");
        },
        onError: (err) => {
          const status = (err as { status?: number })?.status;
          setError(
            isRateLimited(err)
              ? failureReason(err)
              : status === 409
                ? "That email is already registered."
                : "Could not create your account. Please try again.",
          );
        },
      },
    );
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {/* The logo was a bare <img>; these pages had no header, no footer
              and no link back to the site; the only exit was the back button. */}
          <Link href="/">
            <img
              src={`${basePath}/logo.svg`}
              alt="Originance home"
              className="h-10 mx-auto mb-4 cursor-pointer"
            />
          </Link>
          <CardTitle className="text-2xl font-serif">Join Originance</CardTitle>
          <CardDescription>Connect with global trade partners</CardDescription>
        </CardHeader>
        <CardContent>
          <GoogleSignInButton role={role} label="Sign up with Google" />
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <span className="text-sm font-medium">I want to join as</span>
              <div className="grid grid-cols-2 gap-3" role="radiogroup" aria-label="Account type">
                {([
                  { value: "buyer", label: "Buyer", hint: "I source products" },
                  { value: "seller", label: "Exporter", hint: "I sell products" },
                ] as const).map((opt) => (
                  <button
                    key={opt.value}
                    type="button"
                    role="radio"
                    aria-checked={role === opt.value}
                    onClick={() => setRole(opt.value)}
                    className={`rounded-lg border p-3 text-left transition-colors ${
                      role === opt.value
                        ? "border-primary bg-primary/5 ring-1 ring-primary"
                        : "border-input hover:bg-muted"
                    }`}
                  >
                    <span className="block text-sm font-medium">{opt.label}</span>
                    <span className="block text-xs text-muted-foreground">{opt.hint}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First name</Label>
                <Input
                  id="firstName"
                  autoComplete="given-name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last name</Label>
                <Input
                  id="lastName"
                  autoComplete="family-name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <PasswordInput
                id="password"
                autoComplete="new-password"
                required
                minLength={8}
                value={password}
                onChange={setPassword}
              />
              <p className="text-xs text-muted-foreground">
                At least 8 characters.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm password</Label>
              <PasswordInput
                id="confirmPassword"
                autoComplete="new-password"
                required
                minLength={8}
                value={confirm}
                onChange={setConfirm}
              />
              {confirm && password !== confirm && (
                <p className="text-xs text-destructive">Passwords don't match.</p>
              )}
            </div>
            <div className="flex items-start gap-2">
              <input
                id="terms"
                type="checkbox"
                required
                checked={acceptedTerms}
                onChange={(e) => setAcceptedTerms(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-input accent-primary"
              />
              <Label htmlFor="terms" className="text-xs font-normal text-muted-foreground leading-relaxed">
                I agree to the <Link href="/terms" className="text-primary hover:underline">Terms of Service</Link>
                {" "}and <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>.
              </Label>
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button
              type="submit"
              className="w-full"
              disabled={register.isPending || !acceptedTerms}
            >
              {register.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Create account
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Already have an account?{" "}
            <Link
              href="/sign-in"
              className="font-medium text-primary hover:underline"
            >
              Sign in
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
