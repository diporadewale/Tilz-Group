import { useEffect, useRef, useState } from "react";
import { Link, useSearchParams } from "wouter";
import { useVerifyEmail, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Loader2, CheckCircle2, XCircle } from "lucide-react";

export default function VerifyEmail() {
  const [params] = useSearchParams();
  const token = params.get("token") ?? "";
  const verify = useVerifyEmail();
  const queryClient = useQueryClient();
  const [status, setStatus] = useState<"pending" | "ok" | "error">("pending");
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    if (!token) {
      setStatus("error");
      return;
    }
    verify.mutate(
      { data: { token } },
      {
        onSuccess: async () => {
          await queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
          setStatus("ok");
        },
        onError: () => setStatus("error"),
      },
    );
  }, [token, verify, queryClient]);

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-serif">Email verification</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          {status === "pending" && (
            <div className="flex flex-col items-center gap-3 text-muted-foreground">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-sm">Verifying your email…</p>
            </div>
          )}
          {status === "ok" && (
            <div className="flex flex-col items-center gap-3">
              <CheckCircle2 className="h-10 w-10 text-primary" />
              <p className="text-sm text-muted-foreground">
                Your email is verified. Thanks!
              </p>
              <Link
                href="/dashboard"
                className="text-sm font-medium text-primary hover:underline"
              >
                Go to dashboard
              </Link>
            </div>
          )}
          {status === "error" && (
            <div className="flex flex-col items-center gap-3">
              <XCircle className="h-10 w-10 text-destructive" />
              <p className="text-sm text-muted-foreground">
                This verification link is invalid or has expired. Sign in and
                request a new one from the banner.
              </p>
              <Link
                href="/sign-in"
                className="text-sm font-medium text-primary hover:underline"
              >
                Sign in
              </Link>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
