import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  useGetMe,
  useCreateSellerProfile,
  useCreateBuyerProfile,
  useExtractOnboardingIntent,
  useGetClientConfig,
  getGetMeQueryKey,
  getGetClientConfigQueryKey,
} from "@workspace/api-client-react";
import {
  CATEGORIES,
  COUNTRIES,
  CERTIFICATIONS,
  REVENUE_BANDS,
  EMPLOYEE_BANDS,
  BUDGET_BANDS,
} from "@workspace/vocab";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Store, ShoppingBag, Sparkles } from "lucide-react";
import { CountrySelect } from "@/components/SearchableSelect";
// The shared picker. Onboarding used to carry its own copy, which lacked
// aria-pressed, so a screen reader could not tell a chip was a toggle.
import { ChipSelect } from "@/components/ChipSelect";
import { ALL_COUNTRIES } from "@workspace/vocab";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

// Vocabularies come from @workspace/vocab, the same lists the API server uses
// to build the intent-extraction schema and the matcher scores against. Aliased
// here so the JSX below keeps reading the way it did.
const REVENUE = REVENUE_BANDS;
const EMPLOYEES = EMPLOYEE_BANDS;
const BUDGET = BUDGET_BANDS;

export default function Onboarding() {
  const [, setLocation] = useLocation();
  const { data: me, isLoading: meLoading } = useGetMe({
    query: { retry: false, queryKey: getGetMeQueryKey() },
  });
  const createSeller = useCreateSellerProfile();
  const createBuyer = useCreateBuyerProfile();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [step, setStep] = useState(1);
  const [role, setRole] = useState<"seller" | "buyer" | null>(null);
  const [form, setForm] = useState({
    companyName: "",
    country: "",
    city: "",
    description: "",
    // seller
    categories: [] as string[],
    certifications: [] as string[],
    exportMarkets: [] as string[],
    annualRevenue: "",
    employeeCount: "",
    // buyer
    interestedCategories: [] as string[],
    preferredOrigins: [] as string[],
    annualBudget: "",
  });

  const set = <K extends keyof typeof form>(key: K, val: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [key]: val }));

  // ── Intent assist ──────────────────────────────────────────────────────────
  // Optional: only rendered when the server reports an Anthropic key is
  // configured, so a deployment without one behaves as if this never existed.
  const { data: clientConfig } = useGetClientConfig({
    query: { queryKey: getGetClientConfigQueryKey(), staleTime: Infinity },
  });
  const extractIntent = useExtractOnboardingIntent();
  const [pitch, setPitch] = useState("");
  const [suggested, setSuggested] = useState<Set<string>>(new Set());

  const handleSuggest = async () => {
    const text = pitch.trim();
    if (!role || text.length < 12) {
      toast({
        title: "Tell us a little more",
        description: "A sentence or two about what you buy or sell is enough.",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await extractIntent.mutateAsync({ data: { role, text } });

      // Merge rather than replace, anything already chosen by hand stays.
      const merge = (current: string[], incoming: string[] | undefined) =>
        Array.from(new Set([...current, ...(incoming ?? [])]));

      const marks = new Set<string>();
      const mark = (values: string[] | undefined) => (values ?? []).forEach((v) => marks.add(v));

      setForm((f) => {
        const next = { ...f };
        if (role === "seller") {
          next.categories = merge(f.categories, result.categories);
          next.certifications = merge(f.certifications, result.certifications);
          next.exportMarkets = merge(f.exportMarkets, result.exportMarkets);
          if (!f.annualRevenue && result.annualRevenue) next.annualRevenue = result.annualRevenue;
          if (!f.employeeCount && result.employeeCount) next.employeeCount = result.employeeCount;
        } else {
          next.interestedCategories = merge(f.interestedCategories, result.categories);
          next.preferredOrigins = merge(f.preferredOrigins, result.origins);
          if (!f.annualBudget && result.annualBudget) next.annualBudget = result.annualBudget;
        }
        if (!f.country && result.country) next.country = result.country;
        if (!f.description) next.description = text;
        return next;
      });

      mark(result.categories);
      mark(role === "seller" ? result.certifications : result.origins);
      if (role === "seller") mark(result.exportMarkets);
      setSuggested(marks);

      if (marks.size === 0) {
        toast({
          title: "Nothing matched",
          description: "We couldn't map that to our categories, so please pick them below.",
        });
      } else {
        toast({
          title: `${marks.size} suggestion${marks.size === 1 ? "" : "s"} added`,
          description: "Highlighted below. Remove anything that doesn't fit.",
        });
      }
    } catch {
      // FR-008: onboarding must stay usable when this dependency is down.
      toast({
        title: "Couldn't read that",
        description: "Fill the fields in below. Nothing else is affected.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    if (me && me.role && me.status === "approved") {
      setLocation("/dashboard");
    }
  }, [me, setLocation]);

  const handleRoleSelect = (selectedRole: "seller" | "buyer") => {
    setRole(selectedRole);
    setStep(2);
  };

  const submitting = createSeller.isPending || createBuyer.isPending;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!me?.id || !role) return;

    // Country was a native `required` input. The combobox that replaced it has
    // no native validation, so the check has to be explicit.
    if (!form.country) {
      toast({ title: "Choose your country", variant: "destructive" });
      return;
    }

    // Guard the fields the matching algorithm depends on.
    if (role === "seller" && form.categories.length === 0) {
      toast({ title: "Pick at least one category", description: "Buyers find you by category.", variant: "destructive" });
      return;
    }
    if (role === "buyer" && form.interestedCategories.length === 0) {
      toast({ title: "Pick at least one category", description: "We match you to exporters by category.", variant: "destructive" });
      return;
    }

    try {
      if (role === "seller") {
        await createSeller.mutateAsync({
          data: {
            companyName: form.companyName,
            country: form.country,
            city: form.city || undefined,
            description: form.description || undefined,
            categories: form.categories,
            certifications: form.certifications,
            exportMarkets: form.exportMarkets,
            annualRevenue: form.annualRevenue || undefined,
            employeeCount: form.employeeCount || undefined,
          },
        });
      } else {
        await createBuyer.mutateAsync({
          data: {
            companyName: form.companyName,
            country: form.country,
            city: form.city || undefined,
            description: form.description || undefined,
            interestedCategories: form.interestedCategories,
            preferredOrigins: form.preferredOrigins,
            annualBudget: form.annualBudget || undefined,
          },
        });
      }

      await queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
      toast({ title: "Profile created", description: "Welcome to Originance!" });
      setLocation("/dashboard");
    } catch {
      toast({ title: "Error", description: "Failed to create profile.", variant: "destructive" });
    }
  };

  if (meLoading) {
    return (
      <div className="flex min-h-[100dvh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-muted/30 p-4">
      <div className="w-full max-w-2xl py-8">
        <div className="mb-8 text-center">
          <img src={`${import.meta.env.BASE_URL.replace(/\/$/, "")}/logo.svg`} alt="Originance" className="h-12 mx-auto mb-4" />
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-foreground">Welcome to Originance</h1>
          <p className="text-muted-foreground mt-2">Let's set up your profile to get started.</p>
        </div>

        {step === 1 && (
          <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
            <Card className="cursor-pointer hover:border-primary transition-colors hover:shadow-md" onClick={() => handleRoleSelect("buyer")}>
              <CardHeader className="text-center pb-2">
                <ShoppingBag className="w-12 h-12 mx-auto text-primary mb-4" />
                <CardTitle>I am a Buyer</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-sm text-muted-foreground">
                I want to source products from verified exporters in emerging markets.
              </CardContent>
            </Card>

            <Card className="cursor-pointer hover:border-primary transition-colors hover:shadow-md" onClick={() => handleRoleSelect("seller")}>
              <CardHeader className="text-center pb-2">
                <Store className="w-12 h-12 mx-auto text-primary mb-4" />
                <CardTitle>I am an Exporter</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-sm text-muted-foreground">
                I want to showcase my products and connect with international buyers.
              </CardContent>
            </Card>
          </div>
        )}

        {step === 2 && (
          <Card>
            <CardHeader>
              <CardTitle>{role === "seller" ? "Exporter Profile" : "Buyer Profile"}</CardTitle>
              <CardDescription>
                {role === "seller"
                  ? "Tell buyers about your business and what you export."
                  : "Tell us what you're sourcing so we can match you to exporters."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Intent assist. Hidden entirely when the deployment has no
                  Anthropic key, so the control never appears unless it works. */}
              {clientConfig?.intentAssist && (
                <div className="mb-6 rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <Sparkles className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-sm">Start with a description</p>
                      <p className="text-sm text-muted-foreground">
                        {role === "seller"
                          ? "Describe what you export and we'll pre-select your categories, certifications and markets below."
                          : "Describe what you're sourcing and we'll pre-select your categories and preferred origins below."}
                      </p>
                    </div>
                  </div>
                  <Textarea
                    rows={3}
                    value={pitch}
                    maxLength={2000}
                    onChange={(e) => setPitch(e.target.value)}
                    placeholder={
                      role === "seller"
                        ? "e.g. We export organic dried mango and cashews from Ghana, Fair Trade certified, mainly to Germany and the Netherlands."
                        : "e.g. We source organic dried fruit and spices from West Africa for the UK retail market, budget around $2M a year."
                    }
                  />
                  <div className="flex flex-wrap items-center gap-3">
                    <Button
                      type="button"
                      size="sm"
                      onClick={handleSuggest}
                      disabled={extractIntent.isPending || pitch.trim().length < 12}
                    >
                      {extractIntent.isPending ? (
                        <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Reading…</>
                      ) : (
                        <><Sparkles className="mr-2 h-4 w-4" /> Suggest from description</>
                      )}
                    </Button>
                    <span className="text-xs text-muted-foreground">
                      Suggestions only. You review everything before saving.
                    </span>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company name <span className="text-destructive" aria-hidden="true">*</span></Label>
                  <Input id="companyName" required autoComplete="organization" value={form.companyName} onChange={(e) => set("companyName", e.target.value)} />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="country">Country <span className="text-destructive" aria-hidden="true">*</span></Label>
                    <CountrySelect id="country" value={form.country} onChange={(v) => set("country", v)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input id="city" autoComplete="address-level2" value={form.city} onChange={(e) => set("city", e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Company description</Label>
                  <Textarea id="description" value={form.description} onChange={(e) => set("description", e.target.value)} />
                </div>

                {role === "seller" ? (
                  <>
                    <div className="space-y-2">
                      <Label id="lbl-categories">Product categories <span className="text-destructive" aria-hidden="true">*</span></Label>
                      <ChipSelect labelledBy="lbl-categories" options={CATEGORIES} value={form.categories} onChange={(v) => set("categories", v)} suggested={suggested} />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-markets">Export markets</Label>
                      <ChipSelect labelledBy="lbl-markets" options={COUNTRIES} moreOptions={ALL_COUNTRIES} moreLabel="Add another country" value={form.exportMarkets} onChange={(v) => set("exportMarkets", v)} suggested={suggested} />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-certs">Certifications</Label>
                      <ChipSelect labelledBy="lbl-certs" options={CERTIFICATIONS} value={form.certifications} onChange={(v) => set("certifications", v)} suggested={suggested} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="annualRevenue">Annual revenue</Label>
                        <Select value={form.annualRevenue} onValueChange={(v) => set("annualRevenue", v)}>
                          <SelectTrigger id="annualRevenue"><SelectValue placeholder="Select range" /></SelectTrigger>
                          <SelectContent>{REVENUE.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="employeeCount">Employees</Label>
                        <Select value={form.employeeCount} onValueChange={(v) => set("employeeCount", v)}>
                          <SelectTrigger id="employeeCount"><SelectValue placeholder="Select size" /></SelectTrigger>
                          <SelectContent>{EMPLOYEES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label id="lbl-sourcing">Categories you source <span className="text-destructive" aria-hidden="true">*</span></Label>
                      <ChipSelect labelledBy="lbl-sourcing" options={CATEGORIES} value={form.interestedCategories} onChange={(v) => set("interestedCategories", v)} suggested={suggested} />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-origins">Preferred origins</Label>
                      <ChipSelect labelledBy="lbl-origins" options={COUNTRIES} moreOptions={ALL_COUNTRIES} moreLabel="Add another country" value={form.preferredOrigins} onChange={(v) => set("preferredOrigins", v)} suggested={suggested} />
                    </div>
                    <div className="space-y-2 sm:max-w-xs">
                      <Label htmlFor="annualBudget">Annual sourcing budget</Label>
                      <Select value={form.annualBudget} onValueChange={(v) => set("annualBudget", v)}>
                        <SelectTrigger id="annualBudget"><SelectValue placeholder="Select range" /></SelectTrigger>
                        <SelectContent>{BUDGET.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                <div className="pt-2 flex flex-col-reverse sm:flex-row sm:justify-between gap-3">
                  <Button type="button" variant="outline" onClick={() => setStep(1)}>Back</Button>
                  <Button type="submit" disabled={submitting}>
                    {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Complete Profile
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
