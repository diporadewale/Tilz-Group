import { useGetAdminStats } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Users, Building2, ShoppingBag, FileText, AlertCircle } from "lucide-react";
import { Link } from "wouter";

const plural = (n: number, noun: string) => `${n} ${noun}${n === 1 ? "" : "s"}`;

export default function AdminDashboard() {
  const { data: stats, isLoading, isError, refetch } = useGetAdminStats();

  if (isLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></Layout>;
  // Every tile on this page reads from `stats`; without this the whole console
  // rendered as a grid of blanks when the request failed.
  if (isError) {
    return (
      <Layout>
        <div className="max-w-6xl mx-auto">
          <ErrorState label="Couldn't load platform stats" onRetry={() => refetch()} />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6 max-w-6xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Admin Console</h1>
          <p className="text-muted-foreground">Platform overview and pending review queues.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
              <Users className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.totalUsers || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">+{stats?.recentSignups || 0} recent</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Exporters</CardTitle>
              <Building2 className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.totalSellers || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">{stats?.approvedSellers || 0} approved</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Buyers</CardTitle>
              <ShoppingBag className="h-4 w-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stats?.totalBuyers || 0}</div>
              <p className="text-xs text-muted-foreground mt-1">{stats?.totalEnquiries || 0} enquiries sent</p>
            </CardContent>
          </Card>
          {/* The card was a dead end: not clickable, and the pending-profiles
              half had no screen anywhere in the admin nav. Both halves now live
              on the review queue. Also pluralises properly: it read "1 docs". */}
          <Link href="/admin/documents" className="block">
            <Card className="border-amber-200 bg-amber-50/50 h-full transition-colors hover:bg-amber-50">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-amber-800">Action Required</CardTitle>
                <AlertCircle className="h-4 w-4 text-amber-600" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-amber-900">{(stats?.pendingDocuments || 0) + (stats?.pendingProfiles || 0)}</div>
                <p className="text-xs text-amber-700 mt-1">
                  {plural(stats?.pendingDocuments || 0, "document")}, {plural(stats?.pendingProfiles || 0, "profile")}
                </p>
              </CardContent>
            </Card>
          </Link>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
           <Card>
             <CardHeader>
               <CardTitle>Quick Links</CardTitle>
             </CardHeader>
             <CardContent className="grid gap-2">
                <Link href="/admin/users" className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3 font-medium"><Users className="h-5 w-5 text-muted-foreground" /> Manage Users</div>
                </Link>
                <Link href="/admin/sellers" className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3 font-medium"><Building2 className="h-5 w-5 text-muted-foreground" /> Manage Exporters</div>
                </Link>
                <Link href="/admin/documents" className="flex items-center justify-between p-3 border rounded-md hover:bg-muted/50 transition-colors">
                  <div className="flex items-center gap-3 font-medium"><FileText className="h-5 w-5 text-muted-foreground" /> Review Queue</div>
                  {(stats?.pendingDocuments || 0) + (stats?.pendingProfiles || 0) ? <div className="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded-full">{(stats?.pendingDocuments || 0) + (stats?.pendingProfiles || 0)}</div> : null}
                </Link>
             </CardContent>
           </Card>

           <Card>
             <CardHeader>
               <CardTitle>Readiness Tiers</CardTitle>
             </CardHeader>
             <CardContent>
                <div className="space-y-4">
                  {Object.entries(stats?.tierBreakdown || {}).map(([tier, count]) => (
                    <div key={tier} className="flex items-center justify-between">
                      <div className="capitalize font-medium text-sm">{tier}</div>
                      <div className="flex items-center gap-3">
                         <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                           <div className="h-full bg-primary" style={{ width: `${Math.min(100, (Number(count) / (stats?.approvedSellers || 1)) * 100)}%` }} />
                         </div>
                         <div className="text-sm w-8 text-right">{String(count)}</div>
                      </div>
                    </div>
                  ))}
                </div>
             </CardContent>
           </Card>
        </div>
      </div>
    </Layout>
  );
}