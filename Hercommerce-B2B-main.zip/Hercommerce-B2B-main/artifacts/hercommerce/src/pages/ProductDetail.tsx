import { useParams, Link } from "wouter";
import {
  useGetProduct,
  useGetSellerProfile,
  getGetProductQueryKey,
  getGetSellerProfileQueryKey,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { usePageMeta } from "@/hooks/use-page-meta";
import { formatPrice } from "@/lib/catalog";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, Package, MapPin, MessageSquare } from "lucide-react";

// Sellers could write a product description from the day products shipped, and
// no buyer could ever read one: the field was captured, validated and stored,
// but rendered nowhere. The two card grids have no room for it, so this is
// where it goes, along with the full-size photo.
export default function ProductDetail() {
  const { id } = useParams();
  const productId = parseInt(id || "0", 10);

  const { data: product, isLoading, isError, refetch } = useGetProduct(productId, {
    query: { enabled: !!productId, queryKey: getGetProductQueryKey(productId) },
  });

  const sellerId = product?.sellerId;
  const { data: seller } = useGetSellerProfile(sellerId ?? 0, {
    query: { enabled: !!sellerId, queryKey: getGetSellerProfileQueryKey(sellerId ?? 0) },
  });

  usePageMeta(product?.name, product?.description ?? undefined);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
      </Layout>
    );
  }
  if (isError) {
    return <Layout><ErrorState label="Couldn't load this product" onRetry={() => refetch()} /></Layout>;
  }
  if (!product) {
    return (
      <Layout>
        <div className="max-w-md mx-auto text-center py-16 space-y-4">
          <Package className="h-10 w-10 mx-auto text-muted-foreground opacity-40" />
          <h1 className="text-xl font-semibold">Product not found</h1>
          <p className="text-sm text-muted-foreground">It may have been removed by the exporter.</p>
          <Button asChild><Link href="/products">Browse products</Link></Button>
        </div>
      </Layout>
    );
  }

  const price = formatPrice(product);

  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-6">
        <Link href="/products" className="text-sm text-muted-foreground hover:text-primary">
          ← Back to Products
        </Link>

        <div className="grid gap-6 md:grid-cols-2">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full rounded-xl border object-cover aspect-[4/3] max-w-full"
            />
          ) : (
            <div className="w-full rounded-xl border bg-muted flex items-center justify-center aspect-[4/3]">
              <Package className="h-10 w-10 text-muted-foreground opacity-40" />
            </div>
          )}

          <div className="space-y-4">
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight break-words">{product.name}</h1>
              {product.category && (
                <Badge variant="secondary" className="mt-2 font-normal">{product.category}</Badge>
              )}
            </div>

            <dl className="grid grid-cols-2 gap-4 border-y py-4 text-sm">
              <div>
                <dt className="text-xs font-medium text-muted-foreground">Price</dt>
                <dd className="font-medium text-primary">{price || "On request"}</dd>
              </div>
              <div>
                <dt className="text-xs font-medium text-muted-foreground">Minimum order</dt>
                <dd className="font-medium">
                  {product.moq != null ? `${product.moq}${product.unit ? ` ${product.unit}` : ""}` : "Not specified"}
                </dd>
              </div>
            </dl>

            {seller && (
              <Card>
                <CardContent className="pt-6 space-y-3">
                  <p className="text-xs font-medium text-muted-foreground">Supplied by</p>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <Link href={`/sellers/${seller.id}`} className="font-semibold hover:text-primary break-words">
                        {seller.companyName}
                      </Link>
                      <p className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                        <MapPin className="h-3.5 w-3.5 shrink-0" />
                        {seller.city ? `${seller.city}, ` : ""}{seller.country}
                      </p>
                    </div>
                    <ReadinessBadge tier={seller.readinessTier} />
                  </div>
                  <Button asChild className="w-full">
                    <Link href={`/sellers/${seller.id}#enquiry`}>
                      <MessageSquare className="mr-2 h-4 w-4" /> Enquire about this product
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        <Card>
          <CardContent className="pt-6">
            <h2 className="font-semibold mb-2">Description</h2>
            {product.description ? (
              <p className="text-sm text-muted-foreground whitespace-pre-wrap break-words">{product.description}</p>
            ) : (
              <p className="text-sm text-muted-foreground/60 italic">
                The exporter hasn't added a description for this product yet.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
