import { usePageMeta } from "@/hooks/use-page-meta";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Compass, Search } from "lucide-react";

// This page shipped to production as a developer placeholder ("Did you forget
// to add the page to the router?") with no chrome and no way out. It now uses
// the normal Layout, so it carries the header/nav for whoever is signed in, and
// offers real next steps.
export default function NotFound() {
  usePageMeta("Page not found");
  const [, setLocation] = useLocation();
  const [query, setQuery] = useState("");

  const search = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    setLocation(q ? `/sellers?search=${encodeURIComponent(q)}` : "/sellers");
  };

  return (
    <Layout>
      <div className="max-w-lg mx-auto text-center py-12 space-y-6">
        <div className="mx-auto h-14 w-14 rounded-full bg-primary/10 flex items-center justify-center">
          <Compass className="h-7 w-7 text-primary" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">
            We couldn't find that page
          </h1>
          <p className="text-muted-foreground">
            The link may be out of date, or the page may have moved.
          </p>
        </div>

        <form onSubmit={search} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search exporters…"
              aria-label="Search exporters"
            />
          </div>
          <Button type="submit">Search</Button>
        </form>

        <div className="flex flex-wrap gap-3 justify-center pt-2">
          <Button asChild variant="outline">
            <Link href="/">Go home</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/sellers">Browse exporters</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/products">Browse products</Link>
          </Button>
        </div>
      </div>
    </Layout>
  );
}
