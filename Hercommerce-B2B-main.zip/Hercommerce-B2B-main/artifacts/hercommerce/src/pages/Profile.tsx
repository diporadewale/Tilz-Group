import { usePageMeta } from "@/hooks/use-page-meta";
import {
  useGetMe,
  useUpdateSellerProfile,
  useUpdateBuyerProfile,
  useListSellerProfiles,
  useListBuyerProfiles,
  getListSellerProfilesQueryKey,
  getListBuyerProfilesQueryKey,
} from "@workspace/api-client-react";
import { Link } from "wouter";
import { Layout } from "@/components/Layout";
import { ChipSelect } from "@/components/ChipSelect";
import { CountrySelect } from "@/components/SearchableSelect";
import { ALL_COUNTRIES } from "@workspace/vocab";
import {
  CATEGORIES,
  COUNTRIES,
  CERTIFICATIONS,
  REVENUE_BANDS,
  EMPLOYEE_BANDS,
  BUDGET_BANDS,
} from "@workspace/vocab";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ErrorState } from "@/components/QueryState";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function Profile() {
  usePageMeta("My profile");
  const { data: me, isLoading: meLoading } = useGetMe();
  const isSeller = me?.role === "seller";

  const { data: sellerProfiles, isLoading: sellerLoading, isError: sellerError, refetch: refetchSeller } = useListSellerProfiles(
    {},
    { query: { enabled: !!me?.id && isSeller, queryKey: getListSellerProfilesQueryKey({}) } },
  );
  const sellerProfile = sellerProfiles?.find((p) => p.userId === me?.id);

  const { data: buyerProfiles, isLoading: buyerLoading, isError: buyerError, refetch: refetchBuyer } = useListBuyerProfiles(
    {},
    { query: { enabled: !!me?.id && !isSeller, queryKey: getListBuyerProfilesQueryKey({}) } },
  );
  const buyerProfile = buyerProfiles?.find((p) => p.userId === me?.id);

  const updateSeller = useUpdateSellerProfile();
  const updateBuyer = useUpdateBuyerProfile();
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    companyName: "", country: "", city: "", website: "", description: "",
    annualRevenue: "", employeeCount: "", annualBudget: "",
    // Seller
    categories: [] as string[],
    exportMarkets: [] as string[],
    certifications: [] as string[],
    // Buyer
    interestedCategories: [] as string[],
    preferredOrigins: [] as string[],
  });

  useEffect(() => {
    if (isSeller && sellerProfile) {
      setFormData({
        companyName: sellerProfile.companyName || "",
        country: sellerProfile.country || "",
        city: sellerProfile.city || "",
        website: sellerProfile.website || "",
        description: sellerProfile.description || "",
        annualRevenue: sellerProfile.annualRevenue || "",
        employeeCount: sellerProfile.employeeCount || "",
        annualBudget: "",
        categories: sellerProfile.categories ?? [],
        exportMarkets: sellerProfile.exportMarkets ?? [],
        certifications: sellerProfile.certifications ?? [],
        interestedCategories: [],
        preferredOrigins: [],
      });
    } else if (!isSeller && buyerProfile) {
      setFormData({
        companyName: buyerProfile.companyName || "",
        country: buyerProfile.country || "",
        city: buyerProfile.city || "",
        website: buyerProfile.website || "",
        description: buyerProfile.description || "",
        annualRevenue: "",
        employeeCount: "",
        annualBudget: buyerProfile.annualBudget || "",
        categories: [],
        exportMarkets: [],
        certifications: [],
        interestedCategories: buyerProfile.interestedCategories ?? [],
        preferredOrigins: buyerProfile.preferredOrigins ?? [],
      });
    }
  }, [sellerProfile, buyerProfile, isSeller]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!me?.id) return;

    // The country combobox has no native `required`, unlike the input it replaced.
    if (!formData.country) {
      toast({ title: "Choose your country", variant: "destructive" });
      return;
    }

    try {
      if (isSeller && sellerProfile?.id) {
        await updateSeller.mutateAsync({
          id: sellerProfile.id,
          data: {
            companyName: formData.companyName,
            country: formData.country,
            city: formData.city,
            website: formData.website,
            description: formData.description,
            annualRevenue: formData.annualRevenue,
            employeeCount: formData.employeeCount,
            categories: formData.categories,
            exportMarkets: formData.exportMarkets,
            certifications: formData.certifications,
          },
        });
      } else if (!isSeller && buyerProfile?.id) {
        await updateBuyer.mutateAsync({
          id: buyerProfile.id,
          data: {
            companyName: formData.companyName,
            country: formData.country,
            city: formData.city,
            website: formData.website,
            description: formData.description,
            annualBudget: formData.annualBudget,
            interestedCategories: formData.interestedCategories,
            preferredOrigins: formData.preferredOrigins,
          },
        });
      }
      toast({ title: "Profile updated" });
    } catch (err) {
      toast({ title: "Update failed", variant: "destructive" });
    }
  };

  const loading = meLoading || sellerLoading || buyerLoading;
  const isError = isSeller ? sellerError : buyerError;
  const refetch = () => (isSeller ? refetchSeller() : refetchBuyer());
  const hasProfile = isSeller ? !!sellerProfile : !!buyerProfile;

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Edit Profile</h1>
          <p className="text-muted-foreground">Manage your company information.</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load your profile" onRetry={() => refetch()} />
        ) : !hasProfile ? (
          // The form used to render regardless. handleSubmit only updates when a
          // profile id exists, so a user without one filled in every field, hit
          // Save, and got "Profile updated" while nothing was written.
          <Card>
            <CardContent className="py-12 text-center space-y-4">
              <div className="space-y-1">
                <h2 className="text-lg font-medium">You don't have a company profile yet</h2>
                <p className="text-muted-foreground text-sm">
                  Set one up first, then you can edit it here.
                </p>
              </div>
              <Button asChild>
                <Link href="/onboarding">Complete profile</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Company Details</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company name <span className="text-destructive" aria-hidden="true">*</span></Label>
                    <Input id="companyName" name="companyName" required autoComplete="organization" value={formData.companyName} onChange={e => setFormData({ ...formData, companyName: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input id="website" name="website" inputMode="url" autoComplete="url" placeholder="yourcompany.com" value={formData.website} onChange={e => setFormData({ ...formData, website: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">Country <span className="text-destructive" aria-hidden="true">*</span></Label>
                    <CountrySelect id="country" value={formData.country} onChange={(v) => setFormData({ ...formData, country: v })} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input id="city" name="city" autoComplete="address-level2" value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Company description</Label>
                  <Textarea id="description" name="description" rows={4} value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} />
                </div>

                {/* These lists were missing from this form entirely. Without
                    them a self-onboarded seller could never appear in a
                    category filter or receive an RFQ, and a buyer's matches
                    fell back to a buyer-independent tier ranking. */}
                {isSeller ? (
                  <>
                    <div className="space-y-2">
                      <Label id="lbl-categories">Product categories</Label>
                      <p className="text-xs text-muted-foreground">
                        Buyers filter the directory by these, and RFQs are routed to matching exporters.
                      </p>
                      <ChipSelect
                        labelledBy="lbl-categories"
                        options={CATEGORIES}
                        value={formData.categories}
                        onChange={(v) => setFormData({ ...formData, categories: v })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-markets">Export markets</Label>
                      <ChipSelect
                        labelledBy="lbl-markets"
                        options={COUNTRIES}
                        moreOptions={ALL_COUNTRIES}
                        moreLabel="Add another country"
                        value={formData.exportMarkets}
                        onChange={(v) => setFormData({ ...formData, exportMarkets: v })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-certs">Certifications</Label>
                      <ChipSelect
                        labelledBy="lbl-certs"
                        options={CERTIFICATIONS}
                        value={formData.certifications}
                        onChange={(v) => setFormData({ ...formData, certifications: v })}
                      />
                    </div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="annualRevenue">Annual revenue</Label>
                        <Select
                          value={formData.annualRevenue || undefined}
                          onValueChange={(v) => setFormData({ ...formData, annualRevenue: v })}
                        >
                          <SelectTrigger id="annualRevenue"><SelectValue placeholder="Select a range" /></SelectTrigger>
                          <SelectContent>
                            {REVENUE_BANDS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="employeeCount">Employees</Label>
                        <Select
                          value={formData.employeeCount || undefined}
                          onValueChange={(v) => setFormData({ ...formData, employeeCount: v })}
                        >
                          <SelectTrigger id="employeeCount"><SelectValue placeholder="Select a range" /></SelectTrigger>
                          <SelectContent>
                            {EMPLOYEE_BANDS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <Label id="lbl-sourcing">Categories you source</Label>
                      <p className="text-xs text-muted-foreground">
                        Your matches and RFQ routing are based on these.
                      </p>
                      <ChipSelect
                        labelledBy="lbl-sourcing"
                        options={CATEGORIES}
                        value={formData.interestedCategories}
                        onChange={(v) => setFormData({ ...formData, interestedCategories: v })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label id="lbl-origins">Preferred origins</Label>
                      <ChipSelect
                        labelledBy="lbl-origins"
                        options={COUNTRIES}
                        moreOptions={ALL_COUNTRIES}
                        moreLabel="Add another country"
                        value={formData.preferredOrigins}
                        onChange={(v) => setFormData({ ...formData, preferredOrigins: v })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="annualBudget">Annual sourcing budget</Label>
                      <Select
                        value={formData.annualBudget || undefined}
                        onValueChange={(v) => setFormData({ ...formData, annualBudget: v })}
                      >
                        <SelectTrigger id="annualBudget"><SelectValue placeholder="Select a range" /></SelectTrigger>
                        <SelectContent>
                          {BUDGET_BANDS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                <div className="pt-4 flex justify-end">
                  <Button type="submit" disabled={updateSeller.isPending || updateBuyer.isPending}>
                    {(updateSeller.isPending || updateBuyer.isPending) && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    Save Changes
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
