import { failureReason, isRateLimited } from "@/lib/server-error";
import { useState } from "react";
import { Link } from "wouter";
import { useForgotPassword } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function ForgotPassword() {
  const forgot = useForgotPassword();
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    // Backend always 204s (no account enumeration); show the same confirmation
    // whether or not the email exists.
    //
    // Rate limiting is the one exception. onSettled fires on failure too, so a
    // throttled request used to render "a reset link is on its way" and leave
    // the user waiting for mail that was never sent. Showing the 429 leaks
    // nothing, because the limit applies whether or not the address exists.
    forgot.mutate(
      { data: { email } },
      {
        onSettled: (_data, err) => {
          if (isRateLimited(err)) setError(failureReason(err));
          else setSent(true);
        },
      },
    );
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {/* This page had no header, no footer and no route back to the site. */}
          <Link href="/">
            <img
              src={`${import.meta.env.BASE_URL.replace(/\/$/, "")}/logo.svg`}
              alt="Originance home"
              className="h-10 mx-auto mb-4 cursor-pointer"
            />
          </Link>
          <CardTitle className="text-2xl font-serif">Reset your password</CardTitle>
          <CardDescription>
            Enter your email and we'll send you a reset link.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <p className="mb-4 text-sm text-destructive" role="alert">{error}</p>
          )}
          {sent ? (
            <div className="space-y-4 text-center">
              <p className="text-sm text-muted-foreground">
                If an account exists for <strong>{email}</strong>, a password
                reset link is on its way. The link expires in 1 hour.
              </p>
              <Link
                href="/sign-in"
                className="inline-block text-sm font-medium text-primary hover:underline"
              >
                Back to sign in
              </Link>
            </div>
          ) : (
            <form onSubmit={onSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <Button
                type="submit"
                className="w-full"
                disabled={forgot.isPending}
              >
                {forgot.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Send reset link
              </Button>
              <p className="text-center text-sm text-muted-foreground">
                <Link
                  href="/sign-in"
                  className="font-medium text-primary hover:underline"
                >
                  Back to sign in
                </Link>
              </p>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
