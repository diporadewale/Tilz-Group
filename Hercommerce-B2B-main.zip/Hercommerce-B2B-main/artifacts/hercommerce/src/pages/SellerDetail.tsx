import { useParams, Link } from "wouter";
import { useGetSellerProfile, useGetReadiness, useCreateEnquiry, useListProducts, useListReviews, useCreateReview,
  useDeleteReview, useListBuyerProfiles, getGetSellerProfileQueryKey, getGetReadinessQueryKey, getListProductsQueryKey, getListReviewsQueryKey, getListBuyerProfilesQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { formatPrice } from "@/lib/catalog";
import { Stars } from "@/components/Stars";
import { Star } from "lucide-react";
import { Layout } from "@/components/Layout";
import { usePageMeta } from "@/hooks/use-page-meta";
import { failureReason } from "@/lib/server-error";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, MapPin, Globe, Users, TrendingUp, CheckCircle2, MessageSquare } from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function SellerDetail() {
  const { id } = useParams();
  const sellerId = parseInt(id || "0", 10);
  const { user: me, isSignedIn } = useAuth();
  const { data: seller, isLoading: sellerLoading, isError: sellerError, refetch: refetchSeller } = useGetSellerProfile(sellerId, { query: { enabled: !!sellerId, queryKey: getGetSellerProfileQueryKey(sellerId) } });
  const { data: readiness } = useGetReadiness(sellerId, { query: { enabled: !!sellerId, queryKey: getGetReadinessQueryKey(sellerId) } });
  const productsParams = { sellerId };
  const { data: products } = useListProducts(productsParams, { query: { enabled: !!sellerId, queryKey: getListProductsQueryKey(productsParams) } });
  const reviewsParams = { sellerId };
  const { data: reviews } = useListReviews(reviewsParams, { query: { enabled: !!sellerId, queryKey: getListReviewsQueryKey(reviewsParams) } });
  const createEnquiry = useCreateEnquiry();
  const createReview = useCreateReview();
  const deleteReview = useDeleteReview();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [enquirySent, setEnquirySent] = useState(false);
  const [rating, setRating] = useState(0);
  const [reviewComment, setReviewComment] = useState("");

  // A buyer can only have one review per exporter and posting again revises it.
  // Without prefilling, "edit" silently replaced the previous rating and comment
  // with a blank form. GET /buyer-profiles returns only the caller's own profile.
  const isBuyer = me?.role === "buyer";
  const { data: myBuyerProfiles, isLoading: buyerProfileLoading } = useListBuyerProfiles(
    {},
    { query: { enabled: isBuyer, queryKey: getListBuyerProfilesQueryKey({}) } },
  );
  const myBuyerId = myBuyerProfiles?.[0]?.id;
  const myReview = myBuyerId ? reviews?.find((r) => r.buyerId === myBuyerId) : undefined;

  // An empty "No reviews yet." card sat directly above the primary CTA, so the
  // last thing a buyer read before deciding was an absence. This platform's
  // trust signal is the verified documents and readiness tier, not peer
  // reviews, and a young marketplace has zero reviews on almost every profile.
  // Render the card only when it has something to say, or someone to say it.
  const canReview = isSignedIn && isBuyer;

  // The server requires three things to accept a review: a buyer profile, a
  // verified email, and a prior enquiry with this exporter. Two of the three
  // are knowable here. Leaving the stars live meant a buyer could pick a
  // rating, write a comment, submit, and only then be told it was never going
  // to work. Name the missing precondition up front instead.
  const reviewBlocker = buyerProfileLoading
    ? null
    : !myBuyerId
      ? "Add your company profile before you can leave a review."
      : !me?.emailVerified
        ? "Verify your email address before you can leave a review."
        : null;
  const reviewDisabled = buyerProfileLoading || Boolean(reviewBlocker);
  const showReviews = Boolean(reviews?.length) || canReview;

  usePageMeta(seller?.companyName, seller?.description ?? undefined);

  const [reviewLoaded, setReviewLoaded] = useState(false);
  useEffect(() => {
    if (myReview && !reviewLoaded) {
      setRating(myReview.rating);
      setReviewComment(myReview.comment ?? "");
      setReviewLoaded(true);
    }
  }, [myReview, reviewLoaded]);

  // The author can retract their own rating; an admin can take down any review.
  // Until now nothing could remove one, so a mistaken or abusive rating stood
  // permanently on a company's public profile.
  const removeReview = async (reviewId: number) => {
    try {
      await deleteReview.mutateAsync({ id: reviewId });
      toast({ title: "Review removed" });
      setRating(0);
      setReviewComment("");
      setReviewLoaded(false);
      queryClient.invalidateQueries({ queryKey: getListReviewsQueryKey(reviewsParams) });
      queryClient.invalidateQueries({ queryKey: getGetSellerProfileQueryKey(sellerId) });
    } catch (err) {
      toast({
        title: "Could not remove review",
        description: failureReason(err),
        variant: "destructive",
      });
    }
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!rating) {
      toast({ title: "Pick a rating", variant: "destructive" });
      return;
    }
    try {
      await createReview.mutateAsync({ data: { sellerId, rating, comment: reviewComment || undefined } });
      toast({ title: "Review submitted", description: "Thanks for your feedback!" });
      setReviewComment("");
      queryClient.invalidateQueries({ queryKey: getListReviewsQueryKey(reviewsParams) });
      queryClient.invalidateQueries({ queryKey: getGetSellerProfileQueryKey(sellerId) });
    } catch (err) {
      // The server gates reviews on a verified email and a prior enquiry.
      // Those are actionable, so show the reason rather than a generic failure.
      toast({
        title: "Could not submit review",
        description: failureReason(err),
        variant: "destructive",
      });
    }
  };

  const handleSendEnquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject || !message) return;
    
    // Sending requires a buyer profile. Tell the user that instead of a bare
    // "Failed to send" they can't act on.
    if (!myBuyerId) {
      toast({
        title: "Complete your profile first",
        description: "You need a company profile before contacting exporters.",
        variant: "destructive",
      });
      return;
    }

    try {
      await createEnquiry.mutateAsync({
        data: { sellerId, subject, message }
      });
      setEnquirySent(true);
      toast({ title: "Enquiry sent", description: "The exporter will be notified." });
    } catch (err) {
      toast({
        title: "Failed to send",
        description: failureReason(err, "Something went wrong. Please try again."),
        variant: "destructive",
      });
    }
  };

  if (sellerLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></Layout>;
  // Distinguish "this exporter doesn't exist" from "we couldn't reach the API".
  // Previously both rendered as "Exporter not found."
  if (sellerError) {
    return (
      <Layout>
        <div className="text-center py-12 space-y-3">
          <p className="font-medium">Couldn't load this exporter</p>
          <p className="text-sm text-muted-foreground">Check your connection and try again.</p>
          <Button variant="outline" size="sm" onClick={() => refetchSeller()}>Retry</Button>
        </div>
      </Layout>
    );
  }
  if (!seller) return <Layout><div className="text-center py-12">Exporter not found.</div></Layout>;

  return (
    <Layout>
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center gap-2 mb-4">
          <Link href="/sellers" className="text-sm text-muted-foreground hover:text-primary">← Back to Directory</Link>
        </div>

        <div className="flex flex-col md:flex-row gap-6 items-start justify-between bg-white p-6 md:p-8 rounded-xl border shadow-sm">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold font-serif text-foreground">{seller.companyName}</h1>
            <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {seller.city ? `${seller.city}, ` : ''}{seller.country}</span>
              {seller.website && <a href={seller.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline"><Globe className="h-4 w-4" /> Website</a>}
            </div>
          </div>
          <div className="flex flex-col items-start md:items-end gap-2">
            <ReadinessBadge tier={seller.readinessTier} score={readiness?.score} />
            {seller.status === 'approved' && <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">Verified Exporter</Badge>}
            {seller.reviewCount ? (
              <div className="flex items-center gap-1.5">
                <Stars rating={seller.avgRating ?? 0} />
                <span className="text-sm text-muted-foreground">{seller.avgRating} ({seller.reviewCount})</span>
              </div>
            ) : null}
            {/* The primary action used to be the last block on the page, below
                About, Categories, Export Markets and Reviews.

                A signed-out visitor has nothing to scroll to: the card at the
                foot of the page repeats this button verbatim, so anchoring
                there cost a second identical click and a scroll that looked
                like nothing happened. Send them straight to sign-in.

                A signed-in seller or admin has no enquiry form on this page at
                all, so the anchor pointed at nothing. Show them no button. */}
            {!isSignedIn ? (
              <Button asChild className="mt-2 w-full md:w-auto">
                <Link href={`/sign-in?redirect=${encodeURIComponent(`/sellers/${sellerId}`)}`}>
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Sign in to enquire
                </Link>
              </Button>
            ) : isBuyer ? (
              <Button asChild className="mt-2 w-full md:w-auto">
                <a href="#enquiry">
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Contact this exporter
                </a>
              </Button>
            ) : null}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>About the Company</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground whitespace-pre-wrap">{seller.description || "No description provided."}</p>
              </CardContent>
            </Card>

            <div className="grid sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Categories</CardTitle></CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  {seller.categories?.length
                    ? seller.categories.map((c) => <Badge key={c} variant="secondary">{c}</Badge>)
                    : <span className="text-sm text-muted-foreground">No categories listed</span>}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Export Markets</CardTitle></CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  {seller.exportMarkets?.length
                    ? seller.exportMarkets.map((m) => <Badge key={m} variant="outline">{m}</Badge>)
                    : <span className="text-sm text-muted-foreground">No export markets listed</span>}
                </CardContent>
              </Card>
            </div>

            {products && products.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {products.map((p) => {
                      const price = formatPrice(p);
                      return (
                        <Link
                          key={p.id}
                          href={`/products/${p.id}`}
                          className="border rounded-lg overflow-hidden flex flex-col transition-colors hover:border-primary/50"
                        >
                          {p.imageUrl ? (
                            <img src={p.imageUrl} alt={p.name} className="h-32 w-full object-cover" />
                          ) : (
                            <div className="h-32 w-full bg-muted" />
                          )}
                          <div className="p-3">
                            <p className="font-medium text-sm leading-tight">{p.name}</p>
                            {p.category && <p className="text-xs text-muted-foreground mt-0.5">{p.category}</p>}
                            {price && <p className="text-sm text-primary font-medium mt-1">{price}</p>}
                            {p.moq != null && <p className="text-xs text-muted-foreground">MOQ: {p.moq}</p>}
                          </div>
                        </Link>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {showReviews && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 flex-wrap">
                    Reviews
                    {seller.reviewCount ? (
                      <span className="text-sm font-normal text-muted-foreground flex items-center gap-1">
                        <Stars rating={seller.avgRating ?? 0} /> {seller.avgRating} ({seller.reviewCount})
                      </span>
                    ) : null}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {canReview && (
                    <form onSubmit={submitReview} className="border rounded-lg p-4 space-y-3">
                      <p className="text-sm font-medium">
                        {myReview ? "Update your review" : "Leave a review"}
                      </p>
                      {reviewBlocker ? (
                        <p className="text-xs text-amber-700 dark:text-amber-500">{reviewBlocker}</p>
                      ) : myReview ? (
                        <p className="text-xs text-muted-foreground">
                          You reviewed this exporter. Saving replaces your previous rating and comment.
                        </p>
                      ) : (
                        <p className="text-xs text-muted-foreground">
                          You can review an exporter once you've contacted them and verified your email.
                        </p>
                      )}
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((i) => (
                          <button
                            key={i}
                            type="button"
                            disabled={reviewDisabled}
                            onClick={() => setRating(i)}
                            aria-label={`${i} star`}
                            className="p-1.5 -m-1.5 disabled:cursor-not-allowed disabled:opacity-50"
                          >
                            <Star className={`h-6 w-6 ${i <= rating ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30"}`} />
                          </button>
                        ))}
                      </div>
                      <Textarea rows={2} disabled={reviewDisabled} value={reviewComment} onChange={(e) => setReviewComment(e.target.value)} placeholder="Share your experience (optional)…" />
                      <Button type="submit" size="sm" disabled={createReview.isPending || reviewDisabled}>
                        {createReview.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        {myReview ? "Update review" : "Submit review"}
                      </Button>
                    </form>
                  )}
                  {!reviews?.length ? (
                    <p className="text-sm text-muted-foreground">No reviews yet.</p>
                  ) : (
                    <div className="space-y-3">
                      {reviews.map((r) => (
                        <div key={r.id} className="border-b last:border-0 pb-3 last:pb-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-medium">{r.buyerCompany || "Buyer"}</span>
                            <Stars rating={r.rating} />
                          </div>
                          {r.comment && <p className="text-sm text-muted-foreground mt-1">{r.comment}</p>}
                          {(me?.role === "admin" || (myBuyerId && r.buyerId === myBuyerId)) && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="mt-1 h-7 px-2 text-xs text-destructive hover:text-destructive"
                              disabled={deleteReview.isPending}
                              onClick={() => removeReview(r.id)}
                            >
                              {me?.role === "admin" && r.buyerId !== myBuyerId ? "Remove (admin)" : "Delete my review"}
                            </Button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {!isSignedIn && (
              <Card id="enquiry" className="scroll-mt-24">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5" /> Contact this exporter</CardTitle>
                  <CardDescription>Sign in as a buyer to send an enquiry to {seller.companyName}.</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-wrap gap-3">
                  <Button asChild>
                    <Link href={`/sign-in?redirect=${encodeURIComponent(`/sellers/${sellerId}`)}`}>Sign in to enquire</Link>
                  </Button>
                  <Button asChild variant="outline">
                    <Link href="/sign-up">Create an account</Link>
                  </Button>
                </CardContent>
              </Card>
            )}

            {isBuyer && (
              <Card id="enquiry" className="scroll-mt-24">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5" /> Send Enquiry</CardTitle>
                  <CardDescription>Contact {seller.companyName} directly.</CardDescription>
                </CardHeader>
                <CardContent>
                  {enquirySent ? (
                    <div className="bg-emerald-50 text-emerald-800 p-4 rounded-md space-y-3 border border-emerald-200">
                      <p className="flex items-center gap-2">
                        <CheckCircle2 className="h-5 w-5 shrink-0" />
                        Your enquiry has been sent. Replies appear in your Enquiries thread.
                      </p>
                      <div className="flex flex-wrap gap-2">
                        <Button asChild size="sm" variant="outline">
                          <Link href="/enquiries">View my enquiries</Link>
                        </Button>
                        {/* Previously the form was replaced permanently, so a
                            second enquiry needed a page reload. */}
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            setEnquirySent(false);
                            setSubject("");
                            setMessage("");
                          }}
                        >
                          Send another
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <form onSubmit={handleSendEnquiry} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="subject">Subject</Label>
                        <Input id="subject" required value={subject} onChange={e => setSubject(e.target.value)} placeholder="e.g. Request for quotation" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="message">Message</Label>
                        <Textarea id="message" required rows={4} value={message} onChange={e => setMessage(e.target.value)} placeholder="Describe your sourcing needs..." />
                      </div>
                      <Button type="submit" disabled={createEnquiry.isPending} className="w-full sm:w-auto">
                        {createEnquiry.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Send Message
                      </Button>
                    </form>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Company Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground flex items-center gap-2"><TrendingUp className="h-4 w-4" /> Annual Revenue</div>
                  <div className="font-medium">{seller.annualRevenue || "Not disclosed"}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground flex items-center gap-2"><Users className="h-4 w-4" /> Employees</div>
                  <div className="font-medium">{seller.employeeCount || "Not disclosed"}</div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Certifications</CardTitle>
              </CardHeader>
              <CardContent>
                {seller.certifications?.length ? (
                  <ul className="space-y-2">
                    {seller.certifications.map(cert => (
                      <li key={cert} className="flex items-center gap-2 text-sm">
                        <CheckCircle2 className="h-4 w-4 text-emerald-500" /> {cert}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <span className="text-sm text-muted-foreground">No certifications listed</span>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}