import { usePageMeta } from "@/hooks/use-page-meta";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export default function Home() {
  usePageMeta(undefined, "Source directly from verified women-led exporters in emerging markets. Every profile carries a readiness tier showing how much has been verified.");
  const [, setLocation] = useLocation();
  const [q, setQ] = useState("");
  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const query = q.trim();
    setLocation(query ? `/sellers?search=${encodeURIComponent(query)}` : "/sellers");
  };
  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <header className="h-16 border-b border-border bg-white flex items-center justify-between px-6 lg:px-12 sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <img src={`${import.meta.env.BASE_URL.replace(/\/$/, "")}/logo.svg`} alt="Originance Logo" className="h-8 w-auto" />
        </div>
        <nav className="hidden md:flex gap-6 items-center text-sm font-medium text-muted-foreground">
          <Link href="/sellers" className="hover:text-primary transition-colors">Find Exporters</Link>
          <Link href="/products" className="hover:text-primary transition-colors">Products</Link>
          <a href="#how-it-works" className="hover:text-primary transition-colors">How it Works</a>
          <a href="#about" className="hover:text-primary transition-colors">About Us</a>
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/sign-in" className="text-sm font-medium text-primary hover:underline">
            Sign In
          </Link>
          <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link href="/sign-up">Get Started</Link>
          </Button>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative py-24 lg:py-32 overflow-hidden px-6 lg:px-12 bg-white">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/5 via-transparent to-transparent pointer-events-none" />
          <div className="max-w-5xl mx-auto text-center relative z-10">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold tracking-tight text-foreground leading-tight">
              Verified women-led exporters from emerging markets.
            </h1>
            <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
              Source directly from exporters whose documents we have checked. Every profile carries a readiness tier that shows exactly how much has been verified, so you know what you are looking at before you make contact.
            </p>
            <form onSubmit={onSearch} className="mt-10 max-w-2xl mx-auto flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  placeholder="Search exporters by company name…"
                  className="h-14 pl-12 text-base bg-white"
                  aria-label="Search exporters"
                />
              </div>
              <Button type="submit" size="lg" className="h-14 px-8 text-base">Search</Button>
            </form>
            <p className="mt-3 text-sm text-muted-foreground">
              Browse freely. Sign in only when you want to contact an exporter.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="outline" className="h-12 px-8 text-base border-primary/20 text-primary hover:bg-primary/5">
                <Link href="/sellers">Browse all exporters</Link>
              </Button>
              <Button asChild size="lg" variant="ghost" className="h-12 px-8 text-base">
                <Link href="/sign-up?role=seller">Register as an exporter</Link>
              </Button>
            </div>
          </div>
        </section>

        {/* This band previously carried "50+ Countries · 10k+ Verified Sellers ·
            $2B+ Trade Volume · 100% Verified Documents" against an actual
            platform of 9 exporters and 0 products. For a product whose entire
            pitch is verification, unverifiable claims are the worst possible
            first impression, and in several jurisdictions are actionable as
            misleading advertising. Replaced with statements that describe how
            the platform works, which are true today. */}
        <section className="py-16 bg-primary text-primary-foreground px-6 lg:px-12">
          <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
            <div className="flex flex-col gap-2">
              <span className="text-xl font-serif font-bold text-secondary">Document-verified</span>
              <span className="text-sm text-primary-foreground/80">
                Business registration, tax and export licences are checked by our team before an exporter is listed.
              </span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-xl font-serif font-bold text-secondary">Readiness-rated</span>
              <span className="text-sm text-primary-foreground/80">
                Bronze to Platinum tiers reflect how much of an exporter's paperwork has been verified, not how much they paid.
              </span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-xl font-serif font-bold text-secondary">Direct contact</span>
              <span className="text-sm text-primary-foreground/80">
                Message exporters in-app, post a request for quote, and compare responses side by side.
              </span>
            </div>
          </div>
        </section>

        {/* The header links to #how-it-works and #about. Both anchors were dead:
            no element with either id existed anywhere in the document. */}
        <section id="how-it-works" className="py-16 px-6 lg:px-12 scroll-mt-20">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-center">How it works</h2>
            <div className="mt-10 grid gap-8 md:grid-cols-3">
              {[
                {
                  step: "1",
                  title: "Exporters get verified",
                  body: "Exporters upload their registration, tax and licence documents. Our admin team reviews each one, and the outcome sets their readiness tier.",
                },
                {
                  step: "2",
                  title: "Buyers search or post",
                  body: "Browse the directory by category, country and tier, or post a request for quote and let matching exporters come to you.",
                },
                {
                  step: "3",
                  title: "You talk directly",
                  body: "Send an enquiry and continue the conversation in-app. Compare quotes, then take the relationship forward on your own terms.",
                },
              ].map((s) => (
                <div key={s.step} className="space-y-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 text-primary font-bold flex items-center justify-center">
                    {s.step}
                  </div>
                  <h3 className="font-semibold text-lg">{s.title}</h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">{s.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="about" className="py-16 px-6 lg:px-12 bg-muted/40 scroll-mt-20">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h2 className="text-2xl sm:text-3xl font-serif font-bold">About Originance</h2>
            <p className="text-muted-foreground leading-relaxed">
              Originance is a B2B marketplace connecting global buyers with women-led exporters
              in emerging markets. Cross-border sourcing usually stalls on the same problem:
              a buyer has no reliable way to tell whether a supplier is who they say they are.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              We put verification first. Every exporter in the directory has submitted business
              documents that our team has reviewed, and their readiness tier reflects exactly how
              much has been confirmed, so you know what you're looking at before you make contact.
            </p>
          </div>
        </section>
      </main>

      <footer className="bg-foreground text-background py-12 px-6 lg:px-12 border-t border-border/10">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="md:col-span-2">
            <img src={`${import.meta.env.BASE_URL.replace(/\/$/, "")}/logo-on-dark.svg`} alt="Originance" className="h-8 w-auto" />
            <p className="mt-4 text-sm text-muted-foreground max-w-sm">
              Bridging the gap between emerging markets and global buyers with data-forward trust and transparency.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-white">Platform</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/sellers" className="hover:text-white transition-colors">Browse Exporters</Link></li>
              <li><Link href="/sign-up?role=buyer" className="hover:text-white transition-colors">Join as Buyer</Link></li>
              <li><Link href="/sign-up?role=seller" className="hover:text-white transition-colors">Join as Exporter</Link></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4 text-white">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}