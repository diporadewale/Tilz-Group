import { useState } from "react";
import { useParams, Link } from "wouter";
import {
  useGetRfq,
  useCreateRfqQuote,
  useUpdateRfq,
  useListBuyerProfiles,
  getGetRfqQueryKey,
  getListRfqsQueryKey,
  getListBuyerProfilesQueryKey,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { useAuth } from "@/hooks/use-auth";
import { ReadinessBadge } from "@/components/ReadinessBadge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, MapPin, MessageSquare, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CURRENCIES, UNITS, INCOTERMS } from "@/lib/catalog";
import { formatQuotePrice, formatTarget, rankQuotes } from "@/lib/quote";
import { failureReason } from "@/lib/server-error";
import type { RfqQuoteInputCurrency, RfqQuoteInputUnit, RfqQuoteInputIncoterm } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export default function RfqDetail() {
  const { id } = useParams();
  const rfqId = parseInt(id || "0", 10);
  const { user: me } = useAuth();
  const { data: rfq, isLoading, isError, refetch } = useGetRfq(rfqId, { query: { enabled: !!rfqId, queryKey: getGetRfqQueryKey(rfqId) } });
  const createQuote = useCreateRfqQuote();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Structured, so the buyer can compare quotes. Currency and unit start empty
  // and fall back to the RFQ's own at render time: the RFQ loads after first
  // render, and deriving the default avoids an effect racing the seller's input.
  const [unitPrice, setUnitPrice] = useState("");
  const [currency, setCurrency] = useState("");
  const [unit, setUnit] = useState("");
  const [incoterm, setIncoterm] = useState("");
  const [incotermPlace, setIncotermPlace] = useState("");
  const [leadTime, setLeadTime] = useState("");
  const [message, setMessage] = useState("");
  const [revising, setRevising] = useState(false);

  const isSeller = me?.role === "seller";
  const isBuyer = me?.role === "buyer";
  const myQuote = isSeller ? rfq?.quotes?.[0] : undefined;

  // GET /buyer-profiles returns only the caller's own profile, so this is a
  // cheap, exact ownership check.
  const { data: myBuyerProfiles } = useListBuyerProfiles(
    {},
    { query: { enabled: isBuyer, queryKey: getListBuyerProfilesQueryKey({}) } },
  );
  const isOwner = !!rfq && myBuyerProfiles?.[0]?.id === rfq.buyerId;

  const updateRfq = useUpdateRfq();

  const setStatus = async (status: "open" | "closed") => {
    try {
      await updateRfq.mutateAsync({ id: rfqId, data: { status } });
      toast({
        title: status === "closed" ? "RFQ closed" : "RFQ reopened",
        description:
          status === "closed"
            ? "Exporters can no longer submit quotes."
            : "Exporters can submit quotes again.",
      });
      queryClient.invalidateQueries({ queryKey: getGetRfqQueryKey(rfqId) });
      queryClient.invalidateQueries({ queryKey: getListRfqsQueryKey({ scope: "mine" }) });
    } catch {
      toast({ title: "Could not update this RFQ", variant: "destructive" });
    }
  };

  const quoteCurrency = currency || rfq?.targetCurrency || "USD";
  const quoteUnit = unit || rfq?.unit || "";

  const submitQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitPrice) return;
    if (!quoteUnit) {
      toast({ title: "Choose a unit for your price", variant: "destructive" });
      return;
    }
    try {
      await createQuote.mutateAsync({
        id: rfqId,
        data: {
          unitPrice,
          currency: quoteCurrency as RfqQuoteInputCurrency,
          unit: quoteUnit as RfqQuoteInputUnit,
          incoterm: (incoterm || undefined) as RfqQuoteInputIncoterm | undefined,
          incotermPlace: incotermPlace || undefined,
          leadTime: leadTime || undefined,
          message: message || undefined,
        },
      });
      toast({
        title: myQuote ? "Quote updated" : "Quote submitted",
        description: "The buyer can now see your quote.",
      });
      setUnitPrice(""); setCurrency(""); setUnit(""); setIncoterm(""); setIncotermPlace("");
      setLeadTime(""); setMessage("");
      setRevising(false);
      queryClient.invalidateQueries({ queryKey: getGetRfqQueryKey(rfqId) });
    } catch (err) {
      toast({ title: "Could not submit quote", description: failureReason(err), variant: "destructive" });
    }
  };

  if (isLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></Layout>;
  // A 403 or a network failure previously both rendered as "RFQ not found."
  if (isError) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto">
          <ErrorState label="Couldn't load this RFQ" onRetry={() => refetch()} />
        </div>
      </Layout>
    );
  }
  if (!rfq) return <Layout><div className="text-center py-12 text-muted-foreground">RFQ not found.</div></Layout>;

  const meta = [
    rfq.category,
    rfq.quantity && `${rfq.quantity}${rfq.unit ? ` ${rfq.unit}` : ""}`,
    formatTarget(rfq) && `Target ${formatTarget(rfq)}`,
  ].filter(Boolean);

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-6">
        <Link href={isSeller ? "/rfq-market" : "/rfqs"} className="text-sm text-muted-foreground hover:text-primary">← Back</Link>

        <Card>
          <CardHeader>
            <div className="flex items-start justify-between gap-3">
              <CardTitle className="text-2xl">{rfq.title}</CardTitle>
              <div className="flex items-center gap-2 shrink-0">
                <Badge variant={rfq.status === "open" ? "secondary" : "outline"} className="capitalize">{rfq.status}</Badge>
                {/* A buyer previously had no way to close their own RFQ, so it
                    stayed in the seller market indefinitely and the "closed"
                    branch of this page was unreachable. */}
                {isOwner && (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={updateRfq.isPending}
                    onClick={() => setStatus(rfq.status === "open" ? "closed" : "open")}
                  >
                    {updateRfq.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {rfq.status === "open" ? "Close RFQ" : "Reopen"}
                  </Button>
                )}
              </div>
            </div>
            <CardDescription>{rfq.buyerCompany || "A buyer"}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="whitespace-pre-wrap text-sm">{rfq.description}</p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
              {meta.map((m, i) => <span key={i}>{m}</span>)}
              {rfq.destinationCountry && <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {rfq.destinationCountry}</span>}
            </div>
          </CardContent>
        </Card>

        {/* Seller: submit / view own quote */}
        {isSeller && (
          myQuote && !revising ? (
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-emerald-600" /> Your quote</CardTitle></CardHeader>
              <CardContent className="text-sm space-y-1">
                <p><span className="text-muted-foreground">Price:</span> <span className="font-medium">{formatQuotePrice(myQuote)}</span></p>
                {myQuote.leadTime && <p><span className="text-muted-foreground">Lead time:</span> {myQuote.leadTime}</p>}
                {myQuote.message && <p className="whitespace-pre-wrap">{myQuote.message}</p>}
                {/* Resubmitting now revises this quote rather than adding a
                    duplicate, so give the seller a way to do it. */}
                {rfq.status === "open" && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-3"
                    onClick={() => {
                      // A legacy free-text quote has no unit price to prefill;
                      // the seller re-enters it, with the old text shown as a hint.
                      setUnitPrice(myQuote.unitPrice ?? "");
                      setCurrency(myQuote.currency ?? "");
                      setUnit(myQuote.unit ?? "");
                      setIncoterm(myQuote.incoterm ?? "");
                      setIncotermPlace(myQuote.incotermPlace ?? "");
                      setLeadTime(myQuote.leadTime ?? "");
                      setMessage(myQuote.message ?? "");
                      setRevising(true);
                    }}
                  >
                    Revise quote
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : rfq.status === "open" ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><MessageSquare className="h-5 w-5" /> Submit a quote</CardTitle>
                <CardDescription>Only this buyer sees your quote.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={submitQuote} className="space-y-4">
                  {revising && myQuote?.price && !myQuote.unitPrice && (
                    <p className="rounded-md border bg-muted/50 p-3 text-xs text-muted-foreground">
                      Your previous quote was "{myQuote.price}". Quotes now have separate fields so
                      the buyer can compare them, so enter it again below.
                    </p>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="unitPrice">Unit price <span className="text-destructive" aria-hidden="true">*</span></Label>
                    {/* Wraps below ~360px so the amount never shrinks to a sliver
                        between the two selects on a small phone. */}
                    <div className="flex flex-wrap gap-2">
                      <Select value={quoteCurrency} onValueChange={setCurrency}>
                        <SelectTrigger className="w-24 shrink-0" aria-label="Currency"><SelectValue /></SelectTrigger>
                        <SelectContent>{CURRENCIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                      </Select>
                      <Input id="unitPrice" required inputMode="decimal" className="min-w-28 flex-1" value={unitPrice} onChange={(e) => setUnitPrice(e.target.value)} placeholder="e.g. 3.90" />
                      <Select value={quoteUnit || undefined} onValueChange={setUnit}>
                        <SelectTrigger className="w-28 shrink-0" aria-label="Per unit"><SelectValue placeholder="per unit" /></SelectTrigger>
                        <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>per {u}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="incoterm">Delivery terms (Incoterm)</Label>
                      {/* Who pays freight and insurance, and where risk passes, is
                          most of the difference between two quotes at the same
                          unit price, so it gets its own field. */}
                      <div className="flex gap-2">
                        <Select value={incoterm || undefined} onValueChange={setIncoterm}>
                          <SelectTrigger id="incoterm" className="w-28 shrink-0"><SelectValue placeholder="Select" /></SelectTrigger>
                          <SelectContent>{INCOTERMS.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                        </Select>
                        <Input aria-label="Named place" value={incotermPlace} onChange={(e) => setIncotermPlace(e.target.value)} placeholder="e.g. Lagos" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lead">Lead time</Label>
                      <Input id="lead" value={leadTime} onChange={(e) => setLeadTime(e.target.value)} placeholder="e.g. 3-4 weeks" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="qmsg">Message</Label>
                    <Textarea id="qmsg" rows={3} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Terms, samples, certifications…" />
                  </div>
                  <Button type="submit" disabled={createQuote.isPending}>
                    {createQuote.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} Submit Quote
                  </Button>
                </form>
              </CardContent>
            </Card>
          ) : (
            <p className="text-sm text-muted-foreground">This RFQ is closed.</p>
          )
        )}

        {/* Buyer: quotes received */}
        {!isSeller && (
          <Card>
            <CardHeader><CardTitle>Quotes received ({rfq.quoteCount ?? 0})</CardTitle></CardHeader>
            <CardContent>
              {!rfq.quotes?.length ? (
                <p className="text-sm text-muted-foreground">No quotes yet. Matching exporters will respond here.</p>
              ) : (
                <div className="space-y-3">
                  {/* Ordered by unit price where quotes share a currency and
                      unit, lowest first. Arithmetic on the sellers' own numbers,
                      not a judgement of the sellers. */}
                  {rankQuotes(rfq.quotes, rfq).map(({ quote: q, lowest, vsTargetPct }) => (
                    <div key={q.id} className={`border rounded-lg p-4 ${lowest ? "border-emerald-300" : ""}`}>
                      <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1">
                        <div className="flex flex-wrap items-center gap-2 min-w-0">
                          <span className="font-medium">{q.sellerCompany || "Exporter"}</span>
                          <ReadinessBadge tier={(q.sellerTier as never) ?? null} />
                          {lowest && (
                            <Badge variant="outline" className="border-emerald-300 bg-emerald-50 text-emerald-800">Lowest price</Badge>
                          )}
                        </div>
                        <div className="text-right">
                          <span className="font-semibold text-primary break-words">{formatQuotePrice(q)}</span>
                          {vsTargetPct !== null && (
                            <p className={`text-xs ${vsTargetPct <= 0 ? "text-emerald-700" : "text-muted-foreground"}`}>
                              {vsTargetPct === 0 ? "At your target" : `${Math.abs(vsTargetPct)}% ${vsTargetPct < 0 ? "below" : "above"} your target`}
                            </p>
                          )}
                        </div>
                      </div>
                      {q.leadTime && <p className="text-xs text-muted-foreground mt-1">Lead time: {q.leadTime}</p>}
                      {q.message && <p className="text-sm mt-2 whitespace-pre-wrap">{q.message}</p>}
                      <div className="mt-3">
                        <Button asChild size="sm" variant="outline">
                          <Link href={`/sellers/${q.sellerId}`}>View exporter</Link>
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
