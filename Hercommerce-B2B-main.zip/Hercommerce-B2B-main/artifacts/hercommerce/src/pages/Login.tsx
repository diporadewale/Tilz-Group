import { failureReason, isRateLimited } from "@/lib/server-error";
import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { GoogleSignInButton } from "@/components/GoogleSignInButton";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/PasswordInput";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export default function Login() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const login = useLogin();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  // The Google callback redirects here with ?error= when the flow fails. Without
  // this the user lands back on a blank sign-in form with no idea what happened.
  const [error, setError] = useState<string | null>(() => {
    const code = new URLSearchParams(window.location.search).get("error");
    switch (code) {
      case "google_cancelled":
        return "Google sign-in was cancelled.";
      case "google_email_unverified":
        return "That Google account's email address isn't verified, so we can't use it to sign in.";
      case "google_state_mismatch":
        return "That sign-in link expired. Please try again.";
      case "google_exchange_failed":
      case "google_signin_failed":
        return "Google sign-in didn't complete. Please try again.";
      default:
        return null;
    }
  });
  const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    login.mutate(
      { data: { email, password } },
      {
        onSuccess: async () => {
          await queryClient.invalidateQueries({
            queryKey: getGetMeQueryKey(),
          });
          // Honour ?redirect= so the user returns to whatever they were
          // trying to reach. Only same-origin paths are accepted.
          const target = new URLSearchParams(window.location.search).get("redirect");
          setLocation(target && target.startsWith("/") && !target.startsWith("//") ? target : "/");
        },
        onError: (err) =>
          setError(
            // After too many attempts the credentials may well be correct, so
            // repeating "invalid password" would send the user hunting for a
            // problem that isn't there.
            isRateLimited(err) ? failureReason(err) : "Invalid email or password.",
          ),
      },
    );
  };

  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-12">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          {/* The logo was a bare <img>; these pages had no header, no footer
              and no link back to the site; the only exit was the back button. */}
          <Link href="/">
            <img
              src={`${basePath}/logo.svg`}
              alt="Originance home"
              className="h-10 mx-auto mb-4 cursor-pointer"
            />
          </Link>
          <CardTitle className="text-2xl font-serif">
            Welcome to Originance
          </CardTitle>
          <CardDescription>Sign in to access your trade portal</CardDescription>
        </CardHeader>
        <CardContent>
          <GoogleSignInButton label="Sign in with Google" />
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link
                  href="/forgot-password"
                  className="text-xs font-medium text-primary hover:underline"
                >
                  Forgot password?
                </Link>
              </div>
              <PasswordInput
                id="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={setPassword}
              />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Button type="submit" className="w-full" disabled={login.isPending}>
              {login.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Sign In
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link
              href="/sign-up"
              className="font-medium text-primary hover:underline"
            >
              Get started
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
