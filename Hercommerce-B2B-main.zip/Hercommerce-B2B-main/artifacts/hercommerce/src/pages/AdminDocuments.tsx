import {
  useListPendingReviews,
  useVerifyDocument,
  useUpdateSellerProfile,
  useUpdateBuyerProfile,
  useCreateAuditNote,
} from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { failureReason } from "@/lib/server-error";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, FileText, ExternalLink, Check, X } from "lucide-react";
import { useState } from "react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { getListPendingReviewsQueryKey } from "@workspace/api-client-react";

// A reviewer approving a profile is certifying a company to every buyer on the
// platform, so the queue has to show what is actually being certified.
function Chips({ label, values, hint }: { label: string; values?: readonly string[] | null; hint?: string }) {
  return (
    <div className="space-y-1">
      <p className="text-xs font-medium text-muted-foreground">{label}</p>
      {values?.length ? (
        <div className="flex flex-wrap gap-1">
          {values.map((v) => (
            <Badge key={v} variant="secondary" className="font-normal">{v}</Badge>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground/60">None listed</p>
      )}
      {hint && <p className="text-xs text-muted-foreground/70">{hint}</p>}
    </div>
  );
}

export default function AdminDocuments() {
  const { data: reviews, isLoading, isError, refetch } = useListPendingReviews();
  const verifyDoc = useVerifyDocument();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [rejectionReasons, setRejectionReasons] = useState<Record<number, string>>({});
  const [decidingProfile, setDecidingProfile] = useState<number | null>(null);
  // Rejecting a document already required a reason; rejecting a whole company
  // required nothing, so an exporter could be turned away with no explanation
  // and nothing to correct. Keyed separately from the document reasons above,
  // whose ids come from a different table.
  const [profileReasons, setProfileReasons] = useState<Record<string, string>>({});
  const createAuditNote = useCreateAuditNote();

  const updateSeller = useUpdateSellerProfile();
  const updateBuyer = useUpdateBuyerProfile();

  // `status` on a profile is the admin verification verdict, the server only
  // accepts it from an admin, which is what makes this queue safe.
  const decideProfile = async (
    kind: "Exporter" | "Buyer",
    id: number,
    status: "approved" | "rejected",
  ) => {
    const reason = profileReasons[`${kind}-${id}`]?.trim();
    if (status === "rejected" && !reason) {
      toast({ title: "Give a reason before rejecting", variant: "destructive" });
      return;
    }
    setDecidingProfile(id);
    try {
      if (kind === "Exporter") await updateSeller.mutateAsync({ id, data: { status } });
      else await updateBuyer.mutateAsync({ id, data: { status } });

      // Recorded against the profile so the decision is auditable and can be
      // quoted back to the company. The status change is what matters, so a
      // failure to file the note must not read as a failed rejection.
      if (status === "rejected" && reason) {
        try {
          await createAuditNote.mutateAsync({
            data: {
              entityType: kind === "Exporter" ? "seller" : "buyer",
              entityId: id,
              note: reason,
              action: "profile_rejected",
            },
          });
        } catch {
          toast({
            title: `${kind} profile rejected`,
            description: "The reason could not be saved to the audit log.",
            variant: "destructive",
          });
          queryClient.invalidateQueries({ queryKey: getListPendingReviewsQueryKey() });
          return;
        }
      }

      toast({ title: `${kind} profile ${status}` });
      queryClient.invalidateQueries({ queryKey: getListPendingReviewsQueryKey() });
    } catch (err) {
      toast({
        title: "Could not update that profile",
        description: failureReason(err),
        variant: "destructive",
      });
    } finally {
      setDecidingProfile(null);
    }
  };

  const handleVerify = async (id: number, status: 'approved' | 'rejected') => {
    try {
      await verifyDoc.mutateAsync({
        id,
        data: { status, rejectionReason: status === 'rejected' ? rejectionReasons[id] : undefined }
      });
      toast({ title: `Document ${status}` });
      queryClient.invalidateQueries({ queryKey: getListPendingReviewsQueryKey() });
    } catch (e) {
      toast({ title: "Verification failed", variant: "destructive" });
    }
  };

  const docs = reviews?.documents || [];
  // Both halves of the dashboard's "Action Required" now live here, the
  // pending-profiles count was surfaced there but had no screen behind it.
  const pendingProfiles = [
    ...(reviews?.sellerProfiles || []).map((p) => ({ ...p, kind: "Exporter" as const })),
    ...(reviews?.buyerProfiles || []).map((p) => ({ ...p, kind: "Buyer" as const })),
  ];

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Review Queue</h1>
          <p className="text-muted-foreground">Approving or rejecting a document recalculates that exporter's readiness tier.</p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load the review queue" onRetry={() => refetch()} />
        ) : !docs.length && !pendingProfiles.length ? (
          <Card className="py-12 text-center">
            <CardContent>
              <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4 opacity-20" />
              <h3 className="text-lg font-medium">Nothing to review</h3>
              <p className="text-muted-foreground">The queue is empty.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {docs.map(doc => (
              <Card key={doc.id} className="overflow-hidden">
                <div className="flex flex-col sm:flex-row">
                  <div className="p-6 flex-1">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-semibold text-lg break-words">{doc.fileName}</h3>
                        {/* Read "Seller ID: 11" and nothing else, so the reviewer
                            had to look the company up by hand before they could
                            judge the document. */}
                        <div className="flex flex-wrap items-center gap-2 mt-1">
                          <Badge variant="outline" className="capitalize">{doc.documentType.replace(/_/g, ' ')}</Badge>
                          {doc.ownerCompany && <span className="text-xs font-medium">{doc.ownerCompany}</span>}
                          {doc.ownerEmail && <span className="text-xs text-muted-foreground">{doc.ownerEmail}</span>}
                          <span className="text-xs text-muted-foreground">
                            Submitted {format(new Date(doc.createdAt), "d MMM yyyy")}
                          </span>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" asChild>
                        <a href={`/api/documents/${doc.id}/file`} target="_blank" rel="noopener noreferrer"><ExternalLink className="mr-2 h-4 w-4" /> View File</a>
                      </Button>
                    </div>
                    
                    <div className="mt-4 space-y-3">
                      <Textarea 
                        placeholder="Rejection reason (required if rejecting)..." 
                        value={rejectionReasons[doc.id] || ''}
                        onChange={(e) => setRejectionReasons(prev => ({...prev, [doc.id]: e.target.value}))}
                        className="text-sm"
                        rows={2}
                      />
                      <div className="flex gap-2">
                        <Button 
                          onClick={() => handleVerify(doc.id, 'approved')} 
                          className="bg-emerald-600 hover:bg-emerald-700 flex-1 sm:flex-none"
                          disabled={verifyDoc.isPending}
                        >
                          <Check className="mr-2 h-4 w-4" /> Approve
                        </Button>
                        <Button 
                          onClick={() => handleVerify(doc.id, 'rejected')} 
                          variant="destructive"
                          disabled={!rejectionReasons[doc.id] || verifyDoc.isPending}
                          className="flex-1 sm:flex-none"
                        >
                          <X className="mr-2 h-4 w-4" /> Reject
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}

            {pendingProfiles.length > 0 && (
              <div className="space-y-4">
                <h2 className="text-lg font-semibold pt-2">Profiles awaiting approval</h2>
                {pendingProfiles.map((p) => (
                  <Card key={`${p.kind}-${p.id}`}>
                    <CardContent className="pt-6 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <h3 className="font-semibold">{p.companyName}</h3>
                            <Badge variant="outline">{p.kind}</Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {[p.city, p.country].filter(Boolean).join(", ")}
                            {p.user?.email ? ` · ${p.user.email}` : ""}
                            {` · Registered ${format(new Date(p.createdAt), "d MMM yyyy")}`}
                          </p>
                          {p.website && (
                            <a
                              href={p.website}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-primary hover:underline inline-flex items-center gap-1 mt-1 break-all"
                            >
                              <ExternalLink className="h-3 w-3 shrink-0" /> {p.website}
                            </a>
                          )}
                        </div>
                        <div className="flex flex-col gap-2 shrink-0 sm:w-64">
                          <Textarea
                            rows={2}
                            className="text-sm"
                            placeholder="Rejection reason (required if rejecting)…"
                            value={profileReasons[`${p.kind}-${p.id}`] ?? ""}
                            onChange={(e) =>
                              setProfileReasons((prev) => ({ ...prev, [`${p.kind}-${p.id}`]: e.target.value }))
                            }
                          />
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              className="bg-emerald-600 hover:bg-emerald-700 flex-1"
                              disabled={decidingProfile !== null}
                              onClick={() => decideProfile(p.kind, p.id, "approved")}
                            >
                              <Check className="mr-2 h-4 w-4" /> Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="flex-1"
                              disabled={decidingProfile !== null || !profileReasons[`${p.kind}-${p.id}`]?.trim()}
                              onClick={() => decideProfile(p.kind, p.id, "rejected")}
                            >
                              <X className="mr-2 h-4 w-4" /> Reject
                            </Button>
                          </div>
                        </div>
                      </div>

                      {p.description ? (
                        <p className="text-sm text-muted-foreground whitespace-pre-wrap border-l-2 border-muted pl-3">
                          {p.description}
                        </p>
                      ) : (
                        <p className="text-sm text-muted-foreground/60 italic">No company description provided.</p>
                      )}

                      <div className="grid sm:grid-cols-2 gap-x-6 gap-y-4 border-t pt-4">
                        {p.kind === "Exporter" ? (
                          <>
                            <Chips label="Categories" values={p.categories} />
                            <Chips label="Export markets" values={p.exportMarkets} />
                            <Chips
                              label="Claimed certifications"
                              values={p.certifications}
                              hint="Self-declared. Only an approved document verifies these."
                            />
                            <div className="space-y-1">
                              <p className="text-xs font-medium text-muted-foreground">Size</p>
                              <p className="text-sm">{p.annualRevenue || "Revenue not disclosed"}</p>
                              <p className="text-sm">{p.employeeCount ? `${p.employeeCount} employees` : "Headcount not disclosed"}</p>
                            </div>
                          </>
                        ) : (
                          <>
                            <Chips label="Interested in" values={p.interestedCategories} />
                            <Chips label="Preferred origins" values={p.preferredOrigins} />
                            <div className="space-y-1">
                              <p className="text-xs font-medium text-muted-foreground">Annual budget</p>
                              <p className="text-sm">{p.annualBudget || "Not disclosed"}</p>
                            </div>
                          </>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}