import { useParams, Link } from "wouter";
import { useGetEnquiry, useCreateEnquiryMessage, getGetEnquiryQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, ArrowLeft, Send } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";

export default function EnquiryDetail() {
  const { id } = useParams();
  const enquiryId = parseInt(id || "0", 10);
  const { user: me } = useAuth();
  const { data: enquiry, isLoading, isError, refetch } = useGetEnquiry(enquiryId, {
    query: { enabled: !!enquiryId, queryKey: getGetEnquiryQueryKey(enquiryId) },
  });
  const sendMessage = useCreateEnquiryMessage();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [body, setBody] = useState("");

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!body.trim()) return;
    try {
      await sendMessage.mutateAsync({ id: enquiryId, data: { body: body.trim() } });
      setBody("");
      queryClient.invalidateQueries({ queryKey: getGetEnquiryQueryKey(enquiryId) });
    } catch {
      toast({ title: "Failed to send", variant: "destructive" });
    }
  };

  if (isLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></Layout>;
  // A 403 (not a participant) or a network failure previously both rendered as
  // "Enquiry not found."
  if (isError) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto">
          <ErrorState label="Couldn't load this conversation" onRetry={() => refetch()} />
        </div>
      </Layout>
    );
  }
  if (!enquiry) return <Layout><div className="text-center py-12">Enquiry not found.</div></Layout>;

  const closed = enquiry.status === "closed";

  return (
    <Layout>
      <div className="max-w-3xl mx-auto space-y-4">
        <Link href="/enquiries" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Enquiries
        </Link>

        <Card className="flex flex-col h-[70dvh] md:h-[calc(100dvh-12rem)]">
          <CardHeader className="border-b shrink-0">
            <CardTitle className="text-lg">{enquiry.subject}</CardTitle>
            <p className="text-sm text-muted-foreground">
              {enquiry.buyer?.companyName} ↔ {enquiry.seller?.companyName}
            </p>
          </CardHeader>

          {/* Thread */}
          <CardContent className="flex-1 overflow-y-auto py-4 space-y-3">
            {enquiry.messages?.length ? (
              enquiry.messages.map((m) => {
                const mine = m.senderId === me?.id;
                return (
                  <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[80%] rounded-lg px-4 py-2 ${mine ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                      {/* Only the other party was labelled, so a longer
                          back-and-forth was hard to follow. Label both sides. */}
                      <p className={`text-xs font-medium mb-1 ${mine ? "text-primary-foreground/80" : "opacity-80"}`}>
                        {mine
                          ? "You"
                          : m.senderName || (m.senderRole === "seller" ? "Exporter" : "Buyer")}
                      </p>
                      <p className="text-sm whitespace-pre-wrap break-words">{m.body}</p>
                      <p className={`text-[10px] mt-1 ${mine ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                        {format(new Date(m.createdAt), "MMM d, h:mm a")}
                      </p>
                    </div>
                  </div>
                );
              })
            ) : (
              <p className="text-sm text-muted-foreground text-center py-8">No messages yet.</p>
            )}
          </CardContent>

          {/* Composer */}
          <div className="border-t p-3 shrink-0">
            {me?.role === "admin" ? (
              <p className="text-sm text-muted-foreground text-center">
                You are viewing this conversation as an administrator. Only the buyer and
                the exporter can post to it.
              </p>
            ) : closed ? (
              <p className="text-sm text-muted-foreground text-center">This conversation is closed.</p>
            ) : (
              <form onSubmit={send} className="flex items-end gap-2">
                <Textarea
                  rows={2}
                  value={body}
                  onChange={(e) => setBody(e.target.value)}
                  placeholder="Type a message…"
                  className="flex-1 resize-none"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send(e as unknown as React.FormEvent);
                    }
                  }}
                />
                <Button type="submit" disabled={sendMessage.isPending || !body.trim()}>
                  {sendMessage.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                </Button>
              </form>
            )}
          </div>
        </Card>
      </div>
    </Layout>
  );
}
