import { usePageMeta } from "@/hooks/use-page-meta";
import { Link } from "wouter";
import { useGetMe, useListEnquiries, getListEnquiriesQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, MessageSquare, ChevronRight, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Enquiries() {
  usePageMeta("Enquiries");
  const { data: me } = useGetMe();
  const { data: enquiries, isLoading, isError, refetch } = useListEnquiries({}, { query: { enabled: !!me?.id, queryKey: getListEnquiriesQueryKey({}) } });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'open': return <Badge variant="secondary" className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">New</Badge>;
      case 'replied': return <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-emerald-200">Replied</Badge>;
      case 'closed': return <Badge variant="outline">Closed</Badge>;
      default: return null;
    }
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Enquiries</h1>
          {/* An admin sees every thread on the platform for moderation, none of
              which is theirs, so "your messages" was simply untrue for them. */}
          <p className="text-muted-foreground">
            {me?.role === "admin"
              ? "Every conversation on the platform, for moderation. You can read these threads but not reply to them."
              : "Manage your messages and trade requests."}
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div>
        ) : isError ? (
          <ErrorState label="Couldn't load enquiries" onRetry={() => refetch()} />
        ) : !enquiries?.length ? (
          <div className="text-center py-12 border rounded-lg bg-white">
            <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4 opacity-20" />
            <h3 className="text-lg font-medium">No enquiries yet</h3>
            <p className="text-muted-foreground">When you send or receive messages, they will appear here.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {enquiries.map((enq) => (
              <Link key={enq.id} href={`/enquiries/${enq.id}`}>
                <Card className="p-4 hover:border-primary/50 transition-colors cursor-pointer flex items-center gap-4">
                  <div className="bg-primary/5 p-3 rounded-full hidden sm:block">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <h4 className="font-semibold truncate">{enq.subject}</h4>
                      {getStatusBadge(enq.status)}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center justify-between">
                      <span className="truncate">
                        {me?.role === 'seller' ? `From: ${enq.buyer?.companyName || 'Buyer'}` : `To: ${enq.seller?.companyName || 'Seller'}`}
                      </span>
                      <span className="whitespace-nowrap flex items-center gap-1 text-xs"><Clock className="h-3 w-3"/> {formatDistanceToNow(new Date(enq.createdAt), { addSuffix: true })}</span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground" />
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}