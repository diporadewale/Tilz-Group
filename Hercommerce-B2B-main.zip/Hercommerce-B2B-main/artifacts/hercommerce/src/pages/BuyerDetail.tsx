import { useParams, Link } from "wouter";
import { useGetBuyerProfile, useGetMe, getGetBuyerProfileQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/Layout";
import { ErrorState } from "@/components/QueryState";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, MapPin, Globe, ArrowLeft, Building2 } from "lucide-react";

export default function BuyerDetail() {
  const { id } = useParams();
  const buyerId = parseInt(id || "0", 10);
  const { data: me } = useGetMe();
  const { data: buyer, isLoading, isError, refetch } = useGetBuyerProfile(buyerId, { query: { enabled: !!buyerId, queryKey: getGetBuyerProfileQueryKey(buyerId) } });

  if (isLoading) return <Layout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></Layout>;
  // Separate "no such buyer" from "the request failed".
  if (isError) {
    return (
      <Layout>
        <div className="max-w-3xl mx-auto">
          <ErrorState label="Couldn't load this buyer" onRetry={() => refetch()} />
        </div>
      </Layout>
    );
  }
  if (!buyer) return <Layout><div className="text-center py-12">Buyer not found.</div></Layout>;

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-6">
        <Link href="/matches" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back
        </Link>

        <div className="bg-white p-6 md:p-8 rounded-xl border shadow-sm">
          <h1 className="text-2xl sm:text-3xl font-bold font-serif text-foreground">{buyer.companyName}</h1>
          <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {buyer.city ? `${buyer.city}, ` : ''}{buyer.country}</span>
            {buyer.website && <a href={buyer.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline"><Globe className="h-4 w-4" /> Website</a>}
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>About the Buyer</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground whitespace-pre-wrap">{buyer.description || "No description provided."}</p>
              </CardContent>
            </Card>

            <div className="grid sm:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Interested Categories</CardTitle></CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  {buyer.interestedCategories?.map(c => <Badge key={c} variant="secondary">{c}</Badge>) || "None listed"}
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Preferred Origins</CardTitle></CardHeader>
                <CardContent className="flex flex-wrap gap-2">
                  {buyer.preferredOrigins?.map(o => <Badge key={o} variant="outline">{o}</Badge>) || "None listed"}
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sourcing Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="text-sm text-muted-foreground flex items-center gap-2"><Building2 className="h-4 w-4" /> Annual Budget</div>
                  <div className="font-medium">{buyer.annualBudget || "Not disclosed"}</div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}