import { useEffect } from "react";

const SITE = "Originance";

// Two problems, one cause: every route shared the single <title> and <link
// rel="canonical"> baked into index.html. So a search result for the exporter
// directory was titled the same as the homepage, and every page on every
// deployment claimed its canonical copy lived at https://originance.co/,
// a domain that did not resolve while the app was served from
// hercommerce-tau.vercel.app.
//
// Canonical now follows VITE_SITE_URL when set, and otherwise the origin
// actually serving the page, so a preview deployment points at itself instead
// of at a dead host. The site URL is public information, not a secret.
const BASE = (import.meta.env.VITE_SITE_URL as string | undefined)?.replace(/\/+$/, "");

function setMeta(selector: string, attr: "content" | "href", value: string) {
  const el = document.querySelector<HTMLMetaElement | HTMLLinkElement>(selector);
  if (el) el.setAttribute(attr, value);
}

/** Sets the document title, description and canonical URL for a route. */
export function usePageMeta(title?: string, description?: string): void {
  useEffect(() => {
    document.title = title ? `${title} · ${SITE}` : `${SITE}: Verified exporters from emerging markets`;

    const origin = BASE || window.location.origin;
    const url = `${origin}${window.location.pathname}`;
    setMeta('link[rel="canonical"]', "href", url);
    setMeta('meta[property="og:url"]', "content", url);
    setMeta('meta[property="og:title"]', "content", document.title);

    if (description) {
      setMeta('meta[name="description"]', "content", description);
      setMeta('meta[property="og:description"]', "content", description);
    }
  }, [title, description]);
}
