import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";

// Single source of truth for auth state. The session lives in an httpOnly
// cookie the browser sends automatically, so "are we signed in?" is simply
// "does GET /auth/me return a user?". retry:false so a 401 settles immediately
// to the signed-out state instead of retrying.
export function useAuth() {
  const query = useGetMe({
    query: { retry: false, queryKey: getGetMeQueryKey() },
  });

  return {
    user: query.data,
    isLoading: query.isLoading,
    isSignedIn: !!query.data,
  };
}
