import {
  Switch,
  Route,
  Router as WouterRouter,
  Redirect,
} from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { lazy, Suspense } from "react";
import { Loader2 } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import VerifyEmail from "./pages/VerifyEmail";
import NotFound from "./pages/not-found";
const Privacy = lazy(() => import("./pages/Legal").then((m) => ({ default: m.Privacy })));
const Terms = lazy(() => import("./pages/Legal").then((m) => ({ default: m.Terms })));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Onboarding = lazy(() => import("./pages/Onboarding"));
import Sellers from "./pages/Sellers";
import SellerDetail from "./pages/SellerDetail";
import Products from "./pages/Products";
const BuyerDetail = lazy(() => import("./pages/BuyerDetail"));
const Matches = lazy(() => import("./pages/Matches"));
const Documents = lazy(() => import("./pages/Documents"));
const MyProducts = lazy(() => import("./pages/MyProducts"));
const ProductDetail = lazy(() => import("./pages/ProductDetail"));
const Rfqs = lazy(() => import("./pages/Rfqs"));
const RfqMarket = lazy(() => import("./pages/RfqMarket"));
const RfqDetail = lazy(() => import("./pages/RfqDetail"));
const Profile = lazy(() => import("./pages/Profile"));
const Enquiries = lazy(() => import("./pages/Enquiries"));
const EnquiryDetail = lazy(() => import("./pages/EnquiryDetail"));
const AdminDashboard = lazy(() => import("./pages/Admin"));
const AdminUsers = lazy(() => import("./pages/AdminUsers"));
const AdminSellers = lazy(() => import("./pages/AdminSellers"));
const AdminDocuments = lazy(() => import("./pages/AdminDocuments"));

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function FullScreenLoader() {
  return (
    <div className="flex items-center justify-center min-h-[100dvh]">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}

// Gate a route behind a valid session. Redirects to /sign-in when signed out.
function RequireAuth({ children }: { children: React.ReactNode }) {
  const { isSignedIn, isLoading } = useAuth();
  if (isLoading) return <FullScreenLoader />;
  if (!isSignedIn) {
    // Carry where they were headed so sign-in can return them there. Without
    // this the main conversion path (exporter page → "Sign in to enquire")
    // dumped the user on the dashboard to find the exporter again.
    const here = window.location.pathname + window.location.search;
    return <Redirect to={`/sign-in?redirect=${encodeURIComponent(here)}`} />;
  }
  return <>{children}</>;
}

// Gate a route behind a role. The API is the real guard, every admin endpoint
// checks the role server-side, but without this a buyer could still navigate to
// /admin and be shown a broken shell of the admin UI full of failed requests.
function RequireRole({
  role,
  children,
}: {
  role: "buyer" | "seller" | "admin";
  children: React.ReactNode;
}) {
  const { user, isSignedIn, isLoading } = useAuth();
  if (isLoading) return <FullScreenLoader />;
  if (!isSignedIn) return <Redirect to="/sign-in" />;
  if (user?.role !== role) return <Redirect to="/dashboard" />;
  return <>{children}</>;
}

// Signed-in users have no business on the auth pages; previously /sign-in,
// /sign-up and /forgot-password all rendered normally while authenticated.
function RedirectIfSignedIn({ children }: { children: React.ReactNode }) {
  const { isSignedIn, isLoading } = useAuth();
  if (isLoading) return <FullScreenLoader />;
  if (isSignedIn) return <Redirect to="/dashboard" />;
  return <>{children}</>;
}

function HomeRedirect() {
  const { isSignedIn, isLoading } = useAuth();
  if (isLoading) return <FullScreenLoader />;
  if (isSignedIn) return <Redirect to="/dashboard" />;
  return <Home />;
}

function AppRouter() {
  return (
    <Switch>
      <Route path="/" component={HomeRedirect} />
      <Route path="/sign-in">
        <RedirectIfSignedIn>
          <Login />
        </RedirectIfSignedIn>
      </Route>
      <Route path="/sign-up">
        <RedirectIfSignedIn>
          <Register />
        </RedirectIfSignedIn>
      </Route>
      <Route path="/forgot-password">
        <RedirectIfSignedIn>
          <ForgotPassword />
        </RedirectIfSignedIn>
      </Route>
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/verify-email" component={VerifyEmail} />

      {/* Public */}
      <Route path="/privacy" component={Privacy} />
      <Route path="/terms" component={Terms} />
      <Route path="/sellers" component={Sellers} />
      <Route path="/sellers/:id" component={SellerDetail} />
      <Route path="/products" component={Products} />
      <Route path="/products/:id" component={ProductDetail} />

      {/* Protected */}
      <Route path="/dashboard">
        <RequireAuth>
          <Dashboard />
        </RequireAuth>
      </Route>
      <Route path="/onboarding">
        <RequireAuth>
          <Onboarding />
        </RequireAuth>
      </Route>
      <Route path="/buyers/:id">
        <RequireAuth>
          <BuyerDetail />
        </RequireAuth>
      </Route>
      <Route path="/matches">
        <RequireAuth>
          <Matches />
        </RequireAuth>
      </Route>
      <Route path="/documents">
        <RequireAuth>
          <Documents />
        </RequireAuth>
      </Route>
      <Route path="/my-products">
        <RequireAuth>
          <MyProducts />
        </RequireAuth>
      </Route>
      <Route path="/rfqs">
        <RequireAuth>
          <Rfqs />
        </RequireAuth>
      </Route>
      <Route path="/rfq-market">
        <RequireAuth>
          <RfqMarket />
        </RequireAuth>
      </Route>
      <Route path="/rfqs/:id">
        <RequireAuth>
          <RfqDetail />
        </RequireAuth>
      </Route>
      <Route path="/profile">
        <RequireAuth>
          <Profile />
        </RequireAuth>
      </Route>
      <Route path="/enquiries">
        <RequireAuth>
          <Enquiries />
        </RequireAuth>
      </Route>
      <Route path="/enquiries/:id">
        <RequireAuth>
          <EnquiryDetail />
        </RequireAuth>
      </Route>

      {/* Admin */}
      <Route path="/admin">
        <RequireRole role="admin">
          <AdminDashboard />
        </RequireRole>
      </Route>
      <Route path="/admin/users">
        <RequireRole role="admin">
          <AdminUsers />
        </RequireRole>
      </Route>
      <Route path="/admin/sellers">
        <RequireRole role="admin">
          <AdminSellers />
        </RequireRole>
      </Route>
      <Route path="/admin/documents">
        <RequireRole role="admin">
          <AdminDocuments />
        </RequireRole>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Don't burn three retries with backoff on a 4xx, an auth or permission
      // failure is not going to resolve itself, and the retries just delay the
      // error state the user needs to see.
      retry: (failureCount, error) => {
        const status = (error as { status?: number } | null)?.status;
        if (typeof status === "number" && status >= 400 && status < 500) return false;
        return failureCount < 2;
      },
      staleTime: 30_000,
      refetchOnWindowFocus: false,
    },
  },
});

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <WouterRouter base={basePath}>
            <Suspense fallback={<FullScreenLoader />}>
              <AppRouter />
            </Suspense>
          </WouterRouter>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
