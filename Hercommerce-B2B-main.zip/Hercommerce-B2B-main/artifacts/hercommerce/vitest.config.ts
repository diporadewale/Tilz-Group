import { defineConfig } from "vitest/config";
import path from "node:path";

// Pure-logic tests only (lib/*). Kept separate from vite.config.ts, which
// needs PORT and BASE_PATH and pulls in the dev-server plugins.
export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "src") } },
  test: { environment: "node", include: ["src/**/*.test.ts"] },
});
