import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
    // These are pure-function tests: no database, no network, no server. That is
    // deliberate. A suite that needs Postgres cannot run in CI or on a laptop
    // without setup, and one pointed at DATABASE_URL would mutate live data.
    // The authorisation rules were extracted into lib/access.ts precisely so the
    // matrix could be covered without either.
  },
});
