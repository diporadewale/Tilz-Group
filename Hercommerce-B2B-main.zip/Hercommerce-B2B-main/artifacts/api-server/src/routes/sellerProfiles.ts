import { Router, type IRouter } from "express";
import { eq, and, ilike, inArray, arrayContains, avg, count, isNull, type SQL } from "drizzle-orm";
import { db, sellerProfilesTable, usersTable, buyerProfilesTable, reviewsTable } from "@workspace/db";
import {
  ListSellerProfilesResponse,
  GetSellerProfileResponse,
  CreateSellerProfileBody,
  UpdateSellerProfileBody,
  UpdateSellerProfileParams,
  UpdateSellerProfileResponse,
  GetSellerMatchesResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { vocabError } from "../lib/vocab-check";
import { normaliseWebsite } from "../lib/website";
import { pageFrom } from "../lib/paging";
import { canManage, type Actor } from "../lib/access";

const router: IRouter = Router();

/** Adapts the request onto the pure predicates in lib/access.ts. */
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });


type SellerProfileRow = typeof sellerProfilesTable.$inferSelect;

// Batched enrichment: 2 queries total regardless of how many profiles come in.
// This used to be 2 queries *per profile* (user + reviews), so the directory
// cost 1 + 2N queries, at a few hundred exporters that alone would exceed
// Vercel's function timeout.
async function enrichSellerProfiles(profiles: SellerProfileRow[]) {
  if (profiles.length === 0) return [];

  const userIds = [...new Set(profiles.map((p) => p.userId))];
  const profileIds = profiles.map((p) => p.id);

  const [users, ratings] = await Promise.all([
    db.select().from(usersTable).where(inArray(usersTable.id, userIds)),
    db
      .select({
        sellerId: reviewsTable.sellerId,
        avg: avg(reviewsTable.rating),
        count: count(),
      })
      .from(reviewsTable)
      .where(inArray(reviewsTable.sellerId, profileIds))
      .groupBy(reviewsTable.sellerId),
  ]);

  const userMap = new Map(users.map((u) => [u.id, u]));
  const ratingMap = new Map(
    ratings.map((r) => [
      r.sellerId,
      {
        // Postgres avg() comes back as a numeric string.
        avgRating: r.avg === null ? null : Math.round(Number(r.avg) * 10) / 10,
        reviewCount: Number(r.count),
      },
    ]),
  );

  return profiles.map((p) => ({
    ...p,
    user: userMap.get(p.userId) ?? null,
    avgRating: ratingMap.get(p.id)?.avgRating ?? null,
    reviewCount: ratingMap.get(p.id)?.reviewCount ?? 0,
  }));
}

async function enrichSellerProfile(profile: SellerProfileRow) {
  const [only] = await enrichSellerProfiles([profile]);
  return only;
}

router.get("/seller-profiles", async (req: AuthRequest, res): Promise<void> => {
  const { country, category, tier, search, status } = req.query as Record<string, string>;

  // Filter in SQL. This previously loaded every seller profile in the database
  // on every directory hit and narrowed the list in JavaScript.
  const conditions: SQL[] = [];
  if (country) conditions.push(eq(sellerProfilesTable.country, country));
  if (tier === "unrated") {
    // Sentinel, not a stored value, an exporter with no tier yet was
    // previously unfilterable even though the directory shows them.
    conditions.push(isNull(sellerProfilesTable.readinessTier));
  } else if (tier) {
    conditions.push(
      eq(sellerProfilesTable.readinessTier, tier as "bronze" | "silver" | "gold" | "platinum"),
    );
  }
  if (status) {
    conditions.push(eq(sellerProfilesTable.status, status as "pending" | "approved" | "rejected"));
  }
  // Postgres array containment, the category must be one of the profile's.
  if (category) conditions.push(arrayContains(sellerProfilesTable.categories, [category]));
  if (search) conditions.push(ilike(sellerProfilesTable.companyName, `%${search}%`));

  const { limit, offset } = pageFrom(req.query);
  const profiles = await db
    .select()
    .from(sellerProfilesTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(sellerProfilesTable.createdAt)
    .limit(limit)
    .offset(offset);

  res.json(ListSellerProfilesResponse.parse(await enrichSellerProfiles(profiles)));
});

router.post("/seller-profiles", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateSellerProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Controlled fields are enforced here, not just offered as lists by the
  // form: matching compares these strings exactly, so an unlisted value never
  // matches anything. See lib/vocab-check.ts.
  const vocab = vocabError(parsed.data);
  if (vocab) {
    res.status(400).json({ error: vocab });
    return;
  }
  const site = normaliseWebsite(parsed.data.website);
  if (!site.ok) {
    res.status(400).json({ error: site.error });
    return;
  }
  if (site.value !== undefined) parsed.data.website = site.value;

  if (!req.dbUserId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [profile] = await db
    .insert(sellerProfilesTable)
    .values({
      userId: req.dbUserId,
      companyName: parsed.data.companyName,
      description: parsed.data.description ?? null,
      country: parsed.data.country,
      city: parsed.data.city ?? null,
      website: parsed.data.website ?? null,
      categories: parsed.data.categories ?? [],
      annualRevenue: parsed.data.annualRevenue ?? null,
      employeeCount: parsed.data.employeeCount ?? null,
      exportMarkets: parsed.data.exportMarkets ?? [],
      certifications: parsed.data.certifications ?? [],
      logoUrl: parsed.data.logoUrl ?? null,
    })
    .returning();

  // Creating a seller profile establishes the user's role server-side, so
  // onboarding never needs the admin-only user-update endpoint.
  await db
    .update(usersTable)
    .set({ role: "seller" })
    .where(eq(usersTable.id, req.dbUserId));

  const enriched = await enrichSellerProfile(profile);
  res.status(201).json(GetSellerProfileResponse.parse(enriched));
});

router.get("/seller-profiles/:id", async (req, res): Promise<void> => {
  const params = UpdateSellerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [profile] = await db
    .select()
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.id, params.data.id));

  if (!profile) {
    res.status(404).json({ error: "Seller profile not found" });
    return;
  }

  const enriched = await enrichSellerProfile(profile);
  res.json(GetSellerProfileResponse.parse(enriched));
});

router.patch("/seller-profiles/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateSellerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const parsed = UpdateSellerProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Controlled fields are enforced here, not just offered as lists by the
  // form: matching compares these strings exactly, so an unlisted value never
  // matches anything. See lib/vocab-check.ts.
  const vocab = vocabError(parsed.data);
  if (vocab) {
    res.status(400).json({ error: vocab });
    return;
  }
  const site = normaliseWebsite(parsed.data.website);
  if (!site.ok) {
    res.status(400).json({ error: site.error });
    return;
  }
  if (site.value !== undefined) parsed.data.website = site.value;

  const [existing] = await db
    .select({ userId: sellerProfilesTable.userId })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.id, params.data.id));
  if (!existing) {
    res.status(404).json({ error: "Seller profile not found" });
    return;
  }

  // Owner or admin only. Without this any signed-in user could rewrite any
  // other company's profile by guessing its id.
  const isAdmin = req.dbUserRole === "admin";
  if (!canManage(actorOf(req), existing.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const { status, ...ownerEditable } = parsed.data;

  // `status` is the admin verification verdict, a seller must not be able to
  // approve themselves (or reject a competitor) through their own profile edit.
  const changes = isAdmin && status !== undefined ? { ...ownerEditable, status } : ownerEditable;

  if (Object.keys(changes).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }

  const [updated] = await db
    .update(sellerProfilesTable)
    .set(changes)
    .where(eq(sellerProfilesTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Seller profile not found" });
    return;
  }

  const enriched = await enrichSellerProfile(updated);
  res.json(UpdateSellerProfileResponse.parse(enriched));
});

router.get("/seller-profiles/:id/matches", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateSellerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [seller] = await db
    .select()
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.id, params.data.id));

  if (!seller) {
    res.status(404).json({ error: "Seller not found" });
    return;
  }

  // This returns buyer companies and their contact users, effectively a lead
  // list. Owner or admin only; without this guard any signed-in account could
  // harvest the entire buyer base by passing any seller id.
  if (!canManage(actorOf(req), seller.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const buyers = await db
    .select()
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.status, "approved"))
    .limit(200);

  const matched = buyers.filter((b) => {
    const catMatch = b.interestedCategories.some((c) => seller.categories.includes(c));
    const originMatch = b.preferredOrigins.some((o) =>
      [seller.country, seller.city].includes(o),
    );
    return catMatch || originMatch;
  });

  // One user query for the whole match list rather than one per buyer.
  const buyerUserIds = [...new Set(matched.map((b) => b.userId))];
  const users = buyerUserIds.length
    ? await db.select().from(usersTable).where(inArray(usersTable.id, buyerUserIds))
    : [];
  const userMap = new Map(users.map((u) => [u.id, u]));

  const enriched = matched.map((b) => ({ ...b, user: userMap.get(b.userId) ?? null }));

  res.json(GetSellerMatchesResponse.parse(enriched));
});

export default router;
