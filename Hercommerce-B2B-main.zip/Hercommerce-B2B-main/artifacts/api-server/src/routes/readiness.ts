import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, readinessTiersTable, sellerProfilesTable } from "@workspace/db";
import {
  GetReadinessResponse,
  UpdateReadinessBody,
  UpdateReadinessParams,
  UpdateReadinessResponse,
} from "@workspace/api-zod";
import { requireAdmin, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { defaultReadiness, syncProfileBadge } from "../lib/readiness";

const router: IRouter = Router();

// Public: the seller detail page is reachable without signing in, so anonymous
// visitors need the readiness badge too. Readiness is published trust data, it
// is already rendered on the public directory cards.
router.get("/readiness/:sellerId", async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateReadinessParams.safeParse({ sellerId: req.params.sellerId });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [tier] = await db
    .select()
    .from(readinessTiersTable)
    .where(eq(readinessTiersTable.sellerId, params.data.sellerId));

  // A GET must never write (and previously any signed-in user could create
  // unlimited rows, and skew the admin tier breakdown, by probing ids).
  // Synthesise the default instead of persisting it.
  const row = tier ?? defaultReadiness(params.data.sellerId);

  // Internal moderation fields are not public. No client reads them from this
  // endpoint; admins see override history through the admin pages/audit notes.
  res.json(
    GetReadinessResponse.parse({
      ...row,
      adminNote: null,
      overriddenBy: null,
      overriddenAt: null,
    }),
  );
});

router.patch("/readiness/:sellerId", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateReadinessParams.safeParse({ sellerId: req.params.sellerId });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const parsed = UpdateReadinessBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // The seller must exist; the readiness row need not, since GET no longer
  // creates one. Overriding a seller who has never had a row computed is a
  // legitimate admin action, so upsert rather than 404.
  const [profile] = await db
    .select({ id: sellerProfilesTable.id })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.id, params.data.sellerId));
  if (!profile) {
    res.status(404).json({ error: "Exporter not found" });
    return;
  }

  const [existing] = await db
    .select()
    .from(readinessTiersTable)
    .where(eq(readinessTiersTable.sellerId, params.data.sellerId));

  const override = {
    tier: parsed.data.tier,
    adminNote: parsed.data.adminNote ?? null,
    adminOverride: true,
    overriddenBy: req.dbUserId ?? null,
    overriddenAt: new Date(),
  };

  const [updated] = existing
    ? await db
        .update(readinessTiersTable)
        .set(override)
        .where(eq(readinessTiersTable.id, existing.id))
        .returning()
    : await db
        .insert(readinessTiersTable)
        .values({ sellerId: params.data.sellerId, score: 0, ...override })
        .returning();

  // Keep the denormalised badge in sync, otherwise the override never shows up
  // on directory cards, match results or quote rows.
  await syncProfileBadge(params.data.sellerId, updated.tier);

  res.json(UpdateReadinessResponse.parse(updated));
});

export default router;
