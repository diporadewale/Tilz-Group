import { Router, type IRouter } from "express";
import { HealthCheckResponse, GetClientConfigResponse } from "@workspace/api-zod";
import { isIntentAssistConfigured } from "../lib/intent";
import { isGoogleAuthConfigured } from "../lib/google-oauth";

const router: IRouter = Router();

router.get("/healthz", (_req, res) => {
  const data = HealthCheckResponse.parse({ status: "ok" });
  res.json(data);
});

// Public feature flags. The SPA reads this before rendering optional UI so a
// deployment without an Anthropic key never shows a control that cannot work.
router.get("/config", (_req, res) => {
  res.json(
    GetClientConfigResponse.parse({
      intentAssist: isIntentAssistConfigured(),
      googleAuth: isGoogleAuthConfigured(),
    }),
  );
});

export default router;
