import { Router, type IRouter } from "express";
import { eq, and, or, inArray, isNull, desc, count, arrayContains } from "drizzle-orm";
import {
  db,
  rfqsTable,
  rfqQuotesTable,
  buyerProfilesTable,
  sellerProfilesTable,
} from "@workspace/db";
import {
  ListRfqsResponse,
  GetRfqResponse,
  GetRfqParams,
  CreateRfqBody,
  CreateRfqQuoteBody,
  CreateRfqQuoteParams,
  UpdateRfqBody,
  UpdateRfqParams,
  UpdateRfqResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { vocabError } from "../lib/vocab-check";
import { canManage, type Actor } from "../lib/access";
import { notify, notifyMany } from "../lib/notifications";
import { firstNumericError } from "../lib/numeric";

const router: IRouter = Router();

/** Adapts the request onto the pure predicates in lib/access.ts. */
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });


type RfqRow = typeof rfqsTable.$inferSelect;
type QuoteRow = typeof rfqQuotesTable.$inferSelect;

async function buyerProfileFor(userId: number) {
  const [p] = await db.select().from(buyerProfilesTable).where(eq(buyerProfilesTable.userId, userId));
  return p ?? null;
}
async function sellerProfileFor(userId: number) {
  const [p] = await db.select().from(sellerProfilesTable).where(eq(sellerProfilesTable.userId, userId));
  return p ?? null;
}

// Batched: one seller lookup for the whole quote list rather than one per quote.
async function enrichQuotes(quotes: QuoteRow[]) {
  if (quotes.length === 0) return [];

  const sellerIds = [...new Set(quotes.map((q) => q.sellerId))];
  const sellers = await db
    .select({
      id: sellerProfilesTable.id,
      companyName: sellerProfilesTable.companyName,
      tier: sellerProfilesTable.readinessTier,
    })
    .from(sellerProfilesTable)
    .where(inArray(sellerProfilesTable.id, sellerIds));
  const sellerMap = new Map(sellers.map((s) => [s.id, s]));

  return quotes.map((q) => ({
    ...q,
    sellerCompany: sellerMap.get(q.sellerId)?.companyName ?? null,
    sellerTier: sellerMap.get(q.sellerId)?.tier ?? null,
  }));
}

async function enrichQuote(q: QuoteRow) {
  const [only] = await enrichQuotes([q]);
  return only;
}

// Attach buyerCompany + quoteCount to a set of RFQs (batched, no N+1).
async function enrichRfqList(rfqs: RfqRow[]) {
  if (rfqs.length === 0) return [];
  const ids = rfqs.map((r) => r.id);
  const buyerIds = [...new Set(rfqs.map((r) => r.buyerId))];

  const buyers = await db
    .select({ id: buyerProfilesTable.id, companyName: buyerProfilesTable.companyName })
    .from(buyerProfilesTable)
    .where(inArray(buyerProfilesTable.id, buyerIds));
  const buyerMap = new Map(buyers.map((b) => [b.id, b.companyName]));

  const quotes = await db
    .select({ rfqId: rfqQuotesTable.rfqId })
    .from(rfqQuotesTable)
    .where(inArray(rfqQuotesTable.rfqId, ids));
  const counts = new Map<number, number>();
  for (const q of quotes) counts.set(q.rfqId, (counts.get(q.rfqId) ?? 0) + 1);

  return rfqs.map((r) => ({
    ...r,
    buyerCompany: buyerMap.get(r.buyerId) ?? null,
    quoteCount: counts.get(r.id) ?? 0,
  }));
}

router.get(
  "/rfqs",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const scope = (req.query.scope as string) ?? (req.dbUserRole === "seller" ? "market" : "mine");
    const status = req.query.status as "open" | "closed" | undefined;

    let rows: RfqRow[] = [];

    if (scope === "market") {
      // Sellers see open RFQs matching their categories (or uncategorised ones).
      const seller = await sellerProfileFor(req.dbUserId!);
      const cats = seller?.categories ?? [];
      const base = eq(rfqsTable.status, "open");
      const where = cats.length
        ? and(base, or(inArray(rfqsTable.category, cats), isNull(rfqsTable.category)))
        : base;
      rows = await db.select().from(rfqsTable).where(where).orderBy(desc(rfqsTable.createdAt));
    } else {
      // A buyer's own RFQs.
      const buyer = await buyerProfileFor(req.dbUserId!);
      if (!buyer) {
        res.json(ListRfqsResponse.parse([]));
        return;
      }
      const where = status
        ? and(eq(rfqsTable.buyerId, buyer.id), eq(rfqsTable.status, status))
        : eq(rfqsTable.buyerId, buyer.id);
      rows = await db.select().from(rfqsTable).where(where).orderBy(desc(rfqsTable.createdAt));
    }

    res.json(ListRfqsResponse.parse(await enrichRfqList(rows)));
  },
);

router.post(
  "/rfqs",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const parsed = CreateRfqBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }
    // Category and destination country are matched against sellers' profiles
    // by exact string; an unlisted value would route this RFQ to nobody.
    const vocab = vocabError(parsed.data);
    if (vocab) {
      res.status(400).json({ error: vocab });
      return;
    }
    const numericError = firstNumericError({
      Quantity: parsed.data.quantity,
      "Target price": parsed.data.targetPrice,
    });
    if (numericError) {
      res.status(400).json({ error: numericError });
      return;
    }
    // Refused rather than defaulted: silently assuming USD would recreate the
    // ambiguity this field exists to remove.
    if (parsed.data.targetPrice && !parsed.data.targetCurrency) {
      res.status(400).json({ error: "Choose a currency for the target price." });
      return;
    }

    const buyer = await buyerProfileFor(req.dbUserId!);
    if (!buyer) {
      res.status(403).json({ error: "Only buyers with a profile can post RFQs" });
      return;
    }

    const [created] = await db
      .insert(rfqsTable)
      .values({
        buyerId: buyer.id,
        title: parsed.data.title,
        description: parsed.data.description,
        category: parsed.data.category ?? null,
        quantity: parsed.data.quantity ?? null,
        unit: parsed.data.unit ?? null,
        targetPrice: parsed.data.targetPrice ?? null,
        targetCurrency: parsed.data.targetPrice ? (parsed.data.targetCurrency ?? null) : null,
        destinationCountry: parsed.data.destinationCountry ?? null,
      })
      .returning();

    // Notify exporters whose categories match this RFQ. Matched in SQL via array
    // containment, this used to load every seller profile in the database and
    // filter in JavaScript on every RFQ post.
    if (created.category) {
      const matched = await db
        .select({ userId: sellerProfilesTable.userId })
        .from(sellerProfilesTable)
        .where(arrayContains(sellerProfilesTable.categories, [created.category]));

      await notifyMany(
        matched.map((s) => s.userId),
        {
          type: "rfq",
          title: `New RFQ matching your products: ${created.title}`,
          link: "/rfq-market",
        },
      );
    }

    res.status(201).json(
      GetRfqResponse.parse({ ...created, buyerCompany: buyer.companyName, quoteCount: 0, quotes: [] }),
    );
  },
);

router.get(
  "/rfqs/:id",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const params = GetRfqParams.safeParse({ id: req.params.id });
    if (!params.success) {
      res.status(400).json({ error: validationMessage(params.error) });
      return;
    }

    const [rfq] = await db.select().from(rfqsTable).where(eq(rfqsTable.id, params.data.id));
    if (!rfq) {
      res.status(404).json({ error: "RFQ not found" });
      return;
    }

    const [buyer] = await db
      .select({ companyName: buyerProfilesTable.companyName, userId: buyerProfilesTable.userId })
      .from(buyerProfilesTable)
      .where(eq(buyerProfilesTable.id, rfq.buyerId));
    const isOwner = !!buyer && buyer.userId === req.dbUserId;

    // The buyer owner sees every quote; a seller sees only their own.
    let quoteRows: QuoteRow[];
    if (isOwner) {
      quoteRows = await db
        .select()
        .from(rfqQuotesTable)
        .where(eq(rfqQuotesTable.rfqId, rfq.id))
        .orderBy(desc(rfqQuotesTable.createdAt));
    } else {
      const seller = await sellerProfileFor(req.dbUserId!);
      quoteRows = seller
        ? await db
            .select()
            .from(rfqQuotesTable)
            .where(and(eq(rfqQuotesTable.rfqId, rfq.id), eq(rfqQuotesTable.sellerId, seller.id)))
            .orderBy(desc(rfqQuotesTable.createdAt))
        : [];
    }

    // Count in SQL rather than fetching every row just to read `.length`.
    const [countRow] = await db
      .select({ value: count() })
      .from(rfqQuotesTable)
      .where(eq(rfqQuotesTable.rfqId, rfq.id));

    res.json(
      GetRfqResponse.parse({
        ...rfq,
        buyerCompany: buyer?.companyName ?? null,
        quoteCount: Number(countRow.value),
        quotes: await enrichQuotes(quoteRows),
      }),
    );
  },
);

router.patch(
  "/rfqs/:id",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const params = UpdateRfqParams.safeParse({ id: req.params.id });
    if (!params.success) {
      res.status(400).json({ error: validationMessage(params.error) });
      return;
    }
    const parsed = UpdateRfqBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }

    const [rfq] = await db.select().from(rfqsTable).where(eq(rfqsTable.id, params.data.id));
    if (!rfq) {
      res.status(404).json({ error: "RFQ not found" });
      return;
    }

    // Only the buyer who posted it (or an admin) can change its status.
    const [buyer] = await db
      .select({ userId: buyerProfilesTable.userId, companyName: buyerProfilesTable.companyName })
      .from(buyerProfilesTable)
      .where(eq(buyerProfilesTable.id, rfq.buyerId));

    if (!canManage(actorOf(req), buyer?.userId)) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const [updated] = await db
      .update(rfqsTable)
      .set({ status: parsed.data.status })
      .where(eq(rfqsTable.id, params.data.id))
      .returning();

    const [countRow] = await db
      .select({ value: count() })
      .from(rfqQuotesTable)
      .where(eq(rfqQuotesTable.rfqId, updated.id));

    const quoteRows = await db
      .select()
      .from(rfqQuotesTable)
      .where(eq(rfqQuotesTable.rfqId, updated.id))
      .orderBy(desc(rfqQuotesTable.createdAt));

    res.json(
      UpdateRfqResponse.parse({
        ...updated,
        buyerCompany: buyer?.companyName ?? null,
        quoteCount: Number(countRow.value),
        quotes: await enrichQuotes(quoteRows),
      }),
    );
  },
);

router.post(
  "/rfqs/:id/quotes",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const params = CreateRfqQuoteParams.safeParse({ id: req.params.id });
    if (!params.success) {
      res.status(400).json({ error: validationMessage(params.error) });
      return;
    }
    const parsed = CreateRfqQuoteBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }
    // A comparable quote needs a real number and listed currency, unit and
    // Incoterm; that is the whole point of structuring it.
    const quoteVocab = vocabError(parsed.data);
    if (quoteVocab) {
      res.status(400).json({ error: quoteVocab });
      return;
    }
    const priceError = firstNumericError({ "Unit price": parsed.data.unitPrice });
    if (priceError) {
      res.status(400).json({ error: priceError });
      return;
    }

    const seller = await sellerProfileFor(req.dbUserId!);
    if (!seller) {
      res.status(403).json({ error: "Only exporters with a profile can quote" });
      return;
    }

    const [rfq] = await db.select().from(rfqsTable).where(eq(rfqsTable.id, params.data.id));
    if (!rfq) {
      res.status(404).json({ error: "RFQ not found" });
      return;
    }
    if (rfq.status !== "open") {
      res.status(400).json({ error: "This RFQ is closed" });
      return;
    }

    // One quote per seller per RFQ, resubmitting revises the existing quote
    // instead of stacking duplicates in the buyer's list.
    const [existingQuote] = await db
      .select({ id: rfqQuotesTable.id })
      .from(rfqQuotesTable)
      .where(and(eq(rfqQuotesTable.rfqId, rfq.id), eq(rfqQuotesTable.sellerId, seller.id)));

    const values = {
      // Revising a legacy quote replaces its free-text price with structure.
      price: null,
      unitPrice: parsed.data.unitPrice.trim(),
      currency: parsed.data.currency,
      unit: parsed.data.unit,
      incoterm: parsed.data.incoterm ?? null,
      incotermPlace: parsed.data.incotermPlace?.trim() || null,
      leadTime: parsed.data.leadTime ?? null,
      message: parsed.data.message ?? null,
    };

    const [created] = existingQuote
      ? await db
          .update(rfqQuotesTable)
          .set(values)
          .where(eq(rfqQuotesTable.id, existingQuote.id))
          .returning()
      : await db
          .insert(rfqQuotesTable)
          .values({ rfqId: rfq.id, sellerId: seller.id, ...values })
          .returning();

    // Notify the buyer who owns the RFQ.
    const [buyer] = await db
      .select({ userId: buyerProfilesTable.userId })
      .from(buyerProfilesTable)
      .where(eq(buyerProfilesTable.id, rfq.buyerId));
    if (buyer?.userId) {
      await notify(buyer.userId, {
        type: "quote",
        title: `${existingQuote ? "Revised" : "New"} quote on: ${rfq.title}`,
        link: `/rfqs/${rfq.id}`,
      });
    }

    res.status(201).json(await enrichQuote(created));
  },
);

export default router;
