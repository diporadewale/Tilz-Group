import { Router, type IRouter } from "express";
import { eq, and, isNull, desc, count } from "drizzle-orm";
import { db, notificationsTable } from "@workspace/db";
import { ListNotificationsResponse, GetUnreadCountResponse } from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.get("/notifications", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const rows = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, req.dbUserId!))
    .orderBy(desc(notificationsTable.createdAt))
    .limit(50);
  res.json(ListNotificationsResponse.parse(rows));
});

router.get("/notifications/unread-count", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  // Counted in SQL, every signed-in client polls this every 30s, so fetching
  // every unread row just to read `.length` is the wrong shape.
  const [row] = await db
    .select({ value: count() })
    .from(notificationsTable)
    .where(and(eq(notificationsTable.userId, req.dbUserId!), isNull(notificationsTable.readAt)));
  res.json(GetUnreadCountResponse.parse({ count: Number(row.value) }));
});

router.post("/notifications/read-all", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  await db
    .update(notificationsTable)
    .set({ readAt: new Date() })
    .where(and(eq(notificationsTable.userId, req.dbUserId!), isNull(notificationsTable.readAt)));
  res.status(204).end();
});

export default router;
