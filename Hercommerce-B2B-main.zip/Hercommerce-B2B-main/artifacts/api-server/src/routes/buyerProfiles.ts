import { Router, type IRouter } from "express";
import { eq, and, ilike, inArray, type SQL } from "drizzle-orm";
import { db, buyerProfilesTable, usersTable, sellerProfilesTable, readinessTiersTable } from "@workspace/db";
import {
  ListBuyerProfilesResponse,
  GetBuyerProfileResponse,
  CreateBuyerProfileBody,
  UpdateBuyerProfileBody,
  UpdateBuyerProfileParams,
  UpdateBuyerProfileResponse,
  GetBuyerMatchesResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { vocabError } from "../lib/vocab-check";
import { normaliseWebsite } from "../lib/website";
import { canManage, type Actor } from "../lib/access";

const router: IRouter = Router();

/** Adapts the request onto the pure predicates in lib/access.ts. */
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });


type BuyerProfileRow = typeof buyerProfilesTable.$inferSelect;

// Batched: one user query for the whole list rather than one per profile.
async function enrichBuyerProfiles(profiles: BuyerProfileRow[]) {
  if (profiles.length === 0) return [];

  const userIds = [...new Set(profiles.map((p) => p.userId))];
  const users = await db.select().from(usersTable).where(inArray(usersTable.id, userIds));
  const userMap = new Map(users.map((u) => [u.id, u]));

  return profiles.map((p) => ({ ...p, user: userMap.get(p.userId) ?? null }));
}

async function enrichBuyerProfile(profile: BuyerProfileRow) {
  const [only] = await enrichBuyerProfiles([profile]);
  return only;
}

router.get("/buyer-profiles", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const { search, status } = req.query as Record<string, string>;

  // Buyer profiles are NOT public. Unlike exporters (who list themselves in a
  // public directory), a buyer's company, sourcing interests and contact email
  // are private. This endpoint used to return all of them to any signed-in
  // account, which is a ready-made lead list. Non-admins see only their own.
  const conditions: SQL[] = [];

  if (req.dbUserRole !== "admin") {
    conditions.push(eq(buyerProfilesTable.userId, req.dbUserId!));
  } else {
    if (status) {
      conditions.push(eq(buyerProfilesTable.status, status as "pending" | "approved" | "rejected"));
    }
    if (search) conditions.push(ilike(buyerProfilesTable.companyName, `%${search}%`));
  }

  const profiles = await db
    .select()
    .from(buyerProfilesTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(buyerProfilesTable.createdAt)
    .limit(200);

  res.json(ListBuyerProfilesResponse.parse(await enrichBuyerProfiles(profiles)));
});

router.post("/buyer-profiles", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateBuyerProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Controlled fields are enforced here, not just offered as lists by the
  // form: matching compares these strings exactly, so an unlisted value never
  // matches anything. See lib/vocab-check.ts.
  const vocab = vocabError(parsed.data);
  if (vocab) {
    res.status(400).json({ error: vocab });
    return;
  }
  const site = normaliseWebsite(parsed.data.website);
  if (!site.ok) {
    res.status(400).json({ error: site.error });
    return;
  }
  if (site.value !== undefined) parsed.data.website = site.value;

  if (!req.dbUserId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [profile] = await db
    .insert(buyerProfilesTable)
    .values({
      userId: req.dbUserId,
      companyName: parsed.data.companyName,
      description: parsed.data.description ?? null,
      country: parsed.data.country,
      city: parsed.data.city ?? null,
      website: parsed.data.website ?? null,
      interestedCategories: parsed.data.interestedCategories ?? [],
      preferredOrigins: parsed.data.preferredOrigins ?? [],
      annualBudget: parsed.data.annualBudget ?? null,
    })
    .returning();

  // Creating a buyer profile establishes the user's role server-side, so
  // onboarding never needs the admin-only user-update endpoint.
  await db
    .update(usersTable)
    .set({ role: "buyer" })
    .where(eq(usersTable.id, req.dbUserId));

  const enriched = await enrichBuyerProfile(profile);
  res.status(201).json(GetBuyerProfileResponse.parse(enriched));
});

router.get("/buyer-profiles/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateBuyerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  // Owner or admin only. The list endpoint above was scoped to self, but this
  // one was not, so any signed-in account could still walk the id space and
  // read every buyer's company, contact email and annual sourcing budget one
  // row at a time. Buyer profiles are private, and the privacy policy says so.
  const [profile] = await db
    .select()
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.id, params.data.id));

  if (!profile) {
    res.status(404).json({ error: "Buyer profile not found" });
    return;
  }

  if (!canManage(actorOf(req), profile.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const enriched = await enrichBuyerProfile(profile);
  res.json(GetBuyerProfileResponse.parse(enriched));
});

router.patch("/buyer-profiles/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateBuyerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const parsed = UpdateBuyerProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Controlled fields are enforced here, not just offered as lists by the
  // form: matching compares these strings exactly, so an unlisted value never
  // matches anything. See lib/vocab-check.ts.
  const vocab = vocabError(parsed.data);
  if (vocab) {
    res.status(400).json({ error: vocab });
    return;
  }
  const site = normaliseWebsite(parsed.data.website);
  if (!site.ok) {
    res.status(400).json({ error: site.error });
    return;
  }
  if (site.value !== undefined) parsed.data.website = site.value;

  const [existing] = await db
    .select({ userId: buyerProfilesTable.userId })
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.id, params.data.id));
  if (!existing) {
    res.status(404).json({ error: "Buyer profile not found" });
    return;
  }

  // Owner or admin only, see the matching guard on seller profiles.
  const isAdmin = req.dbUserRole === "admin";
  if (!canManage(actorOf(req), existing.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const { status, ...ownerEditable } = parsed.data;

  // `status` is the admin verification verdict, not a self-service field.
  const changes = isAdmin && status !== undefined ? { ...ownerEditable, status } : ownerEditable;

  if (Object.keys(changes).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }

  const [updated] = await db
    .update(buyerProfilesTable)
    .set(changes)
    .where(eq(buyerProfilesTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Buyer profile not found" });
    return;
  }

  const enriched = await enrichBuyerProfile(updated);
  res.json(UpdateBuyerProfileResponse.parse(enriched));
});

router.get("/buyer-profiles/:id/matches", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateBuyerProfileParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [buyer] = await db
    .select()
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.id, params.data.id));

  if (!buyer) {
    res.status(404).json({ error: "Buyer not found" });
    return;
  }

  // A buyer's match list is derived from their private sourcing preferences.
  // Owner or admin only.
  if (!canManage(actorOf(req), buyer.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const sellers = await db
    .select()
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.status, "approved"))
    .limit(200);

  // Pre-load the readiness rows and users for every candidate in two queries
  // instead of two queries per candidate.
  const sellerIds = sellers.map((s) => s.id);
  const sellerUserIds = [...new Set(sellers.map((s) => s.userId))];

  const [tierRows, users] = sellers.length
    ? await Promise.all([
        db
          .select({
            sellerId: readinessTiersTable.sellerId,
            documentsVerified: readinessTiersTable.documentsVerified,
          })
          .from(readinessTiersTable)
          .where(inArray(readinessTiersTable.sellerId, sellerIds)),
        db.select().from(usersTable).where(inArray(usersTable.id, sellerUserIds)),
      ])
    : [[], []];

  const verifiedMap = new Map(tierRows.map((t) => [t.sellerId, t.documentsVerified]));
  const userMap = new Map(users.map((u) => [u.id, u]));

  const matches = sellers.map((seller) => {
      const matchReasons: string[] = [];
      let score = 0;

      const catOverlap = seller.categories.filter((c) =>
        buyer.interestedCategories.includes(c),
      );
      // Proportional, not cumulative. At 20 points per overlapping category, a
      // seller covering the buyer's only interest scored 20 and could reach at
      // most 75 overall however good they were, so an ideal match presented as
      // a mediocre one. Score the share of the buyer's interests covered.
      if (catOverlap.length > 0) {
        const wanted = buyer.interestedCategories.length || 1;
        score += Math.round((Math.min(catOverlap.length, wanted) / wanted) * 45);
        matchReasons.push(`Matching categories: ${catOverlap.join(", ")}`);
      }

      const originMatch = buyer.preferredOrigins.includes(seller.country);
      if (originMatch) {
        score += 30;
        matchReasons.push(`Exports from ${seller.country}`);
      }

      if (seller.readinessTier === "gold" || seller.readinessTier === "platinum") {
        score += 15;
        matchReasons.push(
          `${seller.readinessTier.charAt(0).toUpperCase() + seller.readinessTier.slice(1)} tier exporter`,
        );
      }

      if ((verifiedMap.get(seller.id) ?? 0) >= 3) {
        score += 10;
        matchReasons.push("Fully verified documents");
      }

      return {
        seller: { ...seller, user: userMap.get(seller.userId) ?? null },
        matchScore: Math.min(score, 100),
        matchReasons,
      };
  });

  const sorted = matches
    .filter((m) => m.matchScore > 0)
    .sort((a, b) => b.matchScore - a.matchScore);

  res.json(GetBuyerMatchesResponse.parse(sorted));
});

export default router;
