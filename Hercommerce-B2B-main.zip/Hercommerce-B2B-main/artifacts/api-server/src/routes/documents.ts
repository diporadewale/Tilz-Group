import { Router, type IRouter } from "express";
import { eq, and, type SQL } from "drizzle-orm";
import { db, documentsTable, usersTable } from "@workspace/db";
import {
  ListDocumentsResponse,
  ListDocumentsQueryParams,
  GetDocumentResponse,
  UploadDocumentBody,
  VerifyDocumentBody,
  VerifyDocumentParams,
  VerifyDocumentResponse,
} from "@workspace/api-zod";
import { requireAuth, requireAdmin, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { canManage, type Actor } from "../lib/access";
import { sendDocumentStatusEmail } from "../lib/email";
import { recalculateReadinessForUser } from "../lib/readiness";
import { handleUpload, type HandleUploadBody } from "@vercel/blob/client";
import { get as getBlob } from "@vercel/blob";
import { Readable } from "node:stream";

// The `type` filter arrives as a free-form string in the contract; narrow it to
// the column's enum before it reaches the query.
const DOCUMENT_TYPES = [
  "business_registration",
  "tax_certificate",
  "export_license",
  "product_catalog",
  "quality_certificate",
  "other",
] as const;

type DocumentType = (typeof DOCUMENT_TYPES)[number];

const isDocumentType = (value: string): value is DocumentType =>
  (DOCUMENT_TYPES as readonly string[]).includes(value);

const router: IRouter = Router();

/** Adapts the request onto the pure predicates in lib/access.ts. */
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });


// Issues a short-lived client token so the browser uploads directly to Vercel
// Blob (bypassing the 4.5MB serverless body limit) without ever seeing the
// write token. Speaks the Blob client protocol, so it's outside the OpenAPI
// contract.
//
// Two stores, because Vercel Blob sets access per STORE, not per blob:
//   ORG_BLOB_DOCS_READ_WRITE_TOKEN  private  verification documents
//   BLOB_READ_WRITE_TOKEN           public   product photos (public catalogue)
//
// The client picks by prefixing the pathname, "documents/..." or "products/...".
// That prefix is present in both Blob callback shapes and stays visible in the
// stored URL, which a clientPayload would not. It is not a trust boundary: a
// caller can only mis-file their own upload, and either way the download route
// then fails for them and nobody else.
const IMAGE_TYPES = ["image/png", "image/jpeg", "image/webp"];
const DOCUMENT_TYPES_ALLOWED = ["application/pdf", ...IMAGE_TYPES];

/** The upload's pathname, from either the generate-token or upload-completed event. */
function uploadPathname(body: unknown): string {
  const payload = (body as { payload?: { pathname?: unknown; blob?: { pathname?: unknown } } })?.payload;
  const direct = payload?.pathname;
  if (typeof direct === "string") return direct;
  const completed = payload?.blob?.pathname;
  return typeof completed === "string" ? completed : "";
}

const isDocumentUpload = (pathname: string): boolean => pathname.startsWith("documents/");

router.post(
  "/documents/blob-upload",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const pathname = uploadPathname(req.body);
    const wantsPrivate = isDocumentUpload(pathname);
    const token = wantsPrivate
      ? process.env.ORG_BLOB_DOCS_READ_WRITE_TOKEN
      : process.env.BLOB_READ_WRITE_TOKEN;

    // Without a token `handleUpload` throws a generic error that used to
    // surface as a bare 400, indistinguishable from a rejected file, and only
    // visible in devtools. Name the actual cause, and which store is missing.
    if (!token) {
      res.status(503).json({
        error: wantsPrivate
          ? "Document uploads are not configured on this server (ORG_BLOB_DOCS_READ_WRITE_TOKEN is missing)."
          : "File uploads are not configured on this server (BLOB_READ_WRITE_TOKEN is missing).",
      });
      return;
    }

    try {
      const result = await handleUpload({
        token,
        body: req.body as HandleUploadBody,
        request: req,
        onBeforeGenerateToken: async () => ({
          // A product photo has no reason to accept a PDF; it renders in an
          // <img> on the public catalogue and would silently show as broken.
          allowedContentTypes: wantsPrivate ? DOCUMENT_TYPES_ALLOWED : IMAGE_TYPES,
          maximumSizeInBytes: 10 * 1024 * 1024,
          addRandomSuffix: true,
          tokenPayload: JSON.stringify({ userId: req.dbUserId }),
        }),
        onUploadCompleted: async () => {
          // The client records the document via POST /documents after upload.
        },
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  },
);

router.get("/documents", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const query = ListDocumentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: validationMessage(query.error) });
    return;
  }
  const { userId, status, type } = query.data;

  // Scope and filter in SQL. This previously loaded every document in the system
  // on every request and narrowed it in JavaScript.
  const conditions: SQL[] = [];

  if (req.dbUserRole !== "admin") {
    conditions.push(eq(documentsTable.userId, req.dbUserId!));
  } else if (userId !== undefined) {
    conditions.push(eq(documentsTable.userId, userId));
  }

  if (status) conditions.push(eq(documentsTable.status, status));
  if (type) {
    if (!isDocumentType(type)) {
      res.status(400).json({ error: "Invalid document type" });
      return;
    }
    conditions.push(eq(documentsTable.documentType, type));
  }

  const docs = await db
    .select()
    .from(documentsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(documentsTable.createdAt);

  res.json(ListDocumentsResponse.parse(docs));
});

router.post("/documents", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = UploadDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  if (!req.dbUserId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [doc] = await db
    .insert(documentsTable)
    .values({
      userId: req.dbUserId,
      documentType: parsed.data.documentType,
      fileName: parsed.data.fileName,
      fileUrl: parsed.data.fileUrl,
      storageAccess: parsed.data.storageAccess ?? "public",
      notes: parsed.data.notes ?? null,
    })
    .returning();

  res.status(201).json(GetDocumentResponse.parse(doc));
});

// Verification documents live in a private blob store, so their URL is not
// fetchable on its own. This is the only way to read one, and it checks that
// the caller owns the document or is an admin, which is what the privacy
// policy's "visible only to you and to our administrators" actually requires.
//
// Streams rather than redirects: a redirect to a signed CDN URL would put a
// fetchable link in browser history and the referrer chain, which is the
// weakness this replaces. Uploads are capped at 10MB, well inside the
// serverless response budget.
//
// Registered before /documents/:id so ":id" does not swallow "/file".
router.get("/documents/:id/file", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = VerifyDocumentParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(eq(documentsTable.id, params.data.id));
  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  if (!canManage(actorOf(req), doc.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  // Uploaded before the private store existed: the blob is genuinely public,
  // so there is nothing to unwrap and a redirect is honest about that.
  if (doc.storageAccess === "public") {
    res.redirect(doc.fileUrl);
    return;
  }

  const docsToken = process.env.ORG_BLOB_DOCS_READ_WRITE_TOKEN;
  if (!docsToken) {
    res.status(503).json({ error: "File downloads are not configured on this server." });
    return;
  }

  try {
    const result = await getBlob(doc.fileUrl, { access: "private", token: docsToken });
    // Null when the blob is gone from the store, e.g. deleted out of band.
    if (!result || result.statusCode !== 200 || !result.stream) {
      res.status(502).json({ error: "That file could not be retrieved from storage." });
      return;
    }
    res.setHeader("Content-Type", result.blob.contentType || "application/octet-stream");
    res.setHeader("Content-Length", String(result.blob.size));
    // inline so an admin reviewing the queue sees the PDF rather than saving it.
    res.setHeader("Content-Disposition", `inline; filename="${encodeURIComponent(doc.fileName)}"`);
    res.setHeader("Cache-Control", "private, no-store");
    Readable.fromWeb(result.stream as Parameters<typeof Readable.fromWeb>[0]).pipe(res);
  } catch {
    res.status(502).json({ error: "That file could not be retrieved from storage." });
  }
});

router.get("/documents/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = VerifyDocumentParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [doc] = await db
    .select()
    .from(documentsTable)
    .where(eq(documentsTable.id, params.data.id));

  if (!doc) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  if (!canManage(actorOf(req), doc.userId)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  res.json(GetDocumentResponse.parse(doc));
});

router.patch("/documents/:id/verify", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const params = VerifyDocumentParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const parsed = VerifyDocumentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const [updated] = await db
    .update(documentsTable)
    .set({
      status: parsed.data.status,
      verifiedBy: req.dbUserId,
      verifiedAt: parsed.data.status === "approved" ? new Date() : null,
      rejectionReason: parsed.data.rejectionReason ?? null,
    })
    .where(eq(documentsTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Document not found" });
    return;
  }

  // Notify the document owner of the verdict.
  const [owner] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, updated.userId));
  if (owner?.email && (updated.status === "approved" || updated.status === "rejected")) {
    await sendDocumentStatusEmail(owner.email, {
      documentType: updated.documentType,
      status: updated.status,
      reason: updated.rejectionReason ?? undefined,
    });
  }

  // Recalculate readiness on *every* verdict, not just approvals, a rejection
  // has to be able to move a seller's tier back down. The helper also resolves
  // the correct key space and keeps the seller_profiles badge in sync.
  await recalculateReadinessForUser(updated.userId);

  res.json(VerifyDocumentResponse.parse(updated));
});

export default router;
