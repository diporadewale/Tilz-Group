import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, usersTable, accountsTable } from "@workspace/db";
import { createSession, setSessionCookie } from "../lib/session";
import {
  isGoogleAuthConfigured,
  beginTransaction,
  readTransaction,
  clearTransaction,
  exchangeCode,
  type GoogleProfile,
} from "../lib/google-oauth";
import { logger } from "../lib/logger";
import { appUrl as appBase } from "../lib/app-url";

// Browser redirect endpoints, not JSON APIs, nothing in the generated client
// calls them, so like /documents/blob-upload they sit outside the OpenAPI
// contract by design.
const router: IRouter = Router();



/** Only same-origin paths; never reflect an attacker-supplied absolute URL. */
function safePath(value: string | undefined): string | undefined {
  if (!value) return undefined;
  return value.startsWith("/") && !value.startsWith("//") ? value : undefined;
}

function fail(res: import("express").Response, reason: string) {
  clearTransaction(res);
  res.redirect(`${appBase()}/sign-in?error=${encodeURIComponent(reason)}`);
}

router.get("/auth/google", (req, res) => {
  if (!isGoogleAuthConfigured()) {
    res.status(503).json({ error: "Google sign-in is not configured" });
    return;
  }

  const role = req.query.role === "seller" ? "seller" : req.query.role === "buyer" ? "buyer" : undefined;
  const url = beginTransaction(res, {
    role,
    redirect: safePath(typeof req.query.redirect === "string" ? req.query.redirect : undefined),
  });
  res.redirect(url);
});

router.get("/auth/google/callback", async (req, res): Promise<void> => {
  if (!isGoogleAuthConfigured()) {
    res.status(503).json({ error: "Google sign-in is not configured" });
    return;
  }

  // The user declined at Google's consent screen.
  if (typeof req.query.error === "string") {
    fail(res, "google_cancelled");
    return;
  }

  const tx = readTransaction(req);
  const code = typeof req.query.code === "string" ? req.query.code : "";
  const state = typeof req.query.state === "string" ? req.query.state : "";

  // CSRF: the state Google echoes back must match the one we minted.
  if (!tx || !code || !state || state !== tx.state) {
    fail(res, "google_state_mismatch");
    return;
  }

  let profile: GoogleProfile | null;
  try {
    profile = await exchangeCode(code, tx);
  } catch (err) {
    logger.error({ err }, "Google token exchange threw");
    profile = null;
  }
  if (!profile) {
    fail(res, "google_exchange_failed");
    return;
  }

  // Refuse an unverified Google address. Linking on an unverified email would
  // let someone claim an existing account by registering that address at a
  // domain they do not actually control.
  if (!profile.emailVerified) {
    fail(res, "google_email_unverified");
    return;
  }

  try {
    const userId = await resolveUser(profile, tx.role);
    const session = await createSession(userId);
    setSessionCookie(res, session.id, session.expiresAt);
    clearTransaction(res);
    res.redirect(`${appBase()}${tx.redirect ?? "/dashboard"}`);
  } catch (err) {
    logger.error({ err }, "Google sign-in failed to establish a session");
    fail(res, "google_signin_failed");
  }
});

/**
 * Find or create the local user behind a Google identity.
 *
 * Three cases:
 *   1. We've seen this Google account before  -> sign that user in.
 *   2. The verified email matches a local user -> link the two. Google has
 *      confirmed ownership of the address, so this is safe and is what a user
 *      expects when they registered with a password and later click Google.
 *   3. Neither                                 -> create the user and the link.
 */
async function resolveUser(
  profile: GoogleProfile,
  role: "buyer" | "seller" | undefined,
): Promise<number> {
  const [existingLink] = await db
    .select({ userId: accountsTable.userId })
    .from(accountsTable)
    .where(
      and(
        eq(accountsTable.provider, "google"),
        eq(accountsTable.providerAccountId, profile.sub),
      ),
    );
  if (existingLink) return existingLink.userId;

  const [byEmail] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, profile.email));

  if (byEmail) {
    await db.insert(accountsTable).values({
      userId: byEmail.id,
      provider: "google",
      providerAccountId: profile.sub,
    });
    // Google vouched for the address, so an unverified local account becomes
    // verified, this is also what unblocks leaving a review.
    if (!byEmail.emailVerified) {
      await db
        .update(usersTable)
        .set({ emailVerified: true })
        .where(eq(usersTable.id, byEmail.id));
    }
    return byEmail.id;
  }

  const [created] = await db
    .insert(usersTable)
    .values({
      email: profile.email,
      // No password: this is a Google-only account until they set one.
      passwordHash: null,
      emailVerified: true,
      firstName: profile.firstName,
      lastName: profile.lastName,
      avatarUrl: profile.avatarUrl,
      // Honour the role picked on the sign-up page; the column defaults to
      // buyer, and creating a seller profile later corrects it either way.
      ...(role ? { role } : {}),
    })
    .returning();

  await db.insert(accountsTable).values({
    userId: created.id,
    provider: "google",
    providerAccountId: profile.sub,
  });

  return created.id;
}

export default router;
