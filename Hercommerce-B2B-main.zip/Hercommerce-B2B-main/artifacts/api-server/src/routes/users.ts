import { Router, type IRouter } from "express";
import { eq, ilike, and, or, sql, SQL } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  ListUsersResponse,
  GetUserResponse,
  UpdateUserBody,
  UpdateUserParams,
  UpdateUserResponse,
} from "@workspace/api-zod";
import { requireAuth, requireAdmin, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { canManage, type Actor } from "../lib/access";

const router: IRouter = Router();

/** Adapts the request onto the pure predicates in lib/access.ts. */
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });


router.get("/users", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const { role, status, search } = req.query as {
    role?: string;
    status?: string;
    search?: string;
  };

  const conditions: SQL[] = [];
  if (role) conditions.push(eq(usersTable.role, role as "buyer" | "seller" | "admin"));
  if (status) {
    conditions.push(eq(usersTable.status, status as "pending" | "approved" | "rejected" | "suspended"));
  }
  // The field says "Search email or name" but only ever matched email, and did
  // so case-sensitively, searching an exact name returned nothing. Match both
  // names and email, case-insensitively.
  if (search) {
    const term = `%${search}%`;
    conditions.push(
      or(
        ilike(usersTable.email, term),
        ilike(usersTable.firstName, term),
        ilike(usersTable.lastName, term),
        // So "Kwame Asante" matches even though the halves are separate columns.
        sql`lower(coalesce(${usersTable.firstName}, '') || ' ' || coalesce(${usersTable.lastName}, '')) like lower(${term})`,
      )!,
    );
  }

  const users =
    conditions.length > 0
      ? await db
          .select()
          .from(usersTable)
          .where(and(...conditions))
          .orderBy(usersTable.createdAt)
      : await db.select().from(usersTable).orderBy(usersTable.createdAt);

  res.json(ListUsersResponse.parse(users));
});

router.get("/users/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateUserParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  // Self or admin only. Without this, any signed-in account could walk the id
  // space and harvest every user's email and name.
  if (!canManage(actorOf(req), params.data.id)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, params.data.id));

  if (!user) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(GetUserResponse.parse(user));
});

router.patch("/users/:id", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const params = UpdateUserParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const parsed = UpdateUserBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Only the two fields the contract allows, named explicitly rather than
  // spreading a cast-to-any object into the update.
  const changes: { role?: "buyer" | "seller" | "admin"; status?: "pending" | "approved" | "rejected" | "suspended" } = {};
  if (parsed.data.role) changes.role = parsed.data.role;
  if (parsed.data.status) changes.status = parsed.data.status;

  if (Object.keys(changes).length === 0) {
    res.status(400).json({ error: "Nothing to update" });
    return;
  }

  // An admin must not be able to strip their own admin role, or suspend
  // themselves, and lock the platform out of its only administrator.
  if (req.dbUserId === params.data.id) {
    if (changes.role && changes.role !== "admin") {
      res.status(400).json({ error: "You cannot change your own role" });
      return;
    }
    if (changes.status && changes.status !== "approved") {
      res.status(400).json({ error: "You cannot suspend or reject your own account" });
      return;
    }
  }

  const [updated] = await db
    .update(usersTable)
    .set(changes)
    .where(eq(usersTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "User not found" });
    return;
  }

  res.json(UpdateUserResponse.parse(updated));
});

export default router;
