import { Router, type IRouter } from "express";
import { eq, and, count, gte, inArray, sql, type SQL } from "drizzle-orm";
import { db, usersTable, sellerProfilesTable, buyerProfilesTable, documentsTable, enquiriesTable, readinessTiersTable } from "@workspace/db";
import {
  GetAdminStatsResponse,
  ListPendingReviewsResponse,
  ListUsersResponse,
  ListSellerProfilesResponse,
} from "@workspace/api-zod";
import { requireAdmin, type AuthRequest } from "../middlewares/requireAuth";
import { toCsv, sendCsv } from "../lib/csv";

const router: IRouter = Router();

router.get("/admin/stats", requireAdmin as never, async (_req, res): Promise<void> => {
  const [totalUsersRow] = await db.select({ count: count() }).from(usersTable);
  const [totalSellersRow] = await db
    .select({ count: count() })
    .from(usersTable)
    .where(eq(usersTable.role, "seller"));
  const [totalBuyersRow] = await db
    .select({ count: count() })
    .from(usersTable)
    .where(eq(usersTable.role, "buyer"));
  const [pendingDocsRow] = await db
    .select({ count: count() })
    .from(documentsTable)
    .where(eq(documentsTable.status, "pending"));
  const [pendingSellersRow] = await db
    .select({ count: count() })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.status, "pending"));
  const [pendingBuyersRow] = await db
    .select({ count: count() })
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.status, "pending"));
  const [approvedSellersRow] = await db
    .select({ count: count() })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.status, "approved"));
  const [totalEnquiriesRow] = await db.select({ count: count() }).from(enquiriesTable);

  // Signups in the last 7 days. This previously counted the rows returned by a
  // `limit(10)` query ordered oldest-first, so it always reported
  // min(totalUsers, 10) and had nothing to do with recency.
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const [recentSignupsRow] = await db
    .select({ count: count() })
    .from(usersTable)
    .where(gte(usersTable.createdAt, sevenDaysAgo));
  const recentSignups = Number(recentSignupsRow.count);

  // Count tiers from seller_profiles.readinessTier, the same column the public
  // directory filters on. Counting readiness_tiers rows instead made the admin
  // dashboard disagree with the directory (e.g. Bronze 3 vs 1, Gold 2 vs 3),
  // because that table can hold rows for sellers the directory never shows and
  // holds none for sellers who have never been rated.
  const tierRows = await db
    .select({ tier: sellerProfilesTable.readinessTier, count: count() })
    .from(sellerProfilesTable)
    .groupBy(sellerProfilesTable.readinessTier);

  const tierCount = (tier: string | null) =>
    Number(tierRows.find((r) => r.tier === tier)?.count ?? 0);

  const stats = {
    totalUsers: Number(totalUsersRow.count),
    totalSellers: Number(totalSellersRow.count),
    totalBuyers: Number(totalBuyersRow.count),
    pendingDocuments: Number(pendingDocsRow.count),
    pendingProfiles: Number(pendingSellersRow.count) + Number(pendingBuyersRow.count),
    approvedSellers: Number(approvedSellersRow.count),
    totalEnquiries: Number(totalEnquiriesRow.count),
    recentSignups,
    tierBreakdown: {
      bronze: tierCount("bronze"),
      silver: tierCount("silver"),
      gold: tierCount("gold"),
      platinum: tierCount("platinum"),
      // Surfaced as its own bucket, previously an unrated exporter was simply
      // absent from the breakdown, so the totals never reconciled.
      unrated: tierCount(null),
    },
  };

  res.json(GetAdminStatsResponse.parse(stats));
});

router.get("/admin/pending-reviews", requireAdmin as never, async (_req, res): Promise<void> => {
  const rawDocuments = await db
    .select()
    .from(documentsTable)
    .where(eq(documentsTable.status, "pending"))
    .orderBy(documentsTable.createdAt);

  const rawSellers = await db
    .select()
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.status, "pending"))
    .orderBy(sellerProfilesTable.createdAt);

  const rawBuyers = await db
    .select()
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.status, "pending"))
    .orderBy(buyerProfilesTable.createdAt);

  // One query for every referenced user instead of one per pending profile.
  const userIds = [...new Set([
    ...rawSellers.map((s) => s.userId),
    ...rawBuyers.map((b) => b.userId),
    ...rawDocuments.map((d) => d.userId),
  ])];
  const users = userIds.length
    ? await db.select().from(usersTable).where(inArray(usersTable.id, userIds))
    : [];
  const userMap = new Map(users.map((u) => [u.id, u]));

  // The queue rendered "Seller ID: 11" with nothing else, so the reviewer had
  // to cross-reference the company by hand before they could judge a document.
  const docOwnerCompanies = await db
    .select({ userId: sellerProfilesTable.userId, companyName: sellerProfilesTable.companyName })
    .from(sellerProfilesTable)
    .where(
      rawDocuments.length
        ? inArray(sellerProfilesTable.userId, [...new Set(rawDocuments.map((d) => d.userId))])
        : sql`false`,
    );
  const companyByUser = new Map(docOwnerCompanies.map((c) => [c.userId, c.companyName]));

  const documents = rawDocuments.map((d) => {
    const owner = userMap.get(d.userId);
    return {
      ...d,
      ownerCompany: companyByUser.get(d.userId) ?? null,
      ownerName: owner ? [owner.firstName, owner.lastName].filter(Boolean).join(" ") || null : null,
      ownerEmail: owner?.email ?? null,
    };
  });

  const sellerProfiles = rawSellers.map((s) => ({ ...s, user: userMap.get(s.userId) ?? null }));
  const buyerProfiles = rawBuyers.map((b) => ({ ...b, user: userMap.get(b.userId) ?? null }));

  res.json(
    ListPendingReviewsResponse.parse({ documents, sellerProfiles, buyerProfiles }),
  );
});

router.get("/admin/exports/users", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const { role, status } = req.query as Record<string, string>;

  const conditions: SQL[] = [];
  if (role) conditions.push(eq(usersTable.role, role as "buyer" | "seller" | "admin"));
  if (status) {
    conditions.push(eq(usersTable.status, status as "pending" | "approved" | "rejected" | "suspended"));
  }

  const users = await db
    .select()
    .from(usersTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(usersTable.createdAt);

  const csv = toCsv(
    ["id", "email", "firstName", "lastName", "role", "status", "createdAt"],
    users.map((u) => [
      u.id,
      u.email,
      u.firstName ?? "",
      u.lastName ?? "",
      u.role,
      u.status,
      u.createdAt.toISOString(),
    ]),
  );

  sendCsv(res, "users.csv", csv);
});

router.get("/admin/exports/sellers", requireAdmin as never, async (_req, res): Promise<void> => {
  const sellers = await db
    .select()
    .from(sellerProfilesTable)
    .orderBy(sellerProfilesTable.createdAt);

  const csv = toCsv(
    [
      "id", "companyName", "country", "city", "categories", "status",
      "readinessTier", "annualRevenue", "employeeCount", "createdAt",
    ],
    sellers.map((s) => [
      s.id,
      s.companyName,
      s.country,
      s.city ?? "",
      s.categories.join("|"),
      s.status,
      s.readinessTier ?? "",
      s.annualRevenue ?? "",
      s.employeeCount ?? "",
      s.createdAt.toISOString(),
    ]),
  );

  sendCsv(res, "sellers.csv", csv);
});

export default router;
