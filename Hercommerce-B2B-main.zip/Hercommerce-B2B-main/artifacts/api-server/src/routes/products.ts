import { Router, type IRouter } from "express";
import { eq, and, ilike, type SQL } from "drizzle-orm";
import { db, productsTable, sellerProfilesTable } from "@workspace/db";
import {
  ListProductsResponse,
  GetProductResponse,
  GetProductParams,
  CreateProductBody,
  UpdateProductBody,
  UpdateProductParams,
  DeleteProductParams,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { vocabError } from "../lib/vocab-check";
import { pageFrom } from "../lib/paging";
import { firstNumericError, isInvertedRange } from "../lib/numeric";

const router: IRouter = Router();

// True if the authed user owns the product (via their seller profile).
async function ownsProduct(userId: number, productId: number): Promise<boolean> {
  const [row] = await db
    .select({ ownerId: sellerProfilesTable.userId })
    .from(productsTable)
    .innerJoin(sellerProfilesTable, eq(productsTable.sellerId, sellerProfilesTable.id))
    .where(eq(productsTable.id, productId));
  return !!row && row.ownerId === userId;
}

router.get("/products", async (req, res): Promise<void> => {
  const { sellerId, category, search } = req.query as Record<string, string>;
  const { limit, offset } = pageFrom(req.query);

  const conditions: SQL[] = [];
  if (sellerId) conditions.push(eq(productsTable.sellerId, Number(sellerId)));
  if (category) conditions.push(eq(productsTable.category, category));
  if (search) conditions.push(ilike(productsTable.name, `%${search}%`));

  const rows = await db
    .select()
    .from(productsTable)
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(productsTable.createdAt)
    .limit(limit)
    .offset(offset);

  res.json(ListProductsResponse.parse(rows));
});

router.post(
  "/products",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const parsed = CreateProductBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }
    // The catalogue filters on category by exact string; an unlisted one
    // would make the product unreachable from every category filter.
    const vocab = vocabError(parsed.data);
    if (vocab) {
      res.status(400).json({ error: vocab });
      return;
    }


    const numericError = firstNumericError({
      "Price from": parsed.data.priceMin,
      "Price to": parsed.data.priceMax,
    });
    if (numericError) {
      res.status(400).json({ error: numericError });
      return;
    }
    if (isInvertedRange(parsed.data.priceMin, parsed.data.priceMax)) {
      res.status(400).json({ error: "Price from must not be greater than Price to." });
      return;
    }

    const [profile] = await db
      .select()
      .from(sellerProfilesTable)
      .where(eq(sellerProfilesTable.userId, req.dbUserId!));

    if (!profile) {
      res.status(403).json({ error: "Only exporters with a profile can add products" });
      return;
    }

    const [created] = await db
      .insert(productsTable)
      .values({
        sellerId: profile.id,
        name: parsed.data.name,
        description: parsed.data.description ?? null,
        category: parsed.data.category ?? null,
        imageUrl: parsed.data.imageUrl ?? null,
        priceMin: parsed.data.priceMin ?? null,
        priceMax: parsed.data.priceMax ?? null,
        currency: parsed.data.currency ?? "USD",
        unit: parsed.data.unit ?? null,
        moq: parsed.data.moq ?? null,
      })
      .returning();

    res.status(201).json(GetProductResponse.parse(created));
  },
);

router.get("/products/:id", async (req, res): Promise<void> => {
  const params = GetProductParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, params.data.id));

  if (!product) {
    res.status(404).json({ error: "Product not found" });
    return;
  }

  res.json(GetProductResponse.parse(product));
});

router.patch(
  "/products/:id",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const params = UpdateProductParams.safeParse({ id: req.params.id });
    if (!params.success) {
      res.status(400).json({ error: validationMessage(params.error) });
      return;
    }
    const parsed = UpdateProductBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }
    // The catalogue filters on category by exact string; an unlisted one
    // would make the product unreachable from every category filter.
    const vocab = vocabError(parsed.data);
    if (vocab) {
      res.status(400).json({ error: vocab });
      return;
    }

    const numericError = firstNumericError({
      "Price from": parsed.data.priceMin,
      "Price to": parsed.data.priceMax,
    });
    if (numericError) {
      res.status(400).json({ error: numericError });
      return;
    }
    if (isInvertedRange(parsed.data.priceMin, parsed.data.priceMax)) {
      res.status(400).json({ error: "Price from must not be greater than Price to." });
      return;
    }

    if (!(await ownsProduct(req.dbUserId!, params.data.id))) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const [updated] = await db
      .update(productsTable)
      .set(parsed.data)
      .where(eq(productsTable.id, params.data.id))
      .returning();

    if (!updated) {
      res.status(404).json({ error: "Product not found" });
      return;
    }

    res.json(GetProductResponse.parse(updated));
  },
);

router.delete(
  "/products/:id",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const params = DeleteProductParams.safeParse({ id: req.params.id });
    if (!params.success) {
      res.status(400).json({ error: validationMessage(params.error) });
      return;
    }
    if (!(await ownsProduct(req.dbUserId!, params.data.id))) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    await db.delete(productsTable).where(eq(productsTable.id, params.data.id));
    res.status(204).end();
  },
);

export default router;
