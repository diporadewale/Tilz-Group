import { Router, type IRouter } from "express";
import {
  ExtractOnboardingIntentBody,
  ExtractOnboardingIntentResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import {
  extractIntent,
  isIntentAssistConfigured,
  EMPTY_INTENT,
  MAX_TEXT_LENGTH,
} from "../lib/intent";

const router: IRouter = Router();

router.post(
  "/onboarding/extract-intent",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    if (!isIntentAssistConfigured()) {
      res.status(503).json({ error: "Intent assist is not configured" });
      return;
    }

    const parsed = ExtractOnboardingIntentBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: validationMessage(parsed.error) });
      return;
    }

    // The contract caps length, but this endpoint spends money per call so the
    // bound is re-asserted here rather than trusted to the generated schema.
    const text = parsed.data.text.trim();
    if (text.length > MAX_TEXT_LENGTH) {
      res.status(400).json({ error: "Description is too long" });
      return;
    }

    const intent = await extractIntent(parsed.data.role, text);

    // A null result means the upstream call failed. Onboarding must not break
    // because of it, return empty suggestions and let the client say so.
    res.json(ExtractOnboardingIntentResponse.parse(intent ?? EMPTY_INTENT));
  },
);

export default router;
