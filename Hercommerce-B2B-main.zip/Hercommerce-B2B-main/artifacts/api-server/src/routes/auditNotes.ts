import { Router, type IRouter } from "express";
import { eq, and, inArray } from "drizzle-orm";
import { db, auditNotesTable, usersTable } from "@workspace/db";
import {
  ListAuditNotesResponse,
  // The generated per-item schema *is* the contract's AuditNote shape; Orval
  // does not emit a separate CreateAuditNoteResponse for the 201.
  ListAuditNotesResponseItem as AuditNoteSchema,
  ListAuditNotesQueryParams,
  CreateAuditNoteBody,
} from "@workspace/api-zod";
import { requireAdmin, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";

const router: IRouter = Router();

router.get("/audit-notes", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  // Validate the query against the contract instead of casting it through `any`
  //, this also rejects a bogus entityType before it reaches the DB.
  const query = ListAuditNotesQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: validationMessage(query.error) });
    return;
  }

  const notes = await db
    .select()
    .from(auditNotesTable)
    .where(
      and(
        eq(auditNotesTable.entityType, query.data.entityType),
        eq(auditNotesTable.entityId, query.data.entityId),
      ),
    )
    .orderBy(auditNotesTable.createdAt);

  // Batched: one query for every referenced admin instead of one per note.
  const adminIds = [...new Set(notes.map((n) => n.adminId))];
  const admins = adminIds.length
    ? await db.select().from(usersTable).where(inArray(usersTable.id, adminIds))
    : [];
  const adminMap = new Map(admins.map((a) => [a.id, a]));

  const enriched = notes.map((note) => ({
    ...note,
    admin: adminMap.get(note.adminId) ?? undefined,
  }));

  res.json(ListAuditNotesResponse.parse(enriched));
});

router.post("/audit-notes", requireAdmin as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateAuditNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  if (!req.dbUserId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [note] = await db
    .insert(auditNotesTable)
    .values({
      adminId: req.dbUserId,
      entityType: parsed.data.entityType,
      entityId: parsed.data.entityId,
      note: parsed.data.note,
      action: parsed.data.action ?? null,
    })
    .returning();

  const [admin] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.id, note.adminId));

  // Parse before responding, spreading the raw user row here previously sent
  // the admin's passwordHash to the client. `admin` is optional (not nullable)
  // in the contract, so absent must be undefined rather than null.
  res.status(201).json(AuditNoteSchema.parse({ ...note, admin: admin ?? undefined }));
});

export default router;
