import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  GetMeResponse,
  RegisterBody,
  LoginBody,
  ForgotPasswordBody,
  ResetPasswordBody,
  VerifyEmailBody,
} from "@workspace/api-zod";
import { hashPassword, verifyPassword, verifyPasswordDummy } from "../lib/password";
import {
  createSession,
  invalidateSession,
  invalidateUserSessions,
  setSessionCookie,
  clearSessionCookie,
  SESSION_COOKIE_NAME,
} from "../lib/session";
import { createToken, consumeToken } from "../lib/verification";
import {
  sendVerificationEmail,
  sendPasswordResetEmail,
} from "../lib/email";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import {
  checkRateLimit,
  recordAttempt,
  clearAttempts,
  clientIp,
  type RateLimitAction,
} from "../lib/rate-limit";

const router: IRouter = Router();

/**
 * Replies 429 and returns false when the caller is over the limit.
 *
 * The message is identical whatever the identifier, and attempts are recorded
 * for unknown emails too. If only real accounts were counted, an attacker could
 * enumerate users by watching which addresses eventually start returning 429,
 * which would hand back exactly what the constant-time login above protects.
 */
async function withinRateLimit(
  action: RateLimitAction,
  identifier: string,
  req: { ip?: string; headers: Record<string, unknown> },
  res: { setHeader: (k: string, v: string) => void; status: (n: number) => { json: (b: unknown) => void } },
): Promise<boolean> {
  const { allowed, retryAfterSeconds } = await checkRateLimit(action, identifier, clientIp(req));
  if (allowed) return true;
  res.setHeader("Retry-After", String(retryAfterSeconds));
  res.status(429).json({
    error: "Too many attempts. Please wait a few minutes and try again.",
  });
  return false;
}

router.get(
  "/auth/me",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.dbUserId!));

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    res.json(GetMeResponse.parse(user));
  },
);

router.post("/auth/register", async (req, res): Promise<void> => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const { password, firstName, lastName, role } = parsed.data;
  const email = parsed.data.email.toLowerCase().trim();

  if (!(await withinRateLimit("register", email, req, res))) return;
  await recordAttempt("register", email, clientIp(req));

  const existing = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email));

  if (existing.length > 0) {
    res.status(409).json({ error: "Email already registered" });
    return;
  }

  const passwordHash = await hashPassword(password);

  const [created] = await db
    .insert(usersTable)
    .values({
      email,
      passwordHash,
      firstName: firstName ?? null,
      lastName: lastName ?? null,
      role: role ?? "buyer",
      status: "pending",
    })
    .returning();

  const session = await createSession(created.id);
  setSessionCookie(res, session.id, session.expiresAt);

  const verifyToken = await createToken(created.id, "email_verify");
  await sendVerificationEmail(created.email, verifyToken);

  res.status(201).json(GetMeResponse.parse(created));
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const email = parsed.data.email.toLowerCase().trim();

  if (!(await withinRateLimit("login", email, req, res))) return;

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email));

  // Same response whether the user is missing or the password is wrong. The
  // comparison runs even when there is no such user, returning early on a
  // missing account would make "no such email" measurably faster than "wrong
  // password" and turn this endpoint into a user-enumeration oracle.
  const ok = user?.passwordHash
    ? await verifyPassword(parsed.data.password, user.passwordHash)
    : await verifyPasswordDummy(parsed.data.password);

  if (!user || !ok) {
    // Only failures count, so someone who signs in correctly every day is never
    // throttled, and a burst of wrong guesses is.
    await recordAttempt("login", email, clientIp(req));
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  // A correct password clears the history: a user who mistypes four times and
  // then succeeds starts from zero rather than carrying those four for 15 min.
  await clearAttempts("login", email);

  const session = await createSession(user.id);
  setSessionCookie(res, session.id, session.expiresAt);

  res.json(GetMeResponse.parse(user));
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const token = req.cookies?.[SESSION_COOKIE_NAME];
  if (token) {
    await invalidateSession(token);
  }
  clearSessionCookie(res);
  res.status(204).end();
});

router.post("/auth/forgot-password", async (req, res): Promise<void> => {
  const parsed = ForgotPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const email = parsed.data.email.toLowerCase().trim();

  // The tightest limit on the API: every call that finds a user sends mail, so
  // this is both an account-takeover funnel and a way to flood a stranger's
  // inbox at our expense. Recorded whether or not the address exists.
  if (!(await withinRateLimit("forgot-password", email, req, res))) return;
  await recordAttempt("forgot-password", email, clientIp(req));

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email));

  if (user) {
    const token = await createToken(user.id, "password_reset");
    await sendPasswordResetEmail(user.email, token);
  }

  // Always 204, never reveal whether the email is registered.
  res.status(204).end();
});

router.post("/auth/reset-password", async (req, res): Promise<void> => {
  const parsed = ResetPasswordBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Keyed on IP alone: the caller presents a token, not an email, so there is
  // no account identifier to key on until the token has already been consumed.
  // This is what stops a reset token being brute-forced.
  if (!(await withinRateLimit("reset-password", "", req, res))) return;

  const userId = await consumeToken(parsed.data.token, "password_reset");
  if (!userId) {
    await recordAttempt("reset-password", "", clientIp(req));
    res.status(400).json({ error: "Invalid or expired token" });
    return;
  }

  const passwordHash = await hashPassword(parsed.data.password);
  await db
    .update(usersTable)
    .set({ passwordHash })
    .where(eq(usersTable.id, userId));

  // Resetting a password kills every existing session for that user.
  await invalidateUserSessions(userId);

  res.status(204).end();
});

router.post("/auth/verify-email", async (req, res): Promise<void> => {
  const parsed = VerifyEmailBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const userId = await consumeToken(parsed.data.token, "email_verify");
  if (!userId) {
    res.status(400).json({ error: "Invalid or expired token" });
    return;
  }

  await db
    .update(usersTable)
    .set({ emailVerified: true })
    .where(eq(usersTable.id, userId));

  res.status(204).end();
});

router.post(
  "/auth/resend-verification",
  requireAuth as never,
  async (req: AuthRequest, res): Promise<void> => {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, req.dbUserId!));

    if (!user) {
      res.status(404).json({ error: "User not found" });
      return;
    }

    if (!user.emailVerified) {
      const token = await createToken(user.id, "email_verify");
      await sendVerificationEmail(user.email, token);
    }

    res.status(204).end();
  },
);

export default router;
