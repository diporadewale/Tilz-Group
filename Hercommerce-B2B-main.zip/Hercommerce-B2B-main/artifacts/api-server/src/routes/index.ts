import { Router, type IRouter } from "express";
import healthRouter from "./health";
import onboardingRouter from "./onboarding";
import authRouter from "./auth";
import oauthRouter from "./oauth";
import usersRouter from "./users";
import sellerProfilesRouter from "./sellerProfiles";
import productsRouter from "./products";
import reviewsRouter from "./reviews";
import buyerProfilesRouter from "./buyerProfiles";
import documentsRouter from "./documents";
import readinessRouter from "./readiness";
import enquiriesRouter from "./enquiries";
import rfqsRouter from "./rfqs";
import notificationsRouter from "./notifications";
import auditNotesRouter from "./auditNotes";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(onboardingRouter);
router.use(authRouter);
router.use(oauthRouter);
router.use(usersRouter);
router.use(sellerProfilesRouter);
router.use(productsRouter);
router.use(reviewsRouter);
router.use(buyerProfilesRouter);
router.use(documentsRouter);
router.use(readinessRouter);
router.use(enquiriesRouter);
router.use(rfqsRouter);
router.use(notificationsRouter);
router.use(auditNotesRouter);
router.use(adminRouter);

export default router;
