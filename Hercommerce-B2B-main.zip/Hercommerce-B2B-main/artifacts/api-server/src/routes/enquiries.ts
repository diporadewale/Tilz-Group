import { Router, type IRouter } from "express";
import { eq, asc, and, or, inArray, sql, type SQL } from "drizzle-orm";
import {
  db,
  enquiriesTable,
  enquiryMessagesTable,
  buyerProfilesTable,
  sellerProfilesTable,
  usersTable,
} from "@workspace/db";
import {
  ListEnquiriesResponse,
  GetEnquiryResponse,
  CreateEnquiryBody,
  CreateEnquiryMessageBody,
  CreateEnquiryMessageParams,
  ReplyToEnquiryBody,
  ReplyToEnquiryParams,
  ReplyToEnquiryResponse,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";
import { canReadConversation, canPostToConversation, type Actor } from "../lib/access";
import {
  sendEnquiryReceivedEmail,
  sendEnquiryRepliedEmail,
} from "../lib/email";
import { notify } from "../lib/notifications";

const router: IRouter = Router();

type EnquiryRow = typeof enquiriesTable.$inferSelect;
type MessageRow = typeof enquiryMessagesTable.$inferSelect;

// Batched enrichment: 3 queries total regardless of how many enquiries are
// passed in (previously 4 queries *per* enquiry).
async function enrichEnquiries(enquiries: EnquiryRow[]) {
  if (enquiries.length === 0) return [];

  const buyerIds = [...new Set(enquiries.map((e) => e.buyerId))];
  const sellerIds = [...new Set(enquiries.map((e) => e.sellerId))];

  const buyers = await db
    .select()
    .from(buyerProfilesTable)
    .where(inArray(buyerProfilesTable.id, buyerIds));
  const sellers = await db
    .select()
    .from(sellerProfilesTable)
    .where(inArray(sellerProfilesTable.id, sellerIds));

  const userIds = [...new Set([...buyers.map((b) => b.userId), ...sellers.map((s) => s.userId)])];
  const users = userIds.length
    ? await db.select().from(usersTable).where(inArray(usersTable.id, userIds))
    : [];
  const userMap = new Map(users.map((u) => [u.id, u]));

  const buyerMap = new Map(buyers.map((b) => [b.id, { ...b, user: userMap.get(b.userId) ?? null }]));
  const sellerMap = new Map(sellers.map((s) => [s.id, { ...s, user: userMap.get(s.userId) ?? null }]));

  return enquiries.map((e) => ({
    ...e,
    buyer: buyerMap.get(e.buyerId) ?? null,
    seller: sellerMap.get(e.sellerId) ?? null,
  }));
}

async function enrichEnquiry(enquiry: EnquiryRow) {
  const [only] = await enrichEnquiries([enquiry]);
  return only;
}

type Enriched = Awaited<ReturnType<typeof enrichEnquiry>>;

function labelMessage(m: MessageRow, e: Enriched) {
  const buyerUserId = e.buyer?.user?.id;
  const sellerUserId = e.seller?.user?.id;
  const role = m.senderId === buyerUserId ? "buyer" : m.senderId === sellerUserId ? "seller" : null;
  const name = role === "buyer" ? e.buyer?.companyName ?? null : role === "seller" ? e.seller?.companyName ?? null : null;
  return { ...m, senderRole: role, senderName: name };
}

// Reading and writing need different tests. An admin may need to read a thread
// to resolve a dispute, but must never be able to post into two other
// companies' negotiation as if they were a party to it: the composer made an
// admin indistinguishable from the buyer or the seller in the transcript.
const actorOf = (req: AuthRequest): Actor => ({ userId: req.dbUserId, role: req.dbUserRole as Actor["role"] });

function isParticipant(req: AuthRequest, e: Enriched): boolean {
  return canPostToConversation(actorOf(req), e.buyer?.user?.id, e.seller?.user?.id);
}

/** Read access: the two parties, plus an admin acting as moderator. */
function canRead(req: AuthRequest, e: Enriched): boolean {
  return canReadConversation(actorOf(req), e.buyer?.user?.id, e.seller?.user?.id);
}

router.get("/enquiries", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const { status } = req.query as Record<string, string>;

  // Scope in SQL rather than loading every enquiry in the system and filtering
  // in memory. Newest-first so an inbox reads like an inbox.
  const filters: SQL[] = [];
  if (status) filters.push(eq(enquiriesTable.status, status as "open" | "replied" | "closed"));

  if (req.dbUserRole !== "admin") {
    const [buyerProfiles, sellerProfiles] = await Promise.all([
      db.select({ id: buyerProfilesTable.id }).from(buyerProfilesTable).where(eq(buyerProfilesTable.userId, req.dbUserId!)),
      db.select({ id: sellerProfilesTable.id }).from(sellerProfilesTable).where(eq(sellerProfilesTable.userId, req.dbUserId!)),
    ]);
    const buyerIds = buyerProfiles.map((b) => b.id);
    const sellerIds = sellerProfiles.map((s) => s.id);

    // No profile on either side means no enquiries can belong to this user.
    if (buyerIds.length === 0 && sellerIds.length === 0) {
      res.json(ListEnquiriesResponse.parse([]));
      return;
    }

    const ownership: SQL[] = [];
    if (buyerIds.length) ownership.push(inArray(enquiriesTable.buyerId, buyerIds));
    if (sellerIds.length) ownership.push(inArray(enquiriesTable.sellerId, sellerIds));
    filters.push(ownership.length > 1 ? or(...ownership)! : ownership[0]);
  }

  const enquiries = await db
    .select()
    .from(enquiriesTable)
    .where(filters.length ? and(...filters) : undefined)
    // lastMessageAt is nullable on pre-threading rows, and Postgres sorts NULLs
    // first on DESC, coalesce so legacy enquiries don't pin themselves to the top.
    .orderBy(sql`coalesce(${enquiriesTable.lastMessageAt}, ${enquiriesTable.createdAt}) desc`)
    .limit(200);

  res.json(ListEnquiriesResponse.parse(await enrichEnquiries(enquiries)));
});

router.post("/enquiries", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateEnquiryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }
  if (!req.dbUserId) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }

  const [buyerProfile] = await db.select().from(buyerProfilesTable).where(eq(buyerProfilesTable.userId, req.dbUserId));
  if (!buyerProfile) {
    res.status(400).json({ error: "Buyer profile required" });
    return;
  }

  const now = new Date();
  const [enquiry] = await db
    .insert(enquiriesTable)
    .values({
      buyerId: buyerProfile.id,
      sellerId: parsed.data.sellerId,
      subject: parsed.data.subject,
      message: parsed.data.message,
      status: "open",
      lastMessageAt: now,
    })
    .returning();

  // First turn of the thread.
  await db.insert(enquiryMessagesTable).values({
    enquiryId: enquiry.id,
    senderId: req.dbUserId,
    body: parsed.data.message,
  });

  const enriched = await enrichEnquiry(enquiry);
  const sellerEmail = enriched.seller?.user?.email;
  if (sellerEmail) {
    await sendEnquiryReceivedEmail(sellerEmail, { subject: enquiry.subject });
  }
  if (enriched.seller?.user?.id) {
    await notify(enriched.seller.user.id, {
      type: "enquiry",
      title: `New enquiry: ${enquiry.subject}`,
      link: `/enquiries/${enquiry.id}`,
    });
  }

  res.status(201).json(GetEnquiryResponse.parse({ ...enriched, messages: [] }));
});

router.get("/enquiries/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = ReplyToEnquiryParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [enquiry] = await db.select().from(enquiriesTable).where(eq(enquiriesTable.id, params.data.id));
  if (!enquiry) {
    res.status(404).json({ error: "Enquiry not found" });
    return;
  }

  const enriched = await enrichEnquiry(enquiry);
  if (!canRead(req, enriched)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  let rows = await db
    .select()
    .from(enquiryMessagesTable)
    .where(eq(enquiryMessagesTable.enquiryId, enquiry.id))
    .orderBy(asc(enquiryMessagesTable.createdAt));

  // Legacy enquiries (created before threading) have no message rows, rebuild
  // the thread from the original message + reply so they still render.
  if (rows.length === 0) {
    const synth: MessageRow[] = [
      {
        id: -1,
        enquiryId: enquiry.id,
        senderId: enriched.buyer?.user?.id ?? 0,
        body: enquiry.message,
        createdAt: enquiry.createdAt,
      },
    ];
    if (enquiry.replyMessage) {
      synth.push({
        id: -2,
        enquiryId: enquiry.id,
        senderId: enriched.seller?.user?.id ?? 0,
        body: enquiry.replyMessage,
        createdAt: enquiry.repliedAt ?? enquiry.createdAt,
      });
    }
    rows = synth;
  }

  const messages = rows.map((m) => labelMessage(m, enriched));
  res.json(GetEnquiryResponse.parse({ ...enriched, messages }));
});

router.post("/enquiries/:id/messages", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = CreateEnquiryMessageParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }
  const parsed = CreateEnquiryMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  const [enquiry] = await db.select().from(enquiriesTable).where(eq(enquiriesTable.id, params.data.id));
  if (!enquiry) {
    res.status(404).json({ error: "Enquiry not found" });
    return;
  }
  const enriched = await enrichEnquiry(enquiry);
  if (!isParticipant(req, enriched)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const [created] = await db
    .insert(enquiryMessagesTable)
    .values({ enquiryId: enquiry.id, senderId: req.dbUserId!, body: parsed.data.body })
    .returning();

  const fromSeller = req.dbUserId === enriched.seller?.user?.id;
  await db
    .update(enquiriesTable)
    .set({ lastMessageAt: new Date(), status: fromSeller ? "replied" : "open" })
    .where(eq(enquiriesTable.id, enquiry.id));

  // Notify the other participant (email + in-app).
  const recipient = fromSeller ? enriched.buyer?.user?.email : enriched.seller?.user?.email;
  if (recipient) {
    if (fromSeller) await sendEnquiryRepliedEmail(recipient, { subject: enquiry.subject });
    else await sendEnquiryReceivedEmail(recipient, { subject: enquiry.subject });
  }
  const recipientId = fromSeller ? enriched.buyer?.user?.id : enriched.seller?.user?.id;
  if (recipientId) {
    await notify(recipientId, {
      type: "message",
      title: `New message: ${enquiry.subject}`,
      link: `/enquiries/${enquiry.id}`,
    });
  }

  res.status(201).json(labelMessage(created, enriched));
});

router.patch("/enquiries/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = ReplyToEnquiryParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }
  const parsed = ReplyToEnquiryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }

  // Load and authorise BEFORE writing, without this any authenticated user
  // could mutate any enquiry (and inject a reply) just by guessing its id.
  const [existing] = await db
    .select()
    .from(enquiriesTable)
    .where(eq(enquiriesTable.id, params.data.id));
  if (!existing) {
    res.status(404).json({ error: "Enquiry not found" });
    return;
  }
  const before = await enrichEnquiry(existing);
  if (!isParticipant(req, before)) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }

  const updateData: Record<string, unknown> = { ...parsed.data };
  if (parsed.data.status === "replied") updateData.repliedAt = new Date();

  const [updated] = await db
    .update(enquiriesTable)
    .set(updateData)
    .where(eq(enquiriesTable.id, params.data.id))
    .returning();
  if (!updated) {
    res.status(404).json({ error: "Enquiry not found" });
    return;
  }

  const enriched = await enrichEnquiry(updated);
  res.json(ReplyToEnquiryResponse.parse(enriched));
});

export default router;
