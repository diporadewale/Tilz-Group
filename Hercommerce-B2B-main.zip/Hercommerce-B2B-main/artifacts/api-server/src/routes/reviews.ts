import { Router, type IRouter } from "express";
import { eq, and, desc, inArray } from "drizzle-orm";
import {
  db,
  reviewsTable,
  buyerProfilesTable,
  sellerProfilesTable,
  enquiriesTable,
  usersTable,
} from "@workspace/db";
import { ListReviewsResponse, CreateReviewBody, DeleteReviewParams } from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { validationMessage } from "../lib/validation";

const router: IRouter = Router();

router.get("/reviews", async (req, res): Promise<void> => {
  const sellerId = Number(req.query.sellerId);
  if (!sellerId) {
    res.json(ListReviewsResponse.parse([]));
    return;
  }

  const rows = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.sellerId, sellerId))
    .orderBy(desc(reviewsTable.createdAt));

  const buyerIds = [...new Set(rows.map((r) => r.buyerId))];
  const buyerMap = new Map<number, string>();
  if (buyerIds.length) {
    const buyers = await db
      .select({ id: buyerProfilesTable.id, companyName: buyerProfilesTable.companyName })
      .from(buyerProfilesTable)
      .where(inArray(buyerProfilesTable.id, buyerIds));
    for (const b of buyers) buyerMap.set(b.id, b.companyName);
  }

  res.json(ListReviewsResponse.parse(rows.map((r) => ({ ...r, buyerCompany: buyerMap.get(r.buyerId) ?? null }))));
});

router.post("/reviews", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const parsed = CreateReviewBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: validationMessage(parsed.error) });
    return;
  }
  if (parsed.data.rating < 1 || parsed.data.rating > 5) {
    res.status(400).json({ error: "Rating must be between 1 and 5" });
    return;
  }

  const [buyer] = await db
    .select()
    .from(buyerProfilesTable)
    .where(eq(buyerProfilesTable.userId, req.dbUserId!));
  if (!buyer) {
    res.status(403).json({ error: "Only buyers can leave reviews" });
    return;
  }

  // Reviews are the platform's reputation layer, so they need a real
  // relationship behind them. Previously any signed-in account, unverified
  // email, pending profile, no contact with the exporter, could set a public
  // star rating to any value, repeatedly. That is the standard vector for
  // competitor sabotage and paid review manipulation.
  const [reviewer] = await db
    .select({ emailVerified: usersTable.emailVerified })
    .from(usersTable)
    .where(eq(usersTable.id, req.dbUserId!));
  if (!reviewer?.emailVerified) {
    res.status(403).json({
      error: "Verify your email address before leaving a review.",
    });
    return;
  }

  const [contact] = await db
    .select({ id: enquiriesTable.id })
    .from(enquiriesTable)
    .where(
      and(
        eq(enquiriesTable.buyerId, buyer.id),
        eq(enquiriesTable.sellerId, parsed.data.sellerId),
      ),
    )
    .limit(1);
  if (!contact) {
    res.status(403).json({
      error: "You can only review an exporter you have contacted through the platform.",
    });
    return;
  }

  const [seller] = await db
    .select({ id: sellerProfilesTable.id })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.id, parsed.data.sellerId));
  if (!seller) {
    res.status(404).json({ error: "Exporter not found" });
    return;
  }

  // One review per buyer per seller, update if it already exists.
  const [existing] = await db
    .select()
    .from(reviewsTable)
    .where(and(eq(reviewsTable.sellerId, parsed.data.sellerId), eq(reviewsTable.buyerId, buyer.id)));

  let row;
  if (existing) {
    [row] = await db
      .update(reviewsTable)
      .set({ rating: parsed.data.rating, comment: parsed.data.comment ?? null })
      .where(eq(reviewsTable.id, existing.id))
      .returning();
  } else {
    [row] = await db
      .insert(reviewsTable)
      .values({
        sellerId: parsed.data.sellerId,
        buyerId: buyer.id,
        rating: parsed.data.rating,
        comment: parsed.data.comment ?? null,
      })
      .returning();
  }

  // 200 on revision, 201 on first submission, the response used to claim
  // "created" even when silently overwriting a previous rating.
  res.status(existing ? 200 : 201).json({ ...row, buyerCompany: buyer.companyName });
});

// A review could be created and revised but never removed. That left a rating
// given in error permanent for its author, and gave an admin no way to take
// down an abusive or fraudulent one without direct database access.
//
// Deliberately not gated on a verified email: the create gate exists to stop
// someone planting a rating, and applying it here would trap the very reviews
// it was meant to prevent. Averages are computed on read, so nothing else
// needs recalculating.
router.delete("/reviews/:id", requireAuth as never, async (req: AuthRequest, res): Promise<void> => {
  const params = DeleteReviewParams.safeParse({ id: req.params.id });
  if (!params.success) {
    res.status(400).json({ error: validationMessage(params.error) });
    return;
  }

  const [review] = await db
    .select()
    .from(reviewsTable)
    .where(eq(reviewsTable.id, params.data.id));
  if (!review) {
    res.status(404).json({ error: "Review not found" });
    return;
  }

  if (req.dbUserRole !== "admin") {
    const [buyer] = await db
      .select({ id: buyerProfilesTable.id })
      .from(buyerProfilesTable)
      .where(eq(buyerProfilesTable.userId, req.dbUserId!));
    if (!buyer || buyer.id !== review.buyerId) {
      res.status(403).json({ error: "You can only delete your own review." });
      return;
    }
  }

  await db.delete(reviewsTable).where(eq(reviewsTable.id, params.data.id));
  res.status(204).end();
});

export default router;
