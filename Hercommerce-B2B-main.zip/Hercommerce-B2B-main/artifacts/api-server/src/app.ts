import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Behind Vercel the socket address is the proxy, so without this every request
// looks like it comes from one IP and any per-address limit would throttle the
// whole platform at once. Also makes req.secure honest about TLS terminated
// upstream.
app.set("trust proxy", true);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

// The SPA and the API are served from the same origin on Vercel, so no
// cross-origin browser traffic is expected in production. `origin: true`
// reflects whatever Origin the caller sends, which combined with
// `credentials: true` would allow any site to make credentialed requests, only
// the session cookie's SameSite=Lax setting was preventing that. Allow an
// explicit list instead, and fall back to same-origin-only.
const allowedOrigins = (process.env.CORS_ALLOWED_ORIGINS ?? "")
  .split(",")
  .map((o) => o.trim())
  .filter(Boolean);

app.use(
  cors({
    credentials: true,
    origin(origin, callback) {
      // No Origin header means a same-origin or non-browser request.
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) return callback(null, true);
      // Reject by not enabling CORS rather than erroring, so the browser
      // surfaces a normal CORS failure instead of a 500.
      return callback(null, false);
    },
  }),
);
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.use("/api", router);

// Unknown API paths get a JSON 404 rather than Express's default HTML, which the
// client's JSON parsing cannot handle.
app.use("/api", (_req, res) => {
  res.status(404).json({ error: "Not found" });
});

// Terminal error handler. Express 5 forwards rejected promises from async
// handlers here; without this the default handler replies with HTML (and leaks a
// stack trace outside production), which the SPA renders as a blank screen.
app.use(
  (
    err: unknown,
    req: express.Request,
    res: express.Response,
    _next: express.NextFunction,
  ) => {
    logger.error({ err, method: req.method, url: req.url }, "Unhandled request error");

    if (res.headersSent) return;

    res.status(500).json({ error: "Internal server error" });
  },
);

export default app;
