// Serverless entry for Vercel.
//
// Exports the configured Express app as a handler WITHOUT calling listen().
// esbuild (build.mjs) bundles this to `dist/vercel.mjs`, a self-contained ESM
// file with every dependency inlined, which the Vercel function in `api/`
// re-exports. This keeps @vercel/node away from the raw monorepo TypeScript
// (whose extensionless, bundler-resolution imports it refuses to compile).
import app from "./app";

export default app;
