import Anthropic from "@anthropic-ai/sdk";
import {
  CATEGORIES,
  COUNTRIES,
  CERTIFICATIONS,
  REVENUE_BANDS,
  EMPLOYEE_BANDS,
  BUDGET_BANDS,
  keepKnown,
} from "@workspace/vocab";
import { logger } from "./logger";

// ── Onboarding intent extraction ─────────────────────────────────────────────
//
// Turns a free-text business description into suggestions drawn from the shared
// controlled vocabularies. The output is *not* used to rank or recommend
// anything, it only pre-fills the chip pickers the user then reviews. Ranking
// stays with the deterministic matcher in routes/buyerProfiles.ts.
//
// The safety property that makes this acceptable in a trust-led product: every
// vocabulary field is a JSON-Schema `enum` built from the real lists, so the
// model cannot emit a category, country, or certification the app doesn't have.
// A hallucinated "USDA Organic" claim is structurally impossible here, not
// merely unlikely. `keepKnown` is a second belt for that same braces.

const MODEL = "claude-opus-5";

// Well inside Vercel's 10s Hobby function ceiling, so we return a graceful
// error rather than being killed by the platform mid-request.
const REQUEST_TIMEOUT_MS = 8_000;

export const MIN_TEXT_LENGTH = 12;
export const MAX_TEXT_LENGTH = 2000;

export type IntentRole = "buyer" | "seller";

export interface ExtractedIntent {
  categories: string[];
  origins: string[];
  certifications: string[];
  exportMarkets: string[];
  country: string | null;
  annualRevenue: string | null;
  employeeCount: string | null;
  annualBudget: string | null;
}

const EMPTY_INTENT: ExtractedIntent = {
  categories: [],
  origins: [],
  certifications: [],
  exportMarkets: [],
  country: null,
  annualRevenue: null,
  employeeCount: null,
  annualBudget: null,
};

export function isIntentAssistConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

let client: Anthropic | null = null;
function getClient(): Anthropic {
  if (!client) {
    client = new Anthropic({
      timeout: REQUEST_TIMEOUT_MS, // TypeScript SDK takes milliseconds
      maxRetries: 1, // one retry still fits the function budget; more does not
    });
  }
  return client;
}

/** A nullable enum field. `anyOf` with a null branch is supported by structured outputs. */
const nullableEnum = (values: readonly string[]) => ({
  anyOf: [{ type: "string", enum: [...values] }, { type: "null" }],
});

const enumArray = (values: readonly string[]) => ({
  type: "array",
  items: { type: "string", enum: [...values] },
});

/**
 * Role-specific schema containing *only* the fields that apply to the role.
 *
 * Fields belonging to the other role are omitted rather than given an empty
 * `enum: []`, a zero-member enum admits no valid value and risks being
 * rejected outright by the schema compiler. The caller fills the omitted
 * fields with their empty defaults.
 */
function schemaFor(role: IntentRole) {
  const properties: Record<string, unknown> =
    role === "seller"
      ? {
          categories: enumArray(CATEGORIES),
          certifications: enumArray(CERTIFICATIONS),
          exportMarkets: enumArray(COUNTRIES),
          country: nullableEnum(COUNTRIES),
          annualRevenue: nullableEnum(REVENUE_BANDS),
          employeeCount: nullableEnum(EMPLOYEE_BANDS),
        }
      : {
          categories: enumArray(CATEGORIES),
          origins: enumArray(COUNTRIES),
          country: nullableEnum(COUNTRIES),
          annualBudget: nullableEnum(BUDGET_BANDS),
        };

  return {
    type: "object",
    properties,
    // Structured outputs requires every property to be listed in `required`.
    required: Object.keys(properties),
    additionalProperties: false,
  };
}

function promptFor(role: IntentRole): string {
  return role === "seller"
    ? [
        "You map an exporter's own description of their business onto this platform's fixed vocabularies.",
        "",
        "- `categories`: the product categories they actually sell.",
        "- `certifications`: certifications they claim to hold. Only include one if the text names it or names it unambiguously by synonym. Never infer a certification from a product being called 'organic', organic produce is a category, not a certificate.",
        "- `exportMarkets`: countries or regions they say they sell *to*.",
        "- `country`: the country they operate *from*.",
        "- `annualRevenue` / `employeeCount`: only when the text gives a figure or range that maps to a band.",
        "",
        "Select only what the text supports. An empty list is the correct answer when nothing matches; do not pad.",
      ].join("\n")
    : [
        "You map a buyer's own description of their sourcing needs onto this platform's fixed vocabularies.",
        "",
        "- `categories`: the product categories they want to source.",
        "- `origins`: countries or regions they want to source *from*. A region maps to the listed countries it contains (for example 'West Africa' to Ghana and Nigeria).",
        "- `country`: the country the buyer's own company is based in, not where they source from.",
        "- `annualBudget`: only when the text gives a figure or range that maps to a band.",
        "",
        "Select only what the text supports. An empty list is the correct answer when nothing matches; do not pad.",
      ].join("\n");
}

/**
 * Extract vocabulary suggestions from free text.
 *
 * Throws only for genuinely exceptional conditions (missing key). Upstream
 * failures, timeout, rate limit, malformed output, resolve to `null` so the
 * caller can degrade to manual entry instead of blocking onboarding (FR-008).
 */
export async function extractIntent(
  role: IntentRole,
  text: string,
): Promise<ExtractedIntent | null> {
  if (!isIntentAssistConfigured()) {
    throw new Error("ANTHROPIC_API_KEY is not configured");
  }

  try {
    const response = await getClient().messages.create({
      model: MODEL,
      max_tokens: 4096, // thinking and response share this budget on Opus 5
      system: promptFor(role),
      // Adaptive thinking at low effort: enough reasoning for a mapping task,
      // fast enough for the function budget. Disabling thinking outright on
      // Opus 5 risks internal tags leaking into the output.
      thinking: { type: "adaptive" },
      output_config: {
        effort: "low",
        format: { type: "json_schema", schema: schemaFor(role) },
      },
      messages: [{ role: "user", content: text }],
    });

    if (response.stop_reason === "refusal") {
      logger.warn({ role }, "Intent extraction refused by safety classifier");
      return null;
    }

    const payload = response.content.find((block) => block.type === "text");
    if (!payload || payload.type !== "text") {
      logger.warn({ role, stopReason: response.stop_reason }, "Intent extraction returned no text block");
      return null;
    }

    const parsed = JSON.parse(payload.text) as Partial<Record<keyof ExtractedIntent, unknown>>;

    // The enum schema already guarantees these, but re-filtering keeps the
    // guarantee local to this file rather than assuming the API upheld it.
    const scalar = <T extends readonly string[]>(list: T, value: unknown): string | null =>
      typeof value === "string" && keepKnown(list, [value]).length === 1 ? value : null;
    const list = <T extends readonly string[]>(vocab: T, value: unknown): string[] =>
      Array.isArray(value) ? keepKnown(vocab, value.filter((v): v is string => typeof v === "string")) : [];

    return {
      categories: list(CATEGORIES, parsed.categories),
      origins: role === "buyer" ? list(COUNTRIES, parsed.origins) : [],
      certifications: role === "seller" ? list(CERTIFICATIONS, parsed.certifications) : [],
      exportMarkets: role === "seller" ? list(COUNTRIES, parsed.exportMarkets) : [],
      country: scalar(COUNTRIES, parsed.country),
      annualRevenue: role === "seller" ? scalar(REVENUE_BANDS, parsed.annualRevenue) : null,
      employeeCount: role === "seller" ? scalar(EMPLOYEE_BANDS, parsed.employeeCount) : null,
      annualBudget: role === "buyer" ? scalar(BUDGET_BANDS, parsed.annualBudget) : null,
    };
  } catch (err) {
    // Timeouts, rate limits, overloads, malformed JSON. Onboarding must stay
    // usable when this dependency is unavailable, so this is a soft failure.
    logger.error({ err, role }, "Intent extraction failed");
    return null;
  }
}

export { EMPTY_INTENT };
