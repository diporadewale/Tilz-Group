// Authorisation predicates, in one place and pure.
//
// These rules used to live as inline `if` statements in each handler, which is
// how the platform shipped a hole that survived two external audits: the fix
// for "any signed-in user can read any buyer profile" was applied to
// GET /buyer-profiles and the sibling GET /buyer-profiles/:id was missed. With
// the rule inline in each file there was nothing to grep for and nothing to
// test, so "did we apply this everywhere?" had no answer short of reading every
// route.
//
// Authentication is not authorisation: `requireAuth` proves who is calling,
// these decide what that caller may touch. Every one takes the actor and the
// resource's owner, and returns a boolean. No database access, no request
// object, no side effects, so the whole matrix is exhaustively testable.

export type Role = "buyer" | "seller" | "admin";

export interface Actor {
  /** Undefined when the request is unauthenticated. */
  userId: number | undefined;
  role: Role | undefined;
}

export function isAdmin(actor: Actor): boolean {
  return actor.role === "admin";
}

export function isSignedIn(actor: Actor): boolean {
  return typeof actor.userId === "number";
}

/**
 * True only for the row's owner. Admins are deliberately excluded: use
 * `canManage` where an admin should also pass, so that every call site states
 * which of the two it means rather than leaving it implied.
 */
export function isOwner(actor: Actor, ownerUserId: number | null | undefined): boolean {
  return (
    typeof actor.userId === "number" &&
    typeof ownerUserId === "number" &&
    actor.userId === ownerUserId
  );
}

/** The owner, or an admin. The default for private resources: profiles, documents. */
export function canManage(actor: Actor, ownerUserId: number | null | undefined): boolean {
  return isAdmin(actor) || isOwner(actor, ownerUserId);
}

/**
 * A two-party conversation. Read access extends to admins for moderation;
 * write access does not, because an admin posting into two other companies'
 * negotiation is indistinguishable from a party in the transcript.
 */
export function isParty(
  actor: Actor,
  buyerUserId: number | null | undefined,
  sellerUserId: number | null | undefined,
): boolean {
  return isOwner(actor, buyerUserId) || isOwner(actor, sellerUserId);
}

export function canReadConversation(
  actor: Actor,
  buyerUserId: number | null | undefined,
  sellerUserId: number | null | undefined,
): boolean {
  return isAdmin(actor) || isParty(actor, buyerUserId, sellerUserId);
}

export function canPostToConversation(
  actor: Actor,
  buyerUserId: number | null | undefined,
  sellerUserId: number | null | undefined,
): boolean {
  return isParty(actor, buyerUserId, sellerUserId);
}

/**
 * Verification verdicts: a seller must never be able to approve their own
 * profile or documents, which is what "verified" is supposed to mean. Admin
 * only, never the owner.
 */
export function canSetVerificationStatus(actor: Actor): boolean {
  return isAdmin(actor);
}

/**
 * An admin must not be able to strip their own admin role or suspend
 * themselves, which would leave the platform with no way back in.
 */
export function canChangeAccountStatus(actor: Actor, targetUserId: number): boolean {
  return isAdmin(actor) && actor.userId !== targetUserId;
}
