import { describe, it, expect } from "vitest";
import {
  type Actor,
  type Role,
  isAdmin,
  isSignedIn,
  isOwner,
  canManage,
  isParty,
  canReadConversation,
  canPostToConversation,
  canSetVerificationStatus,
  canChangeAccountStatus,
} from "./access";

const ROLES: Role[] = ["buyer", "seller", "admin"];
const OWNER = 1;
const OTHER = 2;
const ADMIN_ID = 3;

const as = (userId: number | undefined, role: Role | undefined): Actor => ({ userId, role });
const anonymous = as(undefined, undefined);

describe("isSignedIn / isAdmin", () => {
  it("treats a missing userId as signed out whatever the role claims", () => {
    expect(isSignedIn(anonymous)).toBe(false);
    expect(isSignedIn(as(undefined, "admin"))).toBe(false);
    expect(isSignedIn(as(OWNER, "buyer"))).toBe(true);
  });

  it("recognises only the admin role", () => {
    expect(isAdmin(as(ADMIN_ID, "admin"))).toBe(true);
    expect(isAdmin(as(OWNER, "buyer"))).toBe(false);
    expect(isAdmin(as(OWNER, "seller"))).toBe(false);
    expect(isAdmin(anonymous)).toBe(false);
  });
});

describe("isOwner", () => {
  it("matches only the same user id", () => {
    expect(isOwner(as(OWNER, "buyer"), OWNER)).toBe(true);
    expect(isOwner(as(OTHER, "buyer"), OWNER)).toBe(false);
  });

  it("is false for an admin who does not own the row", () => {
    // The distinction canManage exists to make explicit.
    expect(isOwner(as(ADMIN_ID, "admin"), OWNER)).toBe(false);
  });

  // A null owner column and an unauthenticated caller are both "unknown". If
  // undefined === undefined were allowed to pass, an orphaned row would become
  // readable by anyone.
  it.each([
    ["anonymous actor, real owner", anonymous, OWNER],
    ["real actor, null owner", as(OWNER, "buyer"), null],
    ["real actor, undefined owner", as(OWNER, "buyer"), undefined],
    ["anonymous actor, null owner", anonymous, null],
  ])("never matches when either side is unknown: %s", (_label, actor, owner) => {
    expect(isOwner(actor, owner as number | null | undefined)).toBe(false);
  });
});

describe("canManage: the rule behind the buyer-profile hole", () => {
  it("allows the owner and any admin, and nobody else", () => {
    expect(canManage(as(OWNER, "buyer"), OWNER)).toBe(true);
    expect(canManage(as(ADMIN_ID, "admin"), OWNER)).toBe(true);
    expect(canManage(as(OTHER, "buyer"), OWNER)).toBe(false);
    expect(canManage(as(OTHER, "seller"), OWNER)).toBe(false);
    expect(canManage(anonymous, OWNER)).toBe(false);
  });

  it("refuses every signed-in non-owner role", () => {
    // The regression that shipped: a signed-in buyer reading another buyer's
    // company, contact email and annual sourcing budget.
    for (const role of ROLES.filter((r) => r !== "admin")) {
      expect(canManage(as(OTHER, role), OWNER)).toBe(false);
    }
  });
});

describe("conversations: reading and posting differ", () => {
  const BUYER = 10;
  const SELLER = 20;

  it("lets both parties read and post", () => {
    for (const id of [BUYER, SELLER]) {
      expect(canReadConversation(as(id, "buyer"), BUYER, SELLER)).toBe(true);
      expect(canPostToConversation(as(id, "buyer"), BUYER, SELLER)).toBe(true);
    }
  });

  it("lets an admin read but NOT post", () => {
    const admin = as(ADMIN_ID, "admin");
    expect(canReadConversation(admin, BUYER, SELLER)).toBe(true);
    // An admin posting into two other companies' negotiation appears in the
    // transcript as a participant. Moderation is read-only.
    expect(canPostToConversation(admin, BUYER, SELLER)).toBe(false);
  });

  it("excludes an unrelated signed-in user from both", () => {
    const stranger = as(99, "buyer");
    expect(canReadConversation(stranger, BUYER, SELLER)).toBe(false);
    expect(canPostToConversation(stranger, BUYER, SELLER)).toBe(false);
    expect(isParty(stranger, BUYER, SELLER)).toBe(false);
  });

  it("excludes anonymous callers from both", () => {
    expect(canReadConversation(anonymous, BUYER, SELLER)).toBe(false);
    expect(canPostToConversation(anonymous, BUYER, SELLER)).toBe(false);
  });

  it("does not let a legacy enquiry with a missing side become public", () => {
    expect(canReadConversation(as(99, "seller"), null, null)).toBe(false);
    expect(canPostToConversation(anonymous, null, null)).toBe(false);
  });
});

describe("canSetVerificationStatus", () => {
  it("is admin-only, including against the actor's own row", () => {
    expect(canSetVerificationStatus(as(ADMIN_ID, "admin"))).toBe(true);
    // A seller approving their own profile would make "Verified Exporter"
    // mean nothing, which is the product.
    expect(canSetVerificationStatus(as(OWNER, "seller"))).toBe(false);
    expect(canSetVerificationStatus(as(OWNER, "buyer"))).toBe(false);
    expect(canSetVerificationStatus(anonymous)).toBe(false);
  });
});

describe("canChangeAccountStatus", () => {
  it("lets an admin act on others", () => {
    expect(canChangeAccountStatus(as(ADMIN_ID, "admin"), OWNER)).toBe(true);
  });

  it("stops an admin acting on themselves", () => {
    // Otherwise the only administrator can suspend the platform's way back in.
    expect(canChangeAccountStatus(as(ADMIN_ID, "admin"), ADMIN_ID)).toBe(false);
  });

  it("refuses non-admins entirely", () => {
    expect(canChangeAccountStatus(as(OWNER, "seller"), OTHER)).toBe(false);
    expect(canChangeAccountStatus(anonymous, OTHER)).toBe(false);
  });
});

describe("full role x ownership matrix", () => {
  // Enumerated rather than spot-checked, so adding a role fails loudly here
  // instead of silently defaulting to permitted somewhere in a route handler.
  const cases: Array<[Role | undefined, number | undefined, boolean]> = [
    ["buyer", OWNER, true],
    ["seller", OWNER, true],
    ["admin", OWNER, true],
    ["buyer", OTHER, false],
    ["seller", OTHER, false],
    ["admin", OTHER, true],
    [undefined, undefined, false],
  ];

  it.each(cases)("role=%s id=%s -> canManage(owner=1) === %s", (role, userId, expected) => {
    expect(canManage(as(userId, role), OWNER)).toBe(expected);
  });
});
