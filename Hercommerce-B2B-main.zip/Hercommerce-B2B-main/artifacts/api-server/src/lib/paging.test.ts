import { describe, it, expect } from "vitest";
import { pageFrom, DEFAULT_PAGE_SIZE, MAX_PAGE_SIZE } from "./paging";

describe("pageFrom", () => {
  it("defaults when nothing is supplied", () => {
    expect(pageFrom({})).toEqual({ limit: DEFAULT_PAGE_SIZE, offset: 0 });
  });

  it("accepts numeric strings, which is how they arrive on a query string", () => {
    expect(pageFrom({ limit: "10", offset: "20" })).toEqual({ limit: 10, offset: 20 });
  });

  it("caps an oversized limit rather than rejecting it", () => {
    expect(pageFrom({ limit: "10000" }).limit).toBe(MAX_PAGE_SIZE);
  });

  // Any of these reaching a SQL LIMIT unchecked is either an error or an
  // unbounded scan on a 10s serverless budget.
  it.each([
    ["abc", DEFAULT_PAGE_SIZE],
    ["", DEFAULT_PAGE_SIZE],
    [undefined, DEFAULT_PAGE_SIZE],
    [null, DEFAULT_PAGE_SIZE],
    ["Infinity", DEFAULT_PAGE_SIZE],
    ["NaN", DEFAULT_PAGE_SIZE],
    ["0", 1],
    ["-5", 1],
  ])("normalises limit=%s to %s", (input, expected) => {
    expect(pageFrom({ limit: input }).limit).toBe(expected);
  });

  it("never produces a negative offset", () => {
    expect(pageFrom({ offset: "-10" }).offset).toBe(0);
  });

  it("floors a fractional value so it is a usable SQL integer", () => {
    expect(pageFrom({ limit: "10.9", offset: "3.7" })).toEqual({ limit: 10, offset: 3 });
  });
});
