import type { Response } from "express";

// Values that begin with any of these are interpreted as a formula by Excel,
// LibreOffice and Google Sheets. Since exports contain user-supplied text
// (company names, names, emails), an unescaped export lets a hostile signup run
// code on the machine of the admin who opens the file. Prefixing with a single
// quote neutralises it while keeping the value readable.
const FORMULA_PREFIXES = ["=", "+", "-", "@", "\t", "\r"];

export type CsvValue = string | number | null | undefined;

function escapeCell(value: CsvValue): string {
  if (value === null || value === undefined) return "";

  let text = String(value);

  if (FORMULA_PREFIXES.some((p) => text.startsWith(p))) {
    text = `'${text}`;
  }

  // RFC 4180: quote whenever the value contains a delimiter, a quote or a line
  // break, and double any embedded quotes. Without this a company name
  // containing a comma silently shifts every later column.
  if (/[",\n\r]/.test(text)) {
    text = `"${text.replace(/"/g, '""')}"`;
  }

  return text;
}

export function toCsv(headers: string[], rows: CsvValue[][]): string {
  const lines = [
    headers.map(escapeCell).join(","),
    ...rows.map((row) => row.map(escapeCell).join(",")),
  ];
  // CRLF per RFC 4180, Excel on Windows is happier with it.
  return lines.join("\r\n");
}

export function sendCsv(res: Response, filename: string, csv: string): void {
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  // Prevent a browser from ever rendering this as HTML.
  res.setHeader("X-Content-Type-Options", "nosniff");
  // UTF-8 BOM so Excel reads non-ASCII company names correctly.
  res.send(`﻿${csv}`);
}
