import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import { appUrl } from "./app-url";

vi.mock("./logger", () => ({ logger: { warn: vi.fn(), error: vi.fn() } }));

const original = process.env.APP_URL;
beforeEach(() => { delete process.env.APP_URL; });
afterEach(() => { if (original === undefined) delete process.env.APP_URL; else process.env.APP_URL = original; });

describe("appUrl", () => {
  it("passes a well-formed URL through", () => {
    process.env.APP_URL = "https://originance.co";
    expect(appUrl()).toBe("https://originance.co");
  });

  // The value that actually broke Google sign-in in production: the whole
  // NAME=value line pasted into the dashboard's value field, producing
  // redirect_uri=APP_URL=https://originance.co/api/auth/google/callback
  it("strips a pasted NAME= prefix", () => {
    process.env.APP_URL = "APP_URL=https://originance.co";
    expect(appUrl()).toBe("https://originance.co");
  });

  it("strips wrapping quotes, the other common paste artefact", () => {
    process.env.APP_URL = '"https://originance.co"';
    expect(appUrl()).toBe("https://originance.co");
  });

  it("strips trailing slashes so callers can concatenate a path safely", () => {
    process.env.APP_URL = "https://originance.co///";
    expect(appUrl()).toBe("https://originance.co");
  });

  it("handles a prefix, quotes and a trailing slash together", () => {
    process.env.APP_URL = 'APP_URL="https://originance.co/"';
    expect(appUrl()).toBe("https://originance.co");
  });

  it("returns empty for unset or blank, so callers can detect it", () => {
    expect(appUrl()).toBe("");
    process.env.APP_URL = "   ";
    expect(appUrl()).toBe("");
  });

  // Returning a relative or garbage value would put dead links in every
  // verification email, so it is better to return nothing and log.
  it.each(["originance.co", "/api", "ftp://x", "not a url"])("rejects %s", (v) => {
    process.env.APP_URL = v;
    expect(appUrl()).toBe("");
  });

  it("keeps a localhost dev URL including its port", () => {
    process.env.APP_URL = "http://localhost:5173";
    expect(appUrl()).toBe("http://localhost:5173");
  });
});
