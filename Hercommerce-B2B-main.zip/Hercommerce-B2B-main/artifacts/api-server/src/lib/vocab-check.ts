import {
  ALL_COUNTRIES,
  CATEGORIES,
  CERTIFICATIONS,
  REVENUE_BANDS,
  EMPLOYEE_BANDS,
  BUDGET_BANDS,
  CURRENCIES,
  UNITS,
  INCOTERMS,
  isMemberOf,
} from "@workspace/vocab";

// The profile and RFQ routes accepted any string for every controlled field:
// country, categories, markets, origins, certifications and the size bands.
// The forms offered fixed lists, but that was UX only; a hand-rolled request,
// an old client, or a free-text field stored whatever it was given. It matters
// because matching and filtering compare these strings exactly, so a value
// outside the list is not merely untidy, it silently never matches anything.
// "Thaiti" in a buyer's country is the live example.
//
// Absent fields are not checked: on a PATCH they mean "leave unchanged", and
// every one of these is optional somewhere.

type List = readonly string[];

interface Rule {
  label: string;
  list: List;
  noun: string;
}

const SINGLE: Record<string, Rule> = {
  country: { label: "Country", list: ALL_COUNTRIES, noun: "country" },
  destinationCountry: { label: "Destination country", list: ALL_COUNTRIES, noun: "country" },
  category: { label: "Category", list: CATEGORIES, noun: "category" },
  annualRevenue: { label: "Annual revenue", list: REVENUE_BANDS, noun: "revenue band" },
  employeeCount: { label: "Employees", list: EMPLOYEE_BANDS, noun: "employee band" },
  annualBudget: { label: "Annual budget", list: BUDGET_BANDS, noun: "budget band" },
  // Shared field names across products, RFQs and quotes, so one rule covers each.
  currency: { label: "Currency", list: CURRENCIES, noun: "currency" },
  targetCurrency: { label: "Target price currency", list: CURRENCIES, noun: "currency" },
  unit: { label: "Unit", list: UNITS, noun: "unit" },
  incoterm: { label: "Incoterm", list: INCOTERMS, noun: "Incoterm" },
};

const MULTI: Record<string, Rule> = {
  categories: { label: "Product categories", list: CATEGORIES, noun: "category" },
  interestedCategories: { label: "Categories you source", list: CATEGORIES, noun: "category" },
  exportMarkets: { label: "Export markets", list: ALL_COUNTRIES, noun: "country" },
  preferredOrigins: { label: "Preferred origins", list: ALL_COUNTRIES, noun: "country" },
  certifications: { label: "Certifications", list: CERTIFICATIONS, noun: "certification" },
};

/**
 * The first controlled-vocabulary violation in `input`, as a sentence a user
 * can act on, or null when every present field is valid.
 */
export function vocabError(input: Record<string, unknown>): string | null {
  for (const [field, rule] of Object.entries(SINGLE)) {
    const value = input[field];
    // null and "" clear an optional field; neither is a vocabulary term.
    if (value === undefined || value === null || value === "") continue;
    if (typeof value !== "string" || !isMemberOf(rule.list, value)) {
      return `${rule.label}: "${String(value)}" is not a recognised ${rule.noun}.`;
    }
  }
  for (const [field, rule] of Object.entries(MULTI)) {
    const value = input[field];
    if (value === undefined || value === null) continue;
    if (!Array.isArray(value)) return `${rule.label} must be a list.`;
    const unknown = value.find((v) => typeof v !== "string" || !isMemberOf(rule.list, v));
    if (unknown !== undefined) {
      return `${rule.label}: "${String(unknown)}" is not a recognised ${rule.noun}.`;
    }
  }
  return null;
}
