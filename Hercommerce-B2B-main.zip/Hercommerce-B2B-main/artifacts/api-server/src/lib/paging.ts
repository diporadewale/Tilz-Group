// Both public lists grow without bound and neither paged. The exporter
// directory silently truncated at a hard 200, so the 201st exporter was
// unreachable with nothing in the response to say so, and the product list had
// no cap at all, which on a 10s serverless budget fails as a timeout rather
// than as an error anyone can act on.
//
// Clamped rather than validated-and-rejected: a caller asking for 10000 rows is
// almost always a naive client, not an attack, and quietly serving them the
// maximum is friendlier than a 400 they have to learn about.

export const DEFAULT_PAGE_SIZE = 50;
export const MAX_PAGE_SIZE = 200;

export interface Page {
  limit: number;
  offset: number;
}

/** Reads `limit`/`offset` from a query string, clamped to a sane range. */
export function pageFrom(query: { limit?: unknown; offset?: unknown }): Page {
  return {
    limit: clamp(query.limit, DEFAULT_PAGE_SIZE, 1, MAX_PAGE_SIZE),
    offset: clamp(query.offset, 0, 0, Number.MAX_SAFE_INTEGER),
  };
}

function clamp(raw: unknown, fallback: number, min: number, max: number): number {
  // Absent must be handled before Number(), which maps both "" and null to 0.
  // A bare `?limit=` in a URL arrives as "", and would otherwise clamp to the
  // minimum and return a single row instead of a page.
  if (raw === undefined || raw === null || raw === "") return fallback;
  const n = Number(raw);
  // Catches "abc", "NaN" and "Infinity" alike, none of which may reach a SQL LIMIT.
  if (!Number.isFinite(n)) return fallback;
  return Math.min(Math.max(Math.floor(n), min), max);
}
