import { describe, it, expect } from "vitest";
import { validationMessage } from "./validation";

describe("validationMessage", () => {
  // Zod's error.message is the serialised issue array. Returning it leaked
  // internal schema shape to clients from 47 handlers.
  it("turns an issue array into one readable sentence", () => {
    const message = validationMessage({
      issues: [{ path: ["id"], message: "Expected number, received nan" }],
    });
    expect(message).toBe("id: Expected number, received nan");
    expect(message).not.toContain("invalid_type");
    expect(message).not.toContain("{");
  });

  it("joins several issues", () => {
    expect(
      validationMessage({
        issues: [
          { path: ["email"], message: "Invalid email" },
          { path: ["password"], message: "Too short" },
        ],
      }),
    ).toBe("email: Invalid email; password: Too short");
  });

  it("caps the list and says how many were omitted", () => {
    const issues = Array.from({ length: 7 }, (_, i) => ({ path: [`f${i}`], message: "bad" }));
    const message = validationMessage({ issues });
    expect(message).toContain("(and 3 more)");
    expect(message.split(";").length).toBe(4);
  });

  it("renders a nested path with dots", () => {
    expect(validationMessage({ issues: [{ path: ["user", "address", "city"], message: "Required" }] }))
      .toBe("user.address.city: Required");
  });

  it("omits the prefix when the issue has no path", () => {
    expect(validationMessage({ issues: [{ path: [], message: "Body is required" }] }))
      .toBe("Body is required");
  });

  // Must never throw: it runs on the error path of every handler.
  it.each([[null], [undefined], [{}], [{ issues: [] }], [{ issues: "nope" }], ["a string"]])(
    "falls back for malformed input %s",
    (input) => {
      expect(validationMessage(input)).toBe("Invalid request.");
    },
  );
});
