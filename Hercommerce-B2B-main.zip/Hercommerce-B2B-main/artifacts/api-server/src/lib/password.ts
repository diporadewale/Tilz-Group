import { randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

// Password hashing with Node's built-in scrypt, no native module to bundle
// (bcrypt/argon2 are native and would break the Vercel function bundle), no
// external dependency, no cost. Stored format: `scrypt:<saltHex>:<hashHex>`.
const scryptAsync = promisify(scrypt);

const KEY_LENGTH = 64;
const SALT_BYTES = 16;

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(SALT_BYTES).toString("hex");
  const derived = (await scryptAsync(password, salt, KEY_LENGTH)) as Buffer;
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

// A throwaway hash used only to burn roughly the same amount of CPU as a real
// verify when the account does not exist. Without this, "unknown email" returns
// noticeably faster than "wrong password" and login becomes a user-enumeration
// oracle. Generated once at module load so it costs nothing per request.
const DUMMY_HASH_PROMISE = hashPassword(randomBytes(32).toString("hex"));

/**
 * Runs the same scrypt work as {@link verifyPassword} and always returns false.
 * Call this on the "no such user" branch so both branches take similar time.
 */
export async function verifyPasswordDummy(password: string): Promise<boolean> {
  await verifyPassword(password, await DUMMY_HASH_PROMISE);
  return false;
}

export async function verifyPassword(
  password: string,
  stored: string,
): Promise<boolean> {
  const parts = stored.split(":");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;

  const [, salt, hashHex] = parts;
  const expected = Buffer.from(hashHex, "hex");
  const derived = (await scryptAsync(password, salt, expected.length)) as Buffer;

  // Constant-time comparison; lengths are equal by construction but guard
  // anyway since timingSafeEqual throws on a length mismatch.
  return (
    expected.length === derived.length && timingSafeEqual(expected, derived)
  );
}
