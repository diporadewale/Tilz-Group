import { logger } from "./logger";

// APP_URL builds both the OAuth redirect URI and every link inside outbound
// email, so a malformed value fails in two places at once, and silently:
// Google reports `redirect_uri_mismatch` on its own page (never in our logs),
// and email links simply go nowhere.
//
// The observed failure was a value of "APP_URL=https://originance.co", i.e. the
// whole `NAME=value` line pasted into the dashboard's value field. Strip that
// and warn, rather than propagating a broken URL into user-facing links.
export function appUrl(): string {
  let raw = (process.env.APP_URL ?? "").trim();
  if (!raw) return "";

  // Tolerate a pasted `APP_URL=…` (or any KEY=) prefix.
  const prefixed = /^[A-Z_][A-Z0-9_]*=(.*)$/i.exec(raw);
  if (prefixed) {
    logger.warn(
      { rawValue: raw },
      "APP_URL contains a NAME= prefix, set the value only, not the whole line",
    );
    raw = prefixed[1].trim();
  }

  // Strip wrapping quotes, another common dashboard paste artefact.
  raw = raw.replace(/^["']|["']$/g, "").replace(/\/+$/, "");

  if (!/^https?:\/\/[^\s/]+/i.test(raw)) {
    logger.error({ rawValue: raw }, "APP_URL is not a valid absolute URL");
    return "";
  }
  return raw;
}
