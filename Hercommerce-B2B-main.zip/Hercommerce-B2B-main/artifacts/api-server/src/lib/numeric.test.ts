import { describe, it, expect } from "vitest";
import { isNonNegativeNumeric, firstNumericError, isInvertedRange } from "./numeric";

describe("isNonNegativeNumeric", () => {
  it("accepts absent values, since these fields are optional", () => {
    expect(isNonNegativeNumeric(null)).toBe(true);
    expect(isNonNegativeNumeric(undefined)).toBe(true);
    expect(isNonNegativeNumeric("")).toBe(true);
  });

  it.each(["0", "5", "3.80", " 4.20 "])("accepts %s", (v) => {
    expect(isNonNegativeNumeric(v)).toBe(true);
  });

  // "USD abc - -5" was rendering on the public catalogue before this existed.
  it.each(["abc", "-5", "-0.01", "NaN", "1e", "12abc"])("rejects %s", (v) => {
    expect(isNonNegativeNumeric(v)).toBe(false);
  });

  it("rejects Infinity, which Number() happily parses", () => {
    expect(isNonNegativeNumeric("Infinity")).toBe(false);
  });
});

describe("firstNumericError", () => {
  it("returns null when everything is valid", () => {
    expect(firstNumericError({ Quantity: "10", "Target price": undefined })).toBeNull();
  });

  it("names the offending field in the message", () => {
    const message = firstNumericError({ Quantity: "abc" });
    expect(message).toContain("Quantity");
  });
});

describe("isInvertedRange", () => {
  it("flags a minimum above the maximum", () => {
    expect(isInvertedRange("5", "3")).toBe(true);
  });

  it("allows an equal range and a normal one", () => {
    expect(isInvertedRange("3", "3")).toBe(false);
    expect(isInvertedRange("3", "5")).toBe(false);
  });

  it("does not flag a half-open range", () => {
    expect(isInvertedRange("3", undefined)).toBe(false);
    expect(isInvertedRange(undefined, "5")).toBe(false);
  });
});
