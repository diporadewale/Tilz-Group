// Company websites were stored exactly as typed and rendered straight into
// <a href>. Two failures followed. "afrofresh.com", the way most people write a
// domain, has no scheme, so the browser resolved it relative to the current
// page: the link on /sellers/5 went to /sellers/afrofresh.com, a 404 on our own
// site. And the only guard against a non-web scheme was React, at render time,
// in one of the places the value is shown.
//
// The profile form used type="url" to force a scheme, which moved the problem
// rather than solving it: the browser refused "afrofresh.com" with a tooltip,
// which reads as the site being broken. So the form now accepts what people
// type and this makes it a real link.

export type WebsiteResult =
  | { ok: true; value: string | undefined }
  | { ok: false; error: string };

/**
 * undefined stays undefined (field not sent: leave it alone on a PATCH).
 * Blank becomes "" (the user cleared it). Anything else becomes an absolute
 * http(s) URL, or an error a user can act on.
 */
export function normaliseWebsite(raw: unknown): WebsiteResult {
  if (raw === undefined || raw === null) return { ok: true, value: undefined };
  if (typeof raw !== "string") return { ok: false, error: "Website must be text." };

  const trimmed = raw.trim();
  if (trimmed === "") return { ok: true, value: "" };
  if (/\s/.test(trimmed)) return { ok: false, error: "Website can't contain spaces." };

  // Bare domain: assume https. Anything that already names a scheme is judged
  // on that scheme, which is how javascript:, data: and ftp: are refused below.
  const candidate = /^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;

  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return { ok: false, error: `"${trimmed}" doesn't look like a website address.` };
  }

  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { ok: false, error: "Website must be an http or https address." };
  }
  // A business site has a domain with a dot in it. Refusing bare hostnames
  // catches "afrofresh" and also keeps "localhost" out of a public profile.
  if (!url.hostname.includes(".")) {
    return { ok: false, error: `"${trimmed}" is missing a domain ending such as .com.` };
  }

  // Rebuilt rather than url.toString(), which appends "/" to a bare host and
  // would turn every stored domain into a slightly different string.
  const path = url.pathname === "/" ? "" : url.pathname;
  return { ok: true, value: `${url.protocol}//${url.host}${path}${url.search}${url.hash}` };
}
