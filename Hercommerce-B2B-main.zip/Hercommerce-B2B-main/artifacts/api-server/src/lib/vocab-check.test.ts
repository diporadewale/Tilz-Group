import { describe, it, expect } from "vitest";
import { ALL_COUNTRIES, COUNTRIES } from "@workspace/vocab";
import { vocabError } from "./vocab-check";

describe("vocabulary invariants", () => {
  // Existing rows store the 24 curated names. If any were missing from the
  // full list, every one of those profiles would start failing validation.
  it("contains every curated country verbatim", () => {
    const all = new Set<string>(ALL_COUNTRIES);
    expect(COUNTRIES.filter((c) => !all.has(c))).toEqual([]);
  });

  it("has no duplicates", () => {
    expect(new Set(ALL_COUNTRIES).size).toBe(ALL_COUNTRIES.length);
  });

  it("is sorted, so the dropdown needs no client-side sort", () => {
    const sorted = [...ALL_COUNTRIES].sort((a, b) => a.localeCompare(b, "en"));
    expect([...ALL_COUNTRIES]).toEqual(sorted);
  });
});

describe("vocabError", () => {
  it("accepts a valid profile", () => {
    expect(vocabError({
      country: "Ghana",
      categories: ["Cocoa", "Spices"],
      exportMarkets: ["Germany", "Uganda"],
      certifications: ["EU Organic"],
      annualRevenue: "$1M - $2M",
      employeeCount: "10-20",
    })).toBeNull();
  });

  // Beyond the curated 24: the reason ALL_COUNTRIES exists.
  it("accepts a country outside the featured shortlist", () => {
    expect(vocabError({ country: "Rwanda", preferredOrigins: ["Côte d'Ivoire"] })).toBeNull();
  });

  it("rejects the misspelling found in live data, naming the field and value", () => {
    expect(vocabError({ country: "Thaiti" })).toBe('Country: "Thaiti" is not a recognised country.');
  });

  it("rejects the legacy certification found in live data", () => {
    expect(vocabError({ certifications: ["Fair Trade", "Organic"] }))
      .toBe('Certifications: "Organic" is not a recognised certification.');
  });

  it("is case-sensitive, because matching compares strings exactly", () => {
    expect(vocabError({ country: "ghana" })).not.toBeNull();
  });

  it("ignores absent fields, so a status-only PATCH is not blocked by old data", () => {
    expect(vocabError({ status: "approved" })).toBeNull();
  });

  it("treats null and empty string as clearing an optional field", () => {
    expect(vocabError({ destinationCountry: null, annualBudget: "" })).toBeNull();
  });

  it("rejects a non-array where a list is expected", () => {
    expect(vocabError({ categories: "Cocoa" })).toBe("Product categories must be a list.");
  });

  it("rejects a non-string inside a list", () => {
    expect(vocabError({ exportMarkets: ["Germany", 7] })).not.toBeNull();
  });
});

describe("quote and RFQ pricing vocabulary", () => {
  it("accepts a fully structured quote", () => {
    expect(vocabError({ currency: "GBP", unit: "tonne", incoterm: "CIF" })).toBeNull();
  });

  it.each([
    [{ currency: "usd" }, 'Currency: "usd" is not a recognised currency.'],
    [{ currency: "$" }, 'Currency: "$" is not a recognised currency.'],
    [{ unit: "kilos" }, 'Unit: "kilos" is not a recognised unit.'],
    // Pre-2010 terms and free text are refused; the place goes in its own field.
    [{ incoterm: "DDU" }, 'Incoterm: "DDU" is not a recognised Incoterm.'],
    [{ incoterm: "FOB Lagos" }, 'Incoterm: "FOB Lagos" is not a recognised Incoterm.'],
    [{ targetCurrency: "Dollars" }, 'Target price currency: "Dollars" is not a recognised currency.'],
  ])("rejects %j", (input, message) => {
    expect(vocabError(input)).toBe(message);
  });

  it("treats an omitted Incoterm as fine, since it is optional", () => {
    expect(vocabError({ currency: "USD", unit: "kg", incoterm: null })).toBeNull();
  });
});

