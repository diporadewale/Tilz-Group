import { db, notificationsTable } from "@workspace/db";
import { logger } from "./logger";

type NewNotification = {
  type: string;
  title: string;
  body?: string | null;
  link?: string | null;
};

// Fire-and-log: a notification failure must never break the user action that
// triggered it.
export async function notify(userId: number, n: NewNotification): Promise<void> {
  try {
    await db.insert(notificationsTable).values({
      userId,
      type: n.type,
      title: n.title,
      body: n.body ?? null,
      link: n.link ?? null,
    });
  } catch (err) {
    logger.error({ err, userId }, "Failed to create notification");
  }
}

export async function notifyMany(userIds: number[], n: NewNotification): Promise<void> {
  await Promise.all([...new Set(userIds)].map((id) => notify(id, n)));
}
