// Several user-facing numeric fields are stored as text (prices, RFQ quantity
// and target price) and had no validation on either side, so values like "abc"
// and "-5" were accepted and rendered publicly, e.g. "USD abc – -5" on the
// product catalogue. Client-side `type="number"` is a convenience, not a
// guarantee; these helpers are the actual gate.

/** True when `value` is absent, or parses as a finite number >= 0. */
export function isNonNegativeNumeric(value: string | null | undefined): boolean {
  if (value === null || value === undefined || value === "") return true;
  const n = Number(value.trim());
  return Number.isFinite(n) && n >= 0;
}

/**
 * Validate a set of optional numeric-text fields.
 * Returns the first human-readable error, or null when everything is fine.
 */
export function firstNumericError(
  fields: Record<string, string | null | undefined>,
): string | null {
  for (const [label, value] of Object.entries(fields)) {
    if (!isNonNegativeNumeric(value)) {
      return `${label} must be a number of 0 or more.`;
    }
  }
  return null;
}

/** True when both are present and min > max. */
export function isInvertedRange(
  min: string | null | undefined,
  max: string | null | undefined,
): boolean {
  if (!min || !max) return false;
  const lo = Number(min);
  const hi = Number(max);
  if (!Number.isFinite(lo) || !Number.isFinite(hi)) return false;
  return lo > hi;
}
