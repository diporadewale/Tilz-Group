import { and, eq, gt, lt, sql } from "drizzle-orm";
import { db, authAttemptsTable } from "@workspace/db";

// Postgres-backed, not in-memory. On Vercel consecutive requests may land in
// different function instances, so a module-level Map would reset constantly
// and enforce nothing while looking like it worked.

export type RateLimitAction = "login" | "register" | "forgot-password" | "reset-password";

interface Rule {
  /** Attempts allowed per identifier (usually an email) inside the window. */
  perIdentifier: number;
  /** Attempts allowed per source IP inside the window. */
  perIp: number;
  windowSeconds: number;
}

// Tuned so a person who has genuinely forgotten which password they used is
// never blocked, while automated volume is. The per-IP ceilings are the looser
// of the two on purpose: offices and mobile carriers put many real users behind
// one address, so the email limit is what actually protects an account and the
// IP limit only catches spraying across many accounts.
const RULES: Record<RateLimitAction, Rule> = {
  login: { perIdentifier: 8, perIp: 40, windowSeconds: 15 * 60 },
  register: { perIdentifier: 5, perIp: 15, windowSeconds: 60 * 60 },
  // The tightest, because each one sends mail: this is both an account-takeover
  // funnel and a way to flood someone's inbox on our Resend quota.
  "forgot-password": { perIdentifier: 3, perIp: 12, windowSeconds: 60 * 60 },
  "reset-password": { perIdentifier: 10, perIp: 30, windowSeconds: 60 * 60 },
};

export interface RateLimitResult {
  allowed: boolean;
  /** Seconds to wait, for the Retry-After header. Only meaningful when blocked. */
  retryAfterSeconds: number;
}

async function countSince(
  action: RateLimitAction,
  column: "identifier" | "ip",
  value: string,
  since: Date,
): Promise<number> {
  const [row] = await db
    .select({ value: sql<number>`count(*)` })
    .from(authAttemptsTable)
    .where(
      and(
        eq(authAttemptsTable.action, action),
        eq(authAttemptsTable[column], value),
        gt(authAttemptsTable.createdAt, since),
      ),
    );
  return Number(row?.value ?? 0);
}

/**
 * Read-only. Does not consume an attempt, so a successful login is never
 * counted against the user; callers record a failure explicitly.
 */
export async function checkRateLimit(
  action: RateLimitAction,
  identifier: string,
  ip: string,
): Promise<RateLimitResult> {
  const rule = RULES[action];
  const since = new Date(Date.now() - rule.windowSeconds * 1000);

  const [byIdentifier, byIp] = await Promise.all([
    identifier ? countSince(action, "identifier", identifier, since) : Promise.resolve(0),
    ip ? countSince(action, "ip", ip, since) : Promise.resolve(0),
  ]);

  const blocked = byIdentifier >= rule.perIdentifier || byIp >= rule.perIp;
  return { allowed: !blocked, retryAfterSeconds: blocked ? rule.windowSeconds : 0 };
}

/** Records one failed attempt. Never throws: a logging failure must not deny a login. */
export async function recordAttempt(
  action: RateLimitAction,
  identifier: string,
  ip: string,
): Promise<void> {
  try {
    await db.insert(authAttemptsTable).values({ action, identifier, ip });

    // Opportunistic pruning. The table is append-only and every read is a
    // bounded index range, so stale rows cost storage rather than speed;
    // sweeping on roughly one write in twenty keeps it from growing forever
    // without adding a cron job or a delete to every request.
    if (Math.random() < 0.05) {
      const oldest = new Date(Date.now() - 24 * 60 * 60 * 1000);
      await db.delete(authAttemptsTable).where(lt(authAttemptsTable.createdAt, oldest));
    }
  } catch {
    // Deliberately swallowed. If the attempts table is unavailable the correct
    // behaviour is to let a legitimate user sign in, not to lock everyone out.
  }
}

/** Clears an identifier's history after a genuine success, so the next typo starts fresh. */
export async function clearAttempts(action: RateLimitAction, identifier: string): Promise<void> {
  if (!identifier) return;
  try {
    await db
      .delete(authAttemptsTable)
      .where(and(eq(authAttemptsTable.action, action), eq(authAttemptsTable.identifier, identifier)));
  } catch {
    // Same reasoning as recordAttempt.
  }
}

/**
 * The caller's address. Behind Vercel the socket address is the proxy, so the
 * real client is the leftmost x-forwarded-for entry. Spoofable by anyone who
 * can reach the origin directly, which is why the per-identifier limit above,
 * not this, is the one that protects an account.
 */
export function clientIp(req: { ip?: string; headers: Record<string, unknown> }): string {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string" && forwarded.length > 0) {
    return forwarded.split(",")[0]!.trim();
  }
  return req.ip ?? "";
}
