import { describe, it, expect } from "vitest";
import { toCsv } from "./csv";

describe("toCsv", () => {
  it("emits a header row and CRLF line endings per RFC 4180", () => {
    expect(toCsv(["a", "b"], [["1", "2"]])).toBe('a,b\r\n1,2');
  });

  // The original bug: an unescaped =/+/-/@ prefix in a company name became a
  // live formula when an admin opened the export in Excel.
  it.each(["=1+1", "+1", "-1", "@SUM(A1)"])("neutralises the formula prefix %s", (value) => {
    const out = toCsv(["name"], [[value]]);
    const cell = out.split("\r\n")[1]!;
    expect(cell.startsWith("=")).toBe(false);
    expect(cell.startsWith("+")).toBe(false);
    expect(cell.startsWith("@")).toBe(false);
    expect(cell).toContain(value);
  });

  it("quotes cells containing a comma so columns do not shift", () => {
    const out = toCsv(["name"], [["Lagos, Nigeria"]]);
    expect(out.split("\r\n")[1]).toBe('"Lagos, Nigeria"');
  });

  it("escapes embedded quotes by doubling them", () => {
    const out = toCsv(["name"], [['He said "hi"']]);
    expect(out.split("\r\n")[1]).toBe('"He said ""hi"""');
  });

  it("keeps a newline inside a cell from breaking the row structure", () => {
    const out = toCsv(["note"], [["line1\nline2"]]);
    expect(out.split("\r\n")[1]!.startsWith('"')).toBe(true);
  });

  it("renders null and undefined as empty rather than the string 'null'", () => {
    expect(toCsv(["a", "b"], [[null, undefined]]).split("\r\n")[1]).toBe(",");
  });
});
