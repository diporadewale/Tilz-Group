import { describe, it, expect } from "vitest";
import { normaliseWebsite } from "./website";

const ok = (raw: unknown) => {
  const r = normaliseWebsite(raw);
  if (!r.ok) throw new Error(`expected ok, got: ${r.error}`);
  return r.value;
};
const fails = (raw: unknown) => normaliseWebsite(raw).ok === false;

describe("normaliseWebsite", () => {
  // The case that produced a relative link to /sellers/afrofresh.com.
  it("adds https to a bare domain", () => {
    expect(ok("afrofresh.com")).toBe("https://afrofresh.com");
    expect(ok("www.afrofresh.com")).toBe("https://www.afrofresh.com");
  });

  it("keeps an explicit scheme, path and query", () => {
    expect(ok("http://afrofresh.com")).toBe("http://afrofresh.com");
    expect(ok("https://afrofresh.com/about?lang=en#team")).toBe("https://afrofresh.com/about?lang=en#team");
  });

  it("does not append a trailing slash to a bare host", () => {
    expect(ok("https://afrofresh.com/")).toBe("https://afrofresh.com");
  });

  it("trims surrounding whitespace, a common paste artefact", () => {
    expect(ok("  afrofresh.com  ")).toBe("https://afrofresh.com");
  });

  it("distinguishes not-sent from cleared", () => {
    // undefined leaves a PATCH untouched; "" is the user emptying the field.
    expect(ok(undefined)).toBeUndefined();
    expect(ok(null)).toBeUndefined();
    expect(ok("")).toBe("");
    expect(ok("   ")).toBe("");
  });

  it.each([
    "javascript:alert(1)",
    "javascript://alert(1)",
    "data:text/html,<script>alert(1)</script>",
    "ftp://files.example.com",
    "file:///etc/passwd",
  ])("refuses the non-web scheme %s", (raw) => {
    expect(fails(raw)).toBe(true);
  });

  it.each(["afrofresh", "localhost", "http://localhost:3000"])(
    "refuses %s, which has no public domain",
    (raw) => expect(fails(raw)).toBe(true),
  );

  it("refuses text with spaces", () => {
    expect(fails("afro fresh.com")).toBe(true);
  });

  it("refuses non-string input", () => {
    expect(fails(42)).toBe(true);
    expect(fails({ href: "x" })).toBe(true);
  });
});
