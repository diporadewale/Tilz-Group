import { eq } from "drizzle-orm";
import {
  db,
  documentsTable,
  readinessTiersTable,
  sellerProfilesTable,
} from "@workspace/db";

// ── Readiness: one place that owns the tier calculation ──────────────────────
//
// Two things previously went wrong here and both are worth spelling out.
//
// 1. Key space. `readiness_tiers.sellerId` is a **seller_profiles.id**, because
//    that is what every reader passes: GET/PATCH /readiness/:sellerId is called
//    with a profile id by the seller detail page and the admin table, and the
//    buyer matching query joins on `sellerProfiles.id`. Document verification
//    used to write rows keyed by **users.id** instead, so approving documents
//    updated a row nobody read.
//
// 2. Denormalisation. The tier a buyer actually sees on directory cards, match
//    results and RFQ quotes comes from `seller_profiles.readinessTier`, a
//    separate column. Writing only `readiness_tiers` left the badge stale
//    forever. Every write path now updates both, so the badge always reflects
//    the stored tier.

export type Tier = "bronze" | "silver" | "gold" | "platinum";

const DOCUMENTS_REQUIRED = 3;

export function tierForVerifiedCount(verified: number): Tier {
  if (verified >= 5) return "platinum";
  if (verified >= 4) return "gold";
  if (verified >= 2) return "silver";
  return "bronze";
}

export function scoreForVerifiedCount(verified: number): number {
  return Math.min(verified * 20, 100);
}

/**
 * Recompute a seller's readiness from their currently-approved documents and
 * persist it. Safe to call after any document status change (approve, reject,
 * or revert), it always recounts from scratch rather than adjusting a delta,
 * so a rejection correctly moves the tier back down.
 *
 * An admin override wins on `tier`, but the underlying document count and score
 * are still refreshed so the admin sees accurate numbers behind their override.
 *
 * @param userId the document owner (users.id)
 */
export async function recalculateReadinessForUser(userId: number): Promise<void> {
  const [profile] = await db
    .select({ id: sellerProfilesTable.id })
    .from(sellerProfilesTable)
    .where(eq(sellerProfilesTable.userId, userId));

  // Documents can belong to a user who has no seller profile yet; there is no
  // readiness to compute for them.
  if (!profile) return;

  const docs = await db
    .select({ status: documentsTable.status })
    .from(documentsTable)
    .where(eq(documentsTable.userId, userId));

  const verified = docs.filter((d) => d.status === "approved").length;
  const computedTier = tierForVerifiedCount(verified);
  const score = scoreForVerifiedCount(verified);

  const [existing] = await db
    .select()
    .from(readinessTiersTable)
    .where(eq(readinessTiersTable.sellerId, profile.id));

  let effectiveTier: Tier;

  if (!existing) {
    await db.insert(readinessTiersTable).values({
      sellerId: profile.id,
      tier: computedTier,
      score,
      documentsVerified: verified,
      documentsRequired: DOCUMENTS_REQUIRED,
      adminOverride: false,
    });
    effectiveTier = computedTier;
  } else if (existing.adminOverride) {
    await db
      .update(readinessTiersTable)
      .set({ documentsVerified: verified, score })
      .where(eq(readinessTiersTable.id, existing.id));
    effectiveTier = existing.tier;
  } else {
    await db
      .update(readinessTiersTable)
      .set({ documentsVerified: verified, score, tier: computedTier })
      .where(eq(readinessTiersTable.id, existing.id));
    effectiveTier = computedTier;
  }

  await syncProfileBadge(profile.id, effectiveTier);
}

/**
 * Mirror the authoritative tier onto `seller_profiles.readinessTier`, which is
 * what the directory, match list and quote rows render.
 */
export async function syncProfileBadge(sellerProfileId: number, tier: Tier): Promise<void> {
  await db
    .update(sellerProfilesTable)
    .set({ readinessTier: tier })
    .where(eq(sellerProfilesTable.id, sellerProfileId));
}

/**
 * The shape GET /readiness/:sellerId returns when a seller has no row yet.
 * Returned instead of inserting, so a GET never writes (and so probing
 * arbitrary ids cannot pollute the table or skew admin tier stats).
 */
export function defaultReadiness(sellerId: number) {
  const now = new Date();
  return {
    id: 0,
    sellerId,
    tier: "bronze" as Tier,
    score: 0,
    documentsVerified: 0,
    documentsRequired: DOCUMENTS_REQUIRED,
    adminOverride: false,
    adminNote: null,
    overriddenBy: null,
    overriddenAt: null,
    createdAt: now,
    updatedAt: now,
  };
}
