import { createHash, randomBytes } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db, authTokensTable } from "@workspace/db";

export type TokenType = "email_verify" | "password_reset";

const TTL_MS: Record<TokenType, number> = {
  email_verify: 1000 * 60 * 60 * 24, // 24h
  password_reset: 1000 * 60 * 60, // 1h
};

function hashToken(raw: string): string {
  return createHash("sha256").update(raw).digest("hex");
}

// Returns the RAW token (goes only into the emailed link); the DB stores its
// sha256 hash.
export async function createToken(
  userId: number,
  type: TokenType,
): Promise<string> {
  const raw = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + TTL_MS[type]);
  await db.insert(authTokensTable).values({
    userId,
    tokenHash: hashToken(raw),
    type,
    expiresAt,
  });
  return raw;
}

// Validates a raw token and marks it used (single-use). Returns the userId on
// success, or null if missing / wrong type / already used / expired.
export async function consumeToken(
  raw: string,
  type: TokenType,
): Promise<number | null> {
  const tokenHash = hashToken(raw);

  const [token] = await db
    .select()
    .from(authTokensTable)
    .where(
      and(
        eq(authTokensTable.tokenHash, tokenHash),
        eq(authTokensTable.type, type),
      ),
    );

  if (!token) return null;
  if (token.usedAt) return null;
  if (token.expiresAt.getTime() < Date.now()) return null;

  await db
    .update(authTokensTable)
    .set({ usedAt: new Date() })
    .where(eq(authTokensTable.id, token.id));

  return token.userId;
}
