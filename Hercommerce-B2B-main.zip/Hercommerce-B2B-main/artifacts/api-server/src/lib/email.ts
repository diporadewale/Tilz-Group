import { logger } from "./logger";
import { appUrl } from "./app-url";

// Email via Resend's HTTP API, no SDK dependency, serverless-friendly. Sends
// are AWAITED by callers so they complete before the function freezes, but they
// NEVER throw: a delivery failure is logged and the user's action still
// succeeds (NFR-001). In test mode (no domain) Resend only delivers to your own
// account email; set EMAIL_FROM to a verified-domain address to reach anyone.
// EMAIL_FROM must be at the domain verified in Resend, we verify the sending
// subdomain em.originance.co, so the from-address lives there and replies are
// redirected to the real mailbox via EMAIL_REPLY_TO.
const RESEND_ENDPOINT = "https://api.resend.com/emails";



interface SendArgs {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail({ to, subject, html }: SendArgs): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    logger.warn({ to, subject }, "RESEND_API_KEY not set; skipping email");
    return;
  }

  const from = process.env.EMAIL_FROM ?? "Originance <onboarding@resend.dev>";

  // We send from the em.originance.co sending subdomain, which has no mailbox
  // behind it, a reply there would bounce or vanish. Point replies at the real
  // support inbox instead (hello@tilzgroup.com), which needs no Resend
  // verification of its own because it is only a Reply-To header, never the
  // envelope sender. Optional: unset means Resend just omits the header.
  const replyTo = process.env.EMAIL_REPLY_TO;

  try {
    const res = await fetch(RESEND_ENDPOINT, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to,
        subject,
        html,
        ...(replyTo ? { reply_to: replyTo } : {}),
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      logger.error({ to, subject, status: res.status, body }, "Email send failed");
    }
  } catch (err) {
    logger.error({ err, to, subject }, "Email send threw");
  }
}

// Minimal branded HTML shell with an optional call-to-action button.
function layout(opts: {
  heading: string;
  body: string;
  ctaLabel?: string;
  ctaUrl?: string;
}): string {
  const button =
    opts.ctaLabel && opts.ctaUrl
      ? `<p style="margin:24px 0"><a href="${opts.ctaUrl}" style="background:hsl(190 80% 20%);color:#fff;text-decoration:none;padding:12px 20px;border-radius:6px;font-weight:600;display:inline-block">${opts.ctaLabel}</a></p>
         <p style="font-size:13px;color:#667">Or paste this link into your browser:<br>${opts.ctaUrl}</p>`
      : "";
  return `<div style="font-family:Inter,Arial,sans-serif;max-width:480px;margin:0 auto;color:#0f2a33">
    <h1 style="font-size:20px">${opts.heading}</h1>
    <p style="font-size:15px;line-height:1.5;color:#33484f">${opts.body}</p>
    ${button}
    <hr style="border:none;border-top:1px solid #e2e8ec;margin:32px 0">
    <p style="font-size:12px;color:#8aa">Originance, B2B trade for emerging-market exporters.</p>
  </div>`;
}

export async function sendVerificationEmail(
  to: string,
  rawToken: string,
): Promise<void> {
  const url = `${appUrl()}/verify-email?token=${rawToken}`;
  await sendEmail({
    to,
    subject: "Verify your email · Originance",
    html: layout({
      heading: "Confirm your email address",
      body: "Welcome to Originance. Confirm your email to secure your account. This link expires in 24 hours.",
      ctaLabel: "Verify email",
      ctaUrl: url,
    }),
  });
}

export async function sendPasswordResetEmail(
  to: string,
  rawToken: string,
): Promise<void> {
  const url = `${appUrl()}/reset-password?token=${rawToken}`;
  await sendEmail({
    to,
    subject: "Reset your password · Originance",
    html: layout({
      heading: "Reset your password",
      body: "We received a request to reset your password. This link expires in 1 hour. If you didn't request it, you can ignore this email.",
      ctaLabel: "Reset password",
      ctaUrl: url,
    }),
  });
}

export async function sendEnquiryReceivedEmail(
  to: string,
  opts: { subject: string },
): Promise<void> {
  await sendEmail({
    to,
    subject: "New enquiry · Originance",
    html: layout({
      heading: "You have a new enquiry",
      body: `A buyer sent you an enquiry: "${opts.subject}". Sign in to read and reply.`,
      ctaLabel: "View enquiries",
      ctaUrl: `${appUrl()}/enquiries`,
    }),
  });
}

export async function sendEnquiryRepliedEmail(
  to: string,
  opts: { subject: string },
): Promise<void> {
  await sendEmail({
    to,
    subject: "Reply to your enquiry · Originance",
    html: layout({
      heading: "Your enquiry got a reply",
      body: `The exporter replied to your enquiry: "${opts.subject}". Sign in to read it.`,
      ctaLabel: "View enquiries",
      ctaUrl: `${appUrl()}/enquiries`,
    }),
  });
}

export async function sendDocumentStatusEmail(
  to: string,
  opts: { documentType: string; status: "approved" | "rejected"; reason?: string },
): Promise<void> {
  const approved = opts.status === "approved";
  await sendEmail({
    to,
    subject: `Document ${opts.status} · Originance`,
    html: layout({
      heading: `Your document was ${opts.status}`,
      body: approved
        ? `Your "${opts.documentType}" document was approved. It now counts toward your readiness tier.`
        : `Your "${opts.documentType}" document was rejected${opts.reason ? `: ${opts.reason}` : ""}. You can re-upload a corrected version.`,
      ctaLabel: "View documents",
      ctaUrl: `${appUrl()}/documents`,
    }),
  });
}
