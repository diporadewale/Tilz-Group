import { randomBytes, createHash } from "node:crypto";
import type { Request, Response } from "express";
import { appUrl } from "./app-url";

// ── Google Sign-In (OAuth 2.0 authorization code + PKCE) ─────────────────────
//
// Raw HTTPS, no SDK, same reasoning as lib/email.ts: nothing to bundle into the
// Vercel function, and the flow is small.
//
// On ID token verification: we receive the token *directly* from Google's token
// endpoint over an authenticated TLS connection, which is the trust anchor.
// Google's own guidance is that signature verification is unnecessary in that
// case (it matters when a token arrives via a less trusted channel, e.g. handed
// over by a browser). We still validate the iss/aud/exp/nonce claims below,
// because those are cheap and catch replay and misconfiguration.
//
// Serverless has no shared memory between the redirect and the callback, so the
// PKCE verifier, CSRF state and nonce ride in a short-lived httpOnly cookie.

const AUTHORIZE_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const VALID_ISSUERS = new Set(["https://accounts.google.com", "accounts.google.com"]);

const TRANSACTION_COOKIE = "g_oauth";
const TRANSACTION_TTL_MS = 10 * 60 * 1000;

export function isGoogleAuthConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

/** Where Google sends the browser back. Derived from APP_URL so there is one source of truth. */
export function callbackUrl(): string {
  return `${appUrl()}/api/auth/google/callback`;
}

export interface Transaction {
  state: string;
  verifier: string;
  nonce: string;
  /** Role chosen on the sign-up page, so Google users aren't silently defaulted. */
  role?: "buyer" | "seller";
  /** Where to land after sign-in. */
  redirect?: string;
}

const b64url = (buf: Buffer) => buf.toString("base64url");

export function beginTransaction(
  res: Response,
  opts: { role?: "buyer" | "seller"; redirect?: string },
): string {
  const tx: Transaction = {
    state: b64url(randomBytes(32)),
    verifier: b64url(randomBytes(32)),
    nonce: b64url(randomBytes(16)),
    role: opts.role,
    redirect: opts.redirect,
  };

  res.cookie(TRANSACTION_COOKIE, JSON.stringify(tx), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    // Lax still sends the cookie on the top-level GET navigation Google makes
    // back to the callback, which is exactly what we need. Strict would not.
    sameSite: "lax",
    maxAge: TRANSACTION_TTL_MS,
    path: "/",
  });

  const challenge = b64url(createHash("sha256").update(tx.verifier).digest());

  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!,
    redirect_uri: callbackUrl(),
    response_type: "code",
    scope: "openid email profile",
    state: tx.state,
    nonce: tx.nonce,
    code_challenge: challenge,
    code_challenge_method: "S256",
    // Always show the picker rather than silently reusing a signed-in Google
    // account, people share machines.
    prompt: "select_account",
  });

  return `${AUTHORIZE_URL}?${params.toString()}`;
}

export function readTransaction(req: Request): Transaction | null {
  const raw = (req as Request & { cookies?: Record<string, string> }).cookies?.[TRANSACTION_COOKIE];
  if (!raw) return null;
  try {
    const tx = JSON.parse(raw) as Transaction;
    return tx.state && tx.verifier && tx.nonce ? tx : null;
  } catch {
    return null;
  }
}

export function clearTransaction(res: Response): void {
  res.clearCookie(TRANSACTION_COOKIE, { path: "/" });
}

export interface GoogleProfile {
  sub: string;
  email: string;
  emailVerified: boolean;
  firstName: string | null;
  lastName: string | null;
  avatarUrl: string | null;
}

/** Exchange the authorization code and return the verified profile, or null. */
export async function exchangeCode(code: string, tx: Transaction): Promise<GoogleProfile | null> {
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: process.env.GOOGLE_CLIENT_ID!,
      client_secret: process.env.GOOGLE_CLIENT_SECRET!,
      redirect_uri: callbackUrl(),
      grant_type: "authorization_code",
      code_verifier: tx.verifier,
    }),
  });

  if (!res.ok) return null;

  const payload = (await res.json()) as { id_token?: string };
  if (!payload.id_token) return null;

  const segment = payload.id_token.split(".")[1];
  if (!segment) return null;

  let claims: Record<string, unknown>;
  try {
    claims = JSON.parse(Buffer.from(segment, "base64url").toString("utf8"));
  } catch {
    return null;
  }

  // Claim checks: right issuer, issued to us, unexpired, and matching the nonce
  // we generated for this specific transaction (replay protection).
  const iss = String(claims.iss ?? "");
  const aud = String(claims.aud ?? "");
  const exp = Number(claims.exp ?? 0);
  if (!VALID_ISSUERS.has(iss)) return null;
  if (aud !== process.env.GOOGLE_CLIENT_ID) return null;
  if (!Number.isFinite(exp) || exp * 1000 <= Date.now()) return null;
  if (claims.nonce !== tx.nonce) return null;

  const email = typeof claims.email === "string" ? claims.email.toLowerCase() : "";
  const sub = typeof claims.sub === "string" ? claims.sub : "";
  if (!email || !sub) return null;

  return {
    sub,
    email,
    emailVerified: claims.email_verified === true,
    firstName: typeof claims.given_name === "string" ? claims.given_name : null,
    lastName: typeof claims.family_name === "string" ? claims.family_name : null,
    avatarUrl: typeof claims.picture === "string" ? claims.picture : null,
  };
}
