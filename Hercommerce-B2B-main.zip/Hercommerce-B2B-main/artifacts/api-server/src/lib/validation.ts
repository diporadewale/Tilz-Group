// Zod's `error.message` is the JSON-serialised issue array. Returning it to the
// client leaked internal schema detail, e.g. hitting /api/buyer-profiles/me
// (which matches the `:id` route) responded with
//   [{"code":"invalid_type","expected":"number","received":"nan",
//     "path":["id"],"message":"Expected number, received nan"}]
// This turns the same information into one readable sentence.

interface IssueLike {
  path?: (string | number)[];
  message?: string;
}

interface ErrorLike {
  issues?: IssueLike[];
}

export function validationMessage(error: unknown): string {
  const issues = (error as ErrorLike)?.issues;
  if (!Array.isArray(issues) || issues.length === 0) return "Invalid request.";

  const parts = issues.slice(0, 4).map((issue) => {
    const field = (issue.path ?? []).filter((p) => p !== "").join(".");
    const message = issue.message ?? "is invalid";
    return field ? `${field}: ${message}` : message;
  });

  const more = issues.length > parts.length ? ` (and ${issues.length - parts.length} more)` : "";
  return parts.join("; ") + more;
}
