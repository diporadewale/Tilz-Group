# Originance

B2B marketplace MVP connecting emerging-market exporters (sellers) with global buyers. Covers onboarding, document upload/verification, readiness tiers, buyer-seller matching with match scores, enquiry messaging, and full admin tooling with CSV exports.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev`, run the API server (port 8080, proxied at `/api`)
- `pnpm --filter @workspace/hercommerce run dev`, run the React frontend (proxied at `/`)
- `pnpm run typecheck`, full typecheck across all packages
- `pnpm run build`, typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen`, regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push`, push DB schema changes (dev only)
- `pnpm --filter @workspace/scripts run seed`, wipe and re-seed demo data
- Required env: `DATABASE_URL`, Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React 19 + Vite, Tailwind CSS, shadcn/ui, wouter routing, Clerk auth
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml`, OpenAPI spec (source of truth for all endpoints)
- `lib/api-zod/src/generated/api.ts`, generated Zod schemas (backend validation)
- `lib/api-client-react/src/generated/api.ts`, generated React Query hooks (frontend)
- `lib/db/src/schema/`, Drizzle schema files (users, sellerProfiles, buyerProfiles, documents, readinessTiers, enquiries, auditNotes)
- `artifacts/api-server/src/routes/`, Express route handlers (one file per domain)
- `artifacts/api-server/src/middlewares/`, requireAuth, requireAdmin, clerkProxyMiddleware
- `artifacts/hercommerce/src/pages/`, all React pages
- `artifacts/hercommerce/src/components/`, Layout, ReadinessBadge, shadcn UI

## Architecture decisions

- Contract-first: OpenAPI spec drives both Zod validation on the server and React Query hooks on the client via Orval codegen. Never write raw fetch calls or manual hooks when generated ones exist.
- Clerk proxy: `POST /api/__clerk` proxies Clerk's JS to avoid CORS in production. Server uses `@clerk/express` middleware; frontend uses `@clerk/react` with `proxyUrl`. In dev, proxy env vars are empty, Clerk falls back to direct.
- Readiness tiers computed automatically from verified document count; admin can override with an audit note.
- Matching algorithm: overlap of `categories ↔ interestedCategories` and `country ↔ preferredOrigins`, plus tier bonus, capped at 100.

## Product

- Public landing page with buyer/seller CTAs
- Onboarding wizard: role selection → profile creation
- Seller directory with category/country/tier filters
- Seller detail: docs status, readiness widget, enquiry form
- Buyer matches: ranked list with score + reason chips
- Enquiry inbox + thread view
- Document upload + verification workflow
- Admin dashboard: stats, pending review queue, user/seller tables with tier override and CSV export

## User preferences

_Populate as you build, explicit user instructions worth remembering across sessions._

## Gotchas

- Always run `pnpm run typecheck:libs` after changing any `lib/*` schema/type files before typechecking artifact packages.
- Clerk proxy is server-only; `VITE_CLERK_PROXY_URL` is auto-injected in production by the Replit platform, do not set it manually in dev.
- Export hooks (`useExportSellers`, `useExportUsers`) are React Query query hooks, they cannot be called as functions. Use a direct `fetch` call to `/api/admin/exports/*` for triggered CSV downloads.
- When passing `enabled` to a query hook, always also pass `queryKey`: `{ query: { enabled: !!id, queryKey: getGetFooQueryKey(id) } }`.
- The `scripts` package needs `@workspace/db` as a `dependency` (not devDependency) for `tsx` scripts that import DB directly.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See the `clerk-auth` skill for Clerk proxy and auth wiring details
