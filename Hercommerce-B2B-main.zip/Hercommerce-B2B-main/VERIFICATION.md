# Manual Verification Protocol

Written after the 2026-07-30 end-to-end audit. Everything in that audit was verified by
typecheck, build and code reading, **nothing was verified against a running app**. This
document is the missing half: it exists to be executed by a human against a real deployment.

Run it against a **Vercel preview**: not production, and not `localhost` alone, several
findings (Secure cookies, CORS, serverless timeouts, Blob uploads) only reproduce on Vercel.

**Time:** ~45 minutes. **You need:** a browser with devtools, and the accounts below.

---

## 0. Setup

Create these once, in a fresh incognito window per role:

| Account | Role | Purpose |
|---|---|---|
| `buyer-a@…` | buyer | primary buyer |
| `buyer-b@…` | buyer | **second** buyer, needed for the access-control tests |
| `seller-a@…` | seller | primary exporter |
| `seller-b@…` | seller | **second** exporter, needed for the access-control tests |
| `admin@…` | admin | via the admin bootstrap script |

Complete onboarding for all four non-admin accounts, and note each one's **profile id**
(visible in the URL on its detail page, e.g. `/sellers/7` → id `7`).

> Two accounts per role is not optional. Every one of the six access-control fixes is a
> "user A must not be able to touch user B's data" test, and a single account cannot detect
> any of them.

---

## Part A: Access control (do this first)

These are regression tests for the six broken-access-control bugs. All were exploitable by
any signed-in account. **Every one must fail with 403.**

Open devtools → Console while signed in as **buyer-a**: and run each `fetch`. The session
cookie is sent automatically.

### A1. Cannot edit another company's profile
```js
// seller-a's profile id
await (await fetch('/api/seller-profiles/<SELLER_A_ID>', {
  method:'PATCH', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ companyName: 'HACKED' })
})).status
```
**Expect `403`.** Then reload `/sellers/<SELLER_A_ID>` and confirm the name is unchanged.

### A2. Cannot self-approve verification
Signed in as **seller-a**: against seller-a's *own* profile:
```js
await (await fetch('/api/seller-profiles/<SELLER_A_ID>', {
  method:'PATCH', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ status: 'approved' })
})).status
```
**Expect `200`** (you own it), but then check the profile in the admin UI: **`status` must
still be `pending`**. The write succeeds for the fields you own; `status` must be silently
ignored for non-admins. This is the most important single check in this document.

### A3. Cannot read another buyer's data
As **buyer-a**:
```js
(await (await fetch('/api/buyer-profiles')).json()).length
```
**Expect `1`**: your own profile only. If you see buyer-b, the leak is back.

### A4. Cannot harvest the buyer list via matches
As **buyer-a**: using seller-a's id:
```js
await (await fetch('/api/seller-profiles/<SELLER_A_ID>/matches')).status
```
**Expect `403`.**

### A5. Cannot mutate someone else's enquiry
Have buyer-b send an enquiry to seller-b, note its id. As **buyer-a**:
```js
await (await fetch('/api/enquiries/<THAT_ID>', {
  method:'PATCH', headers:{'Content-Type':'application/json'},
  body: JSON.stringify({ status:'closed', replyMessage:'injected' })
})).status
```
**Expect `403`.**

### A6. Cannot enumerate users
As **buyer-a**: with any id that is not your own:
```js
await (await fetch('/api/users/1')).status
```
**Expect `403`** (unless `1` happens to be you).

### A7. No password hash in responses
As **admin**: open `/admin/sellers`, then devtools → Network. Inspect any
`/api/audit-notes` response body. **`passwordHash` must not appear anywhere.**
Search the whole Network tab for `scrypt:`, expect zero hits.

### A8. GET does not write
As **buyer-a**:
```js
await (await fetch('/api/readiness/999999')).status   // 200, synthesised default
```
Then as **admin**: check `/admin` → tier breakdown. **The bronze count must not have
increased.** Repeat the fetch 5 times and re-check, still unchanged.

---

## Part B: By role

### B1. Anonymous (signed out: incognito)

- [ ] `/` loads; hero search jumps to `/sellers?search=…` and the term is applied
- [ ] `/sellers` and `/sellers/:id` load **without signing in**
- [ ] `/products` loads
- [ ] Seller detail shows a readiness badge, **and devtools Console shows no 401s**
      (the readiness endpoint used to 401 for every anonymous visitor)
- [ ] Contact card says "Sign in as a buyer to send an enquiry" with working buttons
- [ ] `/dashboard` redirects to `/sign-in`
- [ ] `/admin` redirects to `/sign-in`

### B2. Buyer

- [ ] **Before onboarding:** dashboard shows the "Finish setting up your company profile"
      card with a working *Complete profile* button
- [ ] `/profile` before onboarding shows "You don't have a company profile yet", **not an
      editable form**. (The old form saved nothing but reported "Profile updated".)
- [ ] Dashboard stat tiles show **real** numbers, account status, open enquiries, open RFQs.
      None of them are hardcoded. Send an enquiry, reload, confirm the count changes.
- [ ] Send an enquiry → success panel offers *View my enquiries* and *Send another*
- [ ] `/enquiries` lists **newest first**
- [ ] Post an RFQ; open it; **Close RFQ** button appears and works; badge flips to `closed`;
      reopen works
- [ ] Leave a review on an exporter → reload the page → **the form is prefilled** with your
      rating and comment, and the button reads "Update review"
- [ ] Nav shows: Dashboard, Exporters, Products, My Matches, My RFQs, Enquiries
- [ ] `/admin` redirects to `/dashboard` (not a broken admin shell)

### B3. Seller

- [ ] Nav shows Exporters and Products, a seller **can** reach the public directory
- [ ] `/my-products` before onboarding shows a *Complete profile* button, not a bare sentence
- [ ] Add a product with a photo → uploads to Blob → appears in the list
- [ ] **Edit** (pencil) opens a prefilled dialog; save persists; reload confirms
- [ ] **Delete** (trash) asks for confirmation naming the product; Cancel does nothing
- [ ] Upload a document in `/documents`
- [ ] Quote on an RFQ from `/rfq-market`; then **quote again on the same RFQ**: it must
      **revise** the existing quote, not create a second one. Confirm the buyer sees one quote.
- [ ] "Revise quote" button appears on your own quote and prefills it

### B4. Admin

- [ ] Nav includes Enquiries (admin moderation view is now reachable)
- [ ] `/admin` tiles load; **Recent signups** reflects the last 7 days, not a constant 10
- [ ] Export CSV (users **and** sellers), see Part D2 for the injection check
- [ ] `/admin/users`: change a user's status; try to change **your own role** away from
      admin → must be refused
- [ ] `/admin/documents`: approve a document for seller-a

### B5. The readiness chain (the biggest correctness fix)

Do this end-to-end, it exercises the bug where three code paths used two different key
spaces and the badge buyers see was never written.

1. As **seller-a**: upload 2 documents.
2. As **admin**: approve both.
3. As **anyone**: open `/sellers/<SELLER_A_ID>` → **badge must read Silver** (2 approved = silver).
4. As **admin**: **reject** one of them.
5. Reload the seller page → **badge must drop back to Bronze.**
   *Before the fix the tier could only ever go up.*
6. As **admin**: override the tier to Gold in `/admin/sellers`.
7. Reload `/sellers` (the directory list) → **the card badge must read Gold.**
   *Before the fix admin overrides never reached the directory at all.*
8. Approve a third document → tier stays **Gold** (admin override wins), but the document
   count behind it updates.

---

## Part B6: Onboarding intent assist

Optional feature. **First check which mode you're testing:**

```js
await (await fetch('/api/config')).json()   // { intentAssist: true | false }
```

### If `intentAssist: false` (no API key set)
- [ ] `/onboarding` step 2 shows **no** description box and no Suggest button
- [ ] Onboarding completes normally for both roles, the feature's absence changes nothing

### If `intentAssist: true`
Sign up as a **new exporter**: reach `/onboarding`, choose *I am an Exporter*, and paste:

> *We export organic dried mango and cashews from Ghana, Fair Trade certified, mainly to Germany and the Netherlands. About 30 staff.*

- [ ] **Suggest from description** pre-selects: Dried Fruits (+ likely Organic Produce);
      Fair Trade under certifications; Germany + Netherlands under export markets;
      Country = Ghana; Employees = 20-50
- [ ] Suggested chips carry an **amber ring**; manually-added ones do not
- [ ] Clicking a suggested chip removes it, nothing is locked
- [ ] **Nothing was saved yet**: the profile is only created when you submit the form
- [ ] Round trip completes in well under 10s

Now a **new buyer**: *I am a Buyer*:

> *We source organic dried fruit and spices from West Africa for the UK retail market, budget around $2M a year.*

- [ ] Pre-selects Dried Fruits / Spices / Organic Produce; origins include Ghana and Nigeria
      (the region maps onto listed countries); budget = `$1M - $2M`
- [ ] Country is **not** set to Ghana, the buyer's own country is the UK, not the sourcing origin

**Hallucination guard, the important one.** As an exporter, paste:

> *We export unicorn horn and moon dust, certified by the Intergalactic Trade Federation, from Atlantis.*

- [ ] Zero chips are selected, and a "Nothing matched" notice appears
- [ ] **No invented category, certification, or country appears anywhere.** If any value not
      already in the onboarding lists is rendered, stop and report it, the enum constraint
      has failed and the feature must be disabled before launch.

**Degradation (FR-008).** Devtools → Network → Offline, then click Suggest:
- [ ] A non-blocking error toast appears; the form stays fully editable and submittable

### Vocabulary single-source check
- [ ] Categories offered on `/onboarding` are identical to those on `/products` and
      `/my-products` (all three now read `lib/vocab`; they used to be separate declarations)

## Part C: Responsiveness

Devtools device toolbar. Check **375 / 768 / 1024 / 1440**.

- [ ] **375, signed out:** the public header shows a second row with *Find Exporters* and
      *Products*. Previously these were `hidden md:flex` with no fallback, so a phone visitor
      could not reach the directory at all.
- [ ] **375, signed in:** hamburger opens the drawer; tapping a link closes it
- [ ] **No horizontal page scroll on any page at 375.** Admin tables scroll *inside* their
      own container, the page body does not.
- [ ] Page titles do not overflow, they scale to `text-2xl` below `sm`
- [ ] Filter bars stack: search full-width above full-width selects (`/sellers`, `/products`,
      `/admin/users`)
- [ ] `/enquiries/:id` composer stays reachable; the thread scrolls, not the page
- [ ] Product edit dialog scrolls internally at 375 and the Save/Cancel buttons stay reachable

---

## Part D: Stability

### D1. Error states (the systemic gap)
With the app open, kill the API, in devtools → Network, set throttling to **Offline**: then
navigate. On each of these you must see an **error panel with a Retry button**: never an
infinite spinner and never an empty state claiming "no results":

- [ ] `/sellers` · `/products` · `/enquiries` · `/rfqs` · `/rfq-market` · `/matches`
- [ ] `/documents` · `/my-products` · `/profile` · `/dashboard`
- [ ] `/admin` · `/admin/users` · `/admin/sellers` · `/admin/documents`
- [ ] Detail pages: `/sellers/:id` · `/enquiries/:id` · `/rfqs/:id`
- [ ] Go back online, hit **Retry** → content loads without a full page reload

### D2. CSV injection
1. Register a seller whose company name is exactly: `=cmd|'/c calc'!A1`
2. As admin, export the sellers CSV.
3. Open it in Excel or LibreOffice.
- [ ] **No formula executes.** The cell shows the literal text.
- [ ] Also register a company named `Acme, Inc "Ltd"` → confirm columns do **not** shift.

### D3. API error shape
```js
await (await fetch('/api/nonexistent-route')).json()
```
- [ ] Returns **JSON** `{"error":"Not found"}`, not an HTML error page.
- [ ] No stack trace in any error response.

### D4. Serverless / performance
- [ ] `/sellers` responds in well under 10s with the seeded data (Network tab → timing)
- [ ] Notification bell polls `/api/notifications/unread-count` every 30s; the response is a
      small `{"count":N}`, it no longer fetches every row to count them

### D5. Auth
- [ ] Sign out → protected routes redirect; back button does not restore a session
- [ ] Password reset kills existing sessions (reset in one browser, confirm the other is out)
- [ ] Login with a **nonexistent** email and a **wrong password on a real account** take
      visibly similar time (the old early-return leaked which emails exist)

---

## Sign-off

Do not deploy to production until Part A passes in full. A failure there is a live
data-exposure bug, not a polish item.

| Part | Result | Notes |
|---|---|---|
| A, Access control | ☐ pass ☐ fail | |
| B, By role | ☐ pass ☐ fail | |
| C, Responsiveness | ☐ pass ☐ fail | |
| D, Stability | ☐ pass ☐ fail | |

Known limitations at time of writing (see BACKLOG.md):
no automated tests · pagination is a hard `limit(200)` · no rate limiting on auth endpoints ·
reviews are unverified (no transaction required) · Neon password still needs rotating.
