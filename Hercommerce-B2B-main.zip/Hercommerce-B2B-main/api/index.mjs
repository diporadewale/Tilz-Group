// Vercel serverless function for the Express API.
//
// A single function (NOT a [...path] catch-all — Vercel's bracket catch-all
// only matched single-segment paths here, 404ing /api/auth/me etc.). vercel.json
// rewrites every /api/* request to this function, preserving the original URL,
// so the Express router mounted at /api matches at any depth.
//
// Re-exports the pre-bundled Express app from the api-server esbuild output, so
// @vercel/node never recompiles the monorepo TypeScript. buildCommand builds
// dist/vercel.mjs before functions are processed.
export { default } from "../artifacts/api-server/dist/vercel.mjs";
