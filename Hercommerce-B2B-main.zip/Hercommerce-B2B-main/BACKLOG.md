# Originance Product Backlog

Prioritised from the competitive benchmark (Alibaba, Tridge, 2026 B2B baseline). The
trust layer (verification → readiness tiers) is our differentiator and is built; the
gap is **marketplace mechanics** (products → RFQ → negotiation → transaction).

Status: ✅ done · 🚧 in progress · ⬜ todo

---

## ✅ Recently shipped
- ✅ Self-hosted auth (email/password + sessions), email verify + password reset
- ✅ Vercel deploy (SPA + Express serverless), `/api` routing
- ✅ Role-aware onboarding (captures categories/origins → feeds matching)
- ✅ Real document upload (Vercel Blob) + admin verification + readiness tiers
- ✅ Exporter directory, cards, filters; seller detail + contact CTA
- ✅ Seeded demo exporters
- ✅ Mobile navigation drawer + responsive baseline
- ✅ Transactional email (enquiry/document notifications)

---

## NOW: current focus
- ✅ **EPIC-1 Product listings**: products schema/API, seller "My Products" CRUD (with photo upload), products shown on seller detail. *(global product-browse page still optional, see EPIC-1 notes)*

## NEXT: high leverage
- ✅ **EPIC-2 RFQ (Request for Quote)**: buyers post requests ("My RFQs"); exporters browse a category-matched market ("RFQ Market") and quote; buyer sees all quotes, seller sees only their own. *(email-notify matching sellers on new RFQ still ⬜)*
- ✅ **EPIC-3 Threaded messaging**: enquiries are now real conversations (`enquiry_messages`); either party posts, legacy one-shot enquiries auto-render as a thread; chat-style detail with composer. *(unread badges still ⬜)*
- ✅ **EPIC-4 Reviews & ratings**: buyers rate/review exporters (1 per buyer, editable); avg rating + count on cards and detail; review form on the seller page.
- ✅ **EPIC-5 In-app notifications**: `notifications` table + bell with unread badge (30s poll); fired on new enquiry, new message, new quote, and RFQ-matching-sellers. *(reviews-style unread-per-thread still ⬜)*

## SHIPPED: intent assist
- ✅ **EPIC-11 Onboarding intent assist**: free-text business description → controlled-vocabulary
  chip suggestions on `/onboarding`, both roles. LLM does *extraction only*; the existing
  deterministic matcher still does all ranking. Every suggestion is drawn from `lib/vocab`
  via an enum-constrained schema, so an out-of-vocabulary value is structurally impossible.
  Optional feature, no `ANTHROPIC_API_KEY`, no UI.
  - ⬜ *(follow-up)* DB-backed per-user call cap. Deferred: needs a new table + `db push`, and
    the abuse surface is small (auth-gated, one profile per user, 2000-char input cap).
  - ⬜ *(follow-up)* Same parser behind public search and RFQ auto-fill (see EPIC-12/13).

## LATER: scale & commerce
- ⬜ **EPIC-12 Public intent search**: the extractor behind the landing-page search box.
  Blocked on: anonymous users can't act on results (sign-in wall), needs a funnel decision.
- ⬜ **EPIC-13 RFQ auto-fill**: parse the RFQ description to populate category/quantity/unit/
  destination. Highest commercial value of the three: accurate RFQ categories directly improve
  which sellers get notified.
- ⬜ **EPIC-14 LLM ranking**: deliberately *not* built. Revisit only past ~200 exporters, where
  a buyer can no longer skim the directory. At current catalogue size a filter beats a model,
  and generated prose about a supplier would undercut the verification layer.
- ⬜ **EPIC-6 Quotes & MOQ/volume pricing**: formal quote objects, tiered pricing.
- ⬜ **EPIC-7 Payments / escrow (trade assurance)**: the trust→transaction mechanism. Big build; partner/provider decision needed.
- ⬜ **EPIC-8 Logistics**: customs docs, freight-forwarder partners, shipment tracking.
- ⬜ **EPIC-9 Multi-currency & i18n**: emerging-market ↔ global.
- ⬜ **EPIC-10 Seller analytics**: profile/product views, enquiry conversion.

## 🔍 External audit (2026-08-13: 57 findings), status

Audited against the **deployed** site, which predated all of the above. Reconciliation:

**Was already fixed before the audit ran:** B2 (buyer-profile leak), M1 (admin console
open to sellers, plus retry-on-4xx and errors-shown-as-empty), H8 (approval didn't move
the tier), M4/M5 (product delete confirm / edit), B7 (close an RFQ).

**Fixed in response to the report:**
- **H6 + B3**: profile forms never exposed categories / export markets / certifications
  (seller) or sourcing interests / origins (buyer). This single gap is what made **B4**
  ("every buyer sees the same matches") and **B5** ("RFQs into a void") inevitable.
- **B1**: reviews now require a verified email *and* a prior enquiry with that exporter;
  revision returns 200 rather than claiming "created" while silently overwriting.
- **H1, H2, H3, H4, H5, H7, H9, H10** · **M2, M3, M6, M7, M8, M9, M10, M11, M12, M13
  (code splitting), M14, M15, M16, M17** · **B6, B8, B9, B10, B11** · **L2, L3, L5, L6,
  L7, L9, L12, L13, L14**
- **B10 was systemic, not one route**: 47 handlers returned raw Zod payloads. All now go
  through `lib/validation.ts`.

**Still open, needs you:**
- ⬜ **C1 / C2, `BLOB_READ_WRITE_TOKEN` is not set.** Blocks all document and product-photo
  upload. Create a Vercel Blob store, link it, redeploy. The *diagnosis* is fixed (a named
  503 and a real reason in the UI), the cause is environmental.
- ⬜ Test data from the audit session still needs removing, above all the 1-star review on
  Zanzibar Spice Traders, which has no delete UI and must go at the DB level.
- ⬜ "Kobo Expoerter" typo is live data, not in the repo.

**Deliberately not done:**
- ⬜ **M13 SSR/prerender.** Route-level code splitting shipped (entry bundle 645 kB → 470 kB,
  25 chunks, admin console no longer ships to anonymous visitors), but server rendering is an
  architectural change to the Vite SPA + Vercel setup and wants its own sprint.
- ⬜ **B12 / L1** richer dashboards and homepage, product decisions, not defects.
- ⬜ **B13** slow My Matches, the N+1s behind it are fixed; re-measure before optimising further.
- ⬜ **L4** heading structure / skip link · **L8** loading skeletons · **L10** product detail
  pages · **L11** admin queue notifications · **L15** category dropdown scroll containment.

## TECH DEBT / OPS
- ✅ Scalable directory search (filters now run in SQL, enrichment batched, `limit(200)`)
- ✅ Remove dead `@clerk/*` deps (+ the `@clerk/themes` CSS import that would have broken the build)
- ✅ 375px sweep: page titles scale below `sm`, admin filter stacks, public mobile nav added
- ⬜ **Execute `VERIFICATION.md` against a Vercel preview**: the audit was verified by
  typecheck/build/code-reading only; nothing has been run against a live app
- ⬜ 🔒 **Rotate Neon `neondb_owner` password (was shared in plaintext)**: highest-severity open item
- ⬜ Confirm Blob store connected to Vercel project; set `RESEND_API_KEY` + `APP_URL` in prod
- ✅ Indexes on documents/seller_profiles/buyer_profiles/enquiries pushed to the database
- ⬜ Switch `DATABASE_URL` to `sslmode=verify-full` in Vercel + local envs. `pg` currently
  treats `require` as `verify-full`, but pg v9 flips it to libpq semantics, which skip
  certificate verification, the connection would silently get weaker on upgrade.
- ⬜ No automated tests anywhere; manual verification is the only safety net
- ⬜ Pagination is a hard `limit(200)`, not real paging, revisit before the directory passes ~200 exporters
- ⬜ Rate limiting on `/auth/login`, `/auth/register`, `/auth/forgot-password` (needs a
  DB-backed counter; serverless has no shared memory)
- ✅ Reviews gated on a verified email + a prior enquiry (B1)

---

## 🔒 Security audit (2026-07-30): fixed

Full end-to-end audit by role and by feature. Everything below was found **and fixed**.

**Broken access control (all were exploitable by any signed-in account):**
- `PATCH /seller-profiles/:id` and `PATCH /buyer-profiles/:id` had no ownership check:
  any user could rewrite any company's profile. Worse, `status` was an accepted field, so a
  seller could **self-approve their own verification** or reject a competitor out of the
  directory. Now owner-or-admin, with `status` restricted to admins.
- `PATCH /enquiries/:id` had no participant check, any user could mutate any enquiry and
  inject a reply into someone else's conversation.
- `GET /buyer-profiles` returned every buyer's company, sourcing interests and contact email
  to any signed-in user. Now self-only for non-admins.
- `GET /seller-profiles/:id/matches` and `GET /buyer-profiles/:id/matches` were unguarded
  lead lists. Now owner-or-admin.
- `GET /users/:id` let any account walk the id space and harvest every user's email/name.
- `POST /audit-notes` returned the admin's **password hash** in the response body.

**Other:**
- CSV injection in both admin exports, an unescaped `=`/`+`/`-`/`@` prefix in a company name
  became a live formula in the admin's spreadsheet. Fields were also unquoted, so any comma
  shifted every column.
- Login leaked which emails exist via response timing (the early return skipped the hash
  compare that the code comment claimed was there).
- CORS reflected any origin with `credentials: true`; only the cookie's `SameSite=Lax`
  prevented exploitation.
- No error-handling middleware, failures returned HTML (with stack traces outside
  production) to a client that only parses JSON.
- `GET /readiness/:sellerId` **wrote on read**: it inserted a row for any id probed, letting
  any user pollute the table and skew the admin tier breakdown.

## 🐞 Correctness (2026-07-30): fixed

- **The readiness system was wired through two incompatible key spaces.** Document
  verification wrote `readiness_tiers` keyed by `users.id`; every reader (seller detail page,
  admin override, buyer matching) queried it by `seller_profiles.id`. Approving documents
  updated a row nobody read.
- **Readiness only ever went up.** The tier was recalculated on approval but not rejection,
  so revoking a document left the seller's tier untouched.
- **The badge buyers see was never updated.** Directory cards, match results and quote rows
  render `seller_profiles.readinessTier`, which no write path touched, so admin tier
  overrides were invisible too. All three paths now go through `lib/readiness.ts`.
- Dashboard displayed a **hardcoded** "Pending" tier and a hardcoded `0` open enquiries.
- `recentSignups` counted `limit(10)` rows ordered oldest-first, always `min(totalUsers, 10)`.
- Sellers could submit unlimited duplicate quotes on one RFQ; now one per seller, revisable.
- Enquiry inbox was ordered oldest-first.

## 🧭 Usability (2026-07-30): fixed

- **Onboarding was an unrecoverable dead end.** `/onboarding` was linked only from the
  post-signup redirect, so anyone who abandoned it could never return, and every action
  then failed with an unexplained error. Now prompted on the dashboard and from each
  "no profile" state.
- **Buyers could never close an RFQ**: no endpoint existed, so the "closed" UI branch was
  unreachable and RFQs sat in the seller market forever. Added `PATCH /rfqs/{id}`.
- **Product editing was dead server code**: `PATCH /products/{id}` was fully implemented
  with ownership guards but nothing called it. Wired up an edit dialog.
- Deleting a product happened on one unconfirmed click.
- On mobile, signed-out visitors **could not reach the directory or catalogue at all**: the
  public nav was `hidden md:flex` with no fallback.
- Sellers were locked out of `/sellers` and `/products`, so they couldn't see their own
  public listing. Admins had no route to the enquiry moderation view the API already allowed.
- Admin pages were reachable by any signed-in user (the API refused them, but the UI
  rendered a broken shell). Added `RequireRole`.
- The review form never prefilled an existing review, so "editing" silently blanked it.
- The email-verification banner reappeared on every navigation.

## 🛡 Stability (2026-07-30): fixed

- **No error boundary and no error handling on 20 of 26 pages.** A failed request rendered
  an empty state saying "no results", or an infinite spinner. Added an `ErrorBoundary` plus
  `QueryState`/`ErrorState` and wired real error branches through every data page.
- React Query retried 4xx three times with backoff before showing anything.
- **`pnpm run build` could not run on Windows at all**: `pnpm-workspace.yaml` excluded every
  Windows native binary, so the mandatory pre-deploy build was impossible locally.
- Unbounded queries and N+1s removed across seller profiles (was 1+2N, unbounded), enquiries
  (1+4N), documents, buyer/seller matches, admin queues, RFQ quote lists, and the
  notification unread count (polled every 30s per user, fetched every row to call `.length`).

---

## EPIC-1 Product listings: sprint deliverables
1. ✅ **Schema + contract**: `products` table; OpenAPI CRUD; codegen; pushed.
2. ✅ **Server handlers**: products CRUD with seller-ownership guards.
3. ✅ **Seller product management UI**: "My Products" list + add + delete + photo upload (Blob).
4. ✅ **Buyer-facing display**: products section on the seller detail page.
- ✅ global product-browse/search page (`/products`, public, search + category)
- ⬜ *(follow-ups)* inline product edit.
