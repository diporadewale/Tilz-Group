---
name: Scripts package needs db as runtime dep
description: @workspace/db must be in dependencies (not devDependencies) for tsx scripts that import it directly
---

The `scripts` package (leaf package, not a lib) runs tsx scripts that import `@workspace/db`. tsx resolves workspace packages at runtime.

**Why:** If @workspace/db is absent from scripts/package.json, Node.js throws ERR_MODULE_NOT_FOUND at runtime because the workspace symlink doesn't exist.

**How to apply:** In scripts/package.json, add `"dependencies": { "@workspace/db": "workspace:*" }`.
