---
name: Clerk proxy in dev vs prod
description: VITE_CLERK_PROXY_URL is auto-injected by Replit in production; never manually set it in dev
---

The Clerk skill says: "The server-side proxy code is production only and is not used in development. Do not ask for or set any env vars related to the proxy."

**Why:** In dev, Clerk falls back to direct API calls. The proxy is only needed in production to avoid CORS on custom domains. Replit's platform injects VITE_CLERK_PROXY_URL automatically at build/deploy time.

**How to apply:** Never set VITE_CLERK_PROXY_URL in .env or environment secrets. Leave it empty in dev — ClerkProvider gracefully no-ops when proxyUrl is undefined.
