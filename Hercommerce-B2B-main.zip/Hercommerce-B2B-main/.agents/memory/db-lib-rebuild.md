---
name: DB lib rebuild before artifact typecheck
description: After adding schema files to lib/db, must run typecheck:libs before artifact typechecks will see the new exports
---

When new schema files are added to `lib/db/src/schema/`, the lib declaration output is stale until rebuilt.

**Why:** Artifacts depend on emitted .d.ts files from the composite lib packages, not source.

**How to apply:** Always run `pnpm run typecheck:libs` after any change to `lib/*` before running `pnpm --filter @workspace/<artifact> run typecheck`.
