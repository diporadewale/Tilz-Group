---
name: Query hook enabled option
description: Orval-generated hooks require queryKey alongside enabled in the query options object
---

When passing `enabled` to an Orval-generated React Query hook, you MUST also pass `queryKey`. Without it TypeScript errors with "Property 'queryKey' is missing".

**Why:** The generated hook signatures require queryKey as part of the options type when enabled is set.

**How to apply:** Always write:
```ts
useGetFoo(id, { query: { enabled: !!id, queryKey: getGetFooQueryKey(id) } })
```
Never write:
```ts
useGetFoo(id, { query: { enabled: !!id } }) // TS error
```
