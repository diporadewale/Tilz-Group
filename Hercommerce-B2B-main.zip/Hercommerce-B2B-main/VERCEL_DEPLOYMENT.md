# Deploying Originance B2B to Vercel

**Strategy chosen:** keep the current architecture (React + Vite SPA + Express 5 API) and adapt it to Vercel, frontend served as static assets from Vercel's CDN, the Express app wrapped as a single serverless function under `/api/*`. No Next.js migration.

This is a plan, not applied changes. Items marked **[BLOCKER]** must be done or the build/runtime fails on Vercel. Items marked **[CORRECTNESS]** will appear to work in a preview but break under real load.

---

## How the pieces map onto Vercel

| Today (Replit) | On Vercel |
|---|---|
| Express `app.listen(PORT)` long-running server | Express app exported as a **serverless function** (no `listen`) |
| Vite dev/preview server on `PORT` | Static build output served by Vercel CDN |
| `BASE_PATH` from Replit env | `/` (served at domain root) |
| `VITE_CLERK_PROXY_URL` auto-injected by Replit | **Set manually** to `https://<your-domain>/api/__clerk` |
| Single Postgres pool, long-lived | **Pooled connection string, `max: 1`** per function instance |

The good news: [app.ts](artifacts/api-server/src/app.ts) already exports the fully-configured Express app and only [index.ts](artifacts/api-server/src/index.ts) calls `listen()`. An Express app is itself a `(req, res)` handler, so wrapping it is a few lines.

---

## Step 0: [BLOCKER] Fix the TypeScript build (`esModuleInterop`)

**Why:** `tsconfig.base.json` used `moduleResolution: "bundler"` with no `esModuleInterop`, so default-importing CJS packages (`pino-http`, `cors`, `cookie-parser`) was only callable by luck of the resolved `@types` versions. On Vercel the catalog pulled `@types/node 25.6.2`, which broke it:
```
src/app.ts(17,3): error TS2349: This expression is not callable.  // pinoHttp(...)
```
**Fix (applied):** added `"esModuleInterop": true` to `tsconfig.base.json`. This makes CJS default imports resolve correctly everywhere and hardens the other CJS imports against future type-version drift.

---

## Step 1: [CORRECTNESS] Fix database connection pooling

**Why:** Each serverless invocation can spin up a new function instance, and [lib/db/src/index.ts](lib/db/src/index.ts) currently does `new Pool({ connectionString })` with no limit. Under load this opens hundreds of Postgres connections and exhausts the server. This is the single most important change.

**Do both:**

1. **Use a pooled `DATABASE_URL`.** Point it at a connection pooler, not the direct Postgres port:
   - Neon: use the **pooled** connection string (host contains `-pooler`).
   - Supabase: use the **Transaction pooler** on port `6543` (not 5432).
   - Self-hosted: front Postgres with PgBouncer (transaction mode).

2. **Cap the per-instance pool** in `lib/db/src/index.ts`:
   ```ts
   export const pool = new Pool({
     connectionString: process.env.DATABASE_URL,
     max: 1,                       // one connection per serverless instance
     idleTimeoutMillis: 10_000,
   });
   ```

> Alternative (cleaner long-term): switch `@workspace/db` to the Neon serverless driver (`drizzle-orm/neon-serverless` + `@neondatabase/serverless`), which uses HTTP/WebSocket and needs no pool. Bigger change, defer to a dedicated deliverable if you go this route.

---

## Step 2: [BLOCKER] Make the Vite build survive without `PORT`/`BASE_PATH`

**Why:** [vite.config.ts](artifacts/hercommerce/vite.config.ts) throws at config-load if `PORT` or `BASE_PATH` is unset. During `vite build` on Vercel there is no `PORT`, so the build aborts.

**Fix:** only require those vars for the dev/preview *server*, and default `base` to `/`:
```ts
const basePath = process.env.BASE_PATH ?? "/";
// PORT is only needed for the dev/preview server, not for `vite build`.
const port = process.env.PORT ? Number(process.env.PORT) : undefined;
// ...guard the NaN/<=0 checks behind `if (process.env.PORT)`,
// and only set server.port/preview.port when `port` is defined.
```
Keep `base: basePath`. On Vercel `BASE_PATH` is unset → base is `/`, which is what we want at the domain root. (`App.tsx` already derives its router base from `import.meta.env.BASE_URL`, so it follows automatically.)

Also drop the Replit-only plugins from the production build, they're already gated behind `REPL_ID`, so no change needed, but confirm `@replit/*` plugins never load when `REPL_ID` is absent.

---

## Step 3: [BLOCKER] Wrap the Express app as a serverless function

Create a catch-all function at the **repo root** so Vercel auto-detects it:

```
api/
  [...path].ts
```
```ts
// api/[...path].ts
import app from "../artifacts/api-server/src/app";
export default app;            // Express app is a valid (req, res) handler
```

Notes:
- A catch-all (`[...path].ts`) receives every `/api/*` request with the **original URL preserved** in `req.url` (e.g. `/api/sellers`). The Express app mounts its router at `/api`, so paths line up with no rewrites needed.
- `@vercel/node` compiles the imported TypeScript and follows the pnpm workspace symlinks, bundling `@workspace/db`, `@workspace/api-zod`, `express`, `@clerk/express`, `drizzle-orm`, `pg`, etc. Verify the first deploy actually bundles `pg` and the Clerk packages.
- The Clerk proxy middleware (`/api/__clerk`) flows through this same function. It's production-gated already and works inside a Node serverless function via `http-proxy-middleware`. Expect a small cold-start cost; acceptable for MVP.

---

## Step 4: `vercel.json` (project root)

```jsonc
{
  "buildCommand": "pnpm run typecheck && pnpm --filter @workspace/hercommerce run build",
  "outputDirectory": "artifacts/hercommerce/dist/public",
  "installCommand": "pnpm install --frozen-lockfile",
  "framework": null,
  "functions": {
    "api/[...path].ts": { "maxDuration": 30 }   // Pro plan; Hobby caps at 10s
  },
  "rewrites": [
    { "source": "/api/(.*)", "destination": "/api/$1" },          // API → function (explicit; catch-all already matches)
    { "source": "/((?!api/).*)", "destination": "/index.html" }   // SPA fallback for client-side routes
  ]
}
```
- `framework: null` because Vercel won't auto-detect a framework at the monorepo root.
- The SPA fallback sends every non-API path to `index.html` so `wouter` can handle routing (`/sellers`, `/admin`, deep links, refreshes).
- Confirm the Vite build still emits to `artifacts/hercommerce/dist/public` (it does today) and that `outputDirectory` matches.

---

## Step 5: Environment variables (Vercel dashboard → Settings → Environment Variables)

**Server-side (secrets, Production & Preview):**
| Var | Value |
|---|---|
| `DATABASE_URL` | **pooled** Postgres connection string (Step 1) |
| `CLERK_SECRET_KEY` | from Clerk dashboard |
| `CLERK_PUBLISHABLE_KEY` | from Clerk dashboard (server reads this in `app.ts`) |

`NODE_ENV=production` is set by Vercel automatically, this is what activates the Clerk proxy middleware.

**Build-time / client (must be `VITE_` prefixed, these are baked into the bundle):**
| Var | Value |
|---|---|
| `VITE_CLERK_PUBLISHABLE_KEY` | Clerk publishable key |
| `VITE_CLERK_PROXY_URL` | `https://<your-domain>/api/__clerk`, **set manually** (Replit injected this for you) |

> Reminder: anything in a `VITE_*` var is shipped to the browser. Never put a secret there. `CLERK_SECRET_KEY` must **not** have a `VITE_` twin.

---

## Step 6: Database migrations

`pnpm --filter @workspace/db run push` is dev-only (it does a schema push, not versioned migrations). For production:
- Generate SQL migrations with `drizzle-kit generate` and apply them as a deliberate step (locally against the prod DB, or a one-off job), **not** during the Vercel build. The build environment shouldn't mutate the production schema.
- Seed data (`@workspace/scripts run seed`) **wipes** data, never run it against production.

---

## Step 7: Verify on a preview deploy (before production)

1. Push a branch / open a PR → Vercel builds a **Preview**.
2. Open the preview URL in incognito. App loads, no console errors.
3. Hit `/api/health` → expect a healthy response (confirms the function + DB env are wired).
4. Sign in via Clerk → confirms `VITE_CLERK_PROXY_URL` + proxy middleware + publishable key all agree.
5. Exercise a data path (load `/sellers`) → confirms DB connectivity through the pooler.
6. Deep-link directly to `/admin/users` and refresh → confirms the SPA fallback rewrite.
7. Trigger a CSV export → confirms the direct-`fetch` download path works same-origin.
8. Check the Vercel function logs (pino JSON) for the request.

---

## Known Vercel constraints that affect this app

1. **Request body limit ~4.5 MB** on the serverless function. Document uploads above that must go direct-to-storage (Vercel Blob / S3 presigned URL), not through `express.json()`. Check the documents flow.
2. **Function timeout**: 10s (Hobby) / up to 60s (Pro). Keep the Clerk proxy and any export queries within budget.
3. **No in-memory state between requests**: anything cached in a module-level variable may or may not survive. Don't rely on it for correctness.
4. **Cold starts**: first request after idle is slower; the Express + Clerk + Drizzle bundle adds to this. Acceptable for MVP; revisit if latency matters.
5. **CORS** becomes unnecessary once frontend and API share the Vercel domain (`cors({ origin: true, credentials: true })` is harmless but can be tightened to same-origin later).
6. **pino-pretty** is dev-only; production logs as JSON to stdout, which Vercel captures, good, leave it.

---

## Summary checklist
- [x] [BLOCKER] `esModuleInterop: true` in `tsconfig.base.json` (fixes the `pinoHttp` typecheck error)
- [x] **Vercel Project Root Directory set to `./`** (was building `artifacts/api-server`, the API only, no frontend)
- [ ] [CORRECTNESS] Pooled `DATABASE_URL` + `max: 1` in `lib/db/src/index.ts`
- [ ] [BLOCKER] `vite.config.ts` no longer throws without `PORT`/`BASE_PATH`; `base` defaults to `/`
- [ ] [BLOCKER] `api/[...path].ts` exports the Express app
- [ ] `vercel.json` with build command, output dir, API + SPA rewrites
- [ ] All env vars set (server secrets + `VITE_*` build vars), `VITE_CLERK_PROXY_URL` pointed at the deployed domain
- [ ] Production migration strategy decided (not `db push`, not during build)
- [ ] Verified on a Preview deploy before promoting to Production
