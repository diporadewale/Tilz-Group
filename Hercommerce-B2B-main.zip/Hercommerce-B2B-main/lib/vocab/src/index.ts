// ── Shared controlled vocabularies ───────────────────────────────────────────
//
// The single source of truth for every closed list the product matches on.
// Previously `CATEGORIES` was declared twice, in the SPA's `lib/catalog.ts` and
// again inline in `Onboarding.tsx`, with nothing keeping them in step, and
// neither reachable from the API server.
//
// Three consumers depend on these being one list:
//   1. the onboarding chip pickers and product/directory filters (SPA),
//   2. the seller/buyer matching algorithm, which scores on category and origin
//      overlap, a term that exists on one side but not the other silently
//      never matches,
//   3. the intent-extraction schema, which turns each list into a JSON-Schema
//      `enum` so the model physically cannot return a value the app doesn't
//      know (see api-server `lib/intent.ts`).
//
// Adding a term here is the whole change (NFR-005). Renaming or removing one is
// NOT, existing rows store these as plain strings, so a rename needs a data
// migration or it will orphan every profile that referenced the old value.

export const CATEGORIES = [
  "Organic Produce", "Dried Fruits", "Fresh Fruit", "Spices", "Grains",
  "Health Foods", "Cocoa", "Coffee", "Beverages", "Wine", "Confectionery",
  "Botanicals", "Textiles", "Cotton", "Apparel", "Floriculture", "Horticulture",
] as const;

export const COUNTRIES = [
  "Germany", "Netherlands", "United Kingdom", "France", "Italy", "Belgium",
  "Switzerland", "United States", "Canada", "Japan", "China", "South Korea",
  "India", "United Arab Emirates", "Australia", "Turkey", "South Africa",
  "Nigeria", "Ghana", "Kenya", "Ethiopia", "Tanzania", "Morocco", "Egypt",
] as const;

// Every country a company can be based in or trade with. COUNTRIES above is a
// curated shortlist of the markets most of our trade runs through, used as the
// quick-pick chips; this is the full set a dropdown searches and the server
// validates against.
//
// Why a separate list rather than growing COUNTRIES: a company's own country
// was free text, and constraining it to 24 trade markets would have locked out
// exporters in Uganda, Rwanda, Côte d'Ivoire, Senegal, Vietnam and most of the
// emerging markets this platform exists for. Free text had its own failure,
// though: a buyer typed "Thaiti", which is not a country and can never match
// an origin filter, because matching compares country strings exactly.
//
// UN member and observer states, plus territories that trade under their own
// customs regime. The 24 names in COUNTRIES appear here verbatim, so existing
// rows stay valid without a migration; that is also why "Turkey" is kept
// rather than ISO's "Türkiye". Renaming any entry needs a data migration.
export const ALL_COUNTRIES = [
  "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda",
  "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain",
  "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia",
  "Bosnia and Herzegovina", "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso",
  "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Central African Republic",
  "Chad", "Chile", "China", "Colombia", "Comoros", "Costa Rica", "Côte d'Ivoire",
  "Croatia", "Cuba", "Cyprus", "Czechia", "Democratic Republic of the Congo", "Denmark",
  "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador",
  "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland",
  "France", "French Polynesia", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece",
  "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras",
  "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland",
  "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati",
  "Kosovo", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia",
  "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau", "Madagascar", "Malawi",
  "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius",
  "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco",
  "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Caledonia",
  "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "North Macedonia",
  "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama", "Papua New Guinea",
  "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Puerto Rico", "Qatar",
  "Republic of the Congo", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis",
  "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino",
  "São Tomé and Príncipe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles",
  "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia",
  "South Africa", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname",
  "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand",
  "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey",
  "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom",
  "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela",
  "Vietnam", "Yemen", "Zambia", "Zimbabwe",
] as const;

export const CERTIFICATIONS = [
  "USDA Organic", "EU Organic", "Fair Trade", "Rainforest Alliance",
  "GlobalGAP", "ISO 22000", "ISO 9001", "HACCP", "BRCGS", "OEKO-TEX", "BCI", "WIETA",
] as const;

export const REVENUE_BANDS = [
  "Under $1M", "$1M - $2M", "$2M - $5M", "$5M - $10M", "$10M+",
] as const;

export const EMPLOYEE_BANDS = [
  "1-10", "10-20", "20-50", "50-100", "100-250", "250-500", "500+",
] as const;

export const BUDGET_BANDS = [
  "Under $1M", "$1M - $2M", "$2M - $5M", "$5M+",
] as const;

// Previously declared only in the SPA's lib/catalog.ts, so the API could not
// validate a product's currency or unit, and an RFQ had no currency at all:
// a seller reading "Target: 4 per kg" could not tell dollars from pounds.
export const CURRENCIES = ["USD", "EUR", "GBP", "CNY", "JPY"] as const;

export const UNITS = ["kg", "tonne", "lb", "unit", "case", "pallet", "litre", "container"] as const;

// Incoterms 2020. Who pays freight and insurance, and where risk passes, is
// most of the difference between two quotes at the same unit price, so a
// comparable quote has to name one. Free text ("FOB Lagos") could not be
// compared or filtered; the named place stays free text on the quote.
export const INCOTERMS = [
  "EXW", "FCA", "CPT", "CIP", "DAP", "DPU", "DDP", "FAS", "FOB", "CFR", "CIF",
] as const;

export type Category = (typeof CATEGORIES)[number];
export type Currency = (typeof CURRENCIES)[number];
export type Unit = (typeof UNITS)[number];
export type Incoterm = (typeof INCOTERMS)[number];
export type Country = (typeof COUNTRIES)[number];
export type AnyCountry = (typeof ALL_COUNTRIES)[number];
export type Certification = (typeof CERTIFICATIONS)[number];
export type RevenueBand = (typeof REVENUE_BANDS)[number];
export type EmployeeBand = (typeof EMPLOYEE_BANDS)[number];
export type BudgetBand = (typeof BUDGET_BANDS)[number];

/** Narrow an untrusted string to a member of one of the lists above. */
export function isMemberOf<T extends readonly string[]>(
  list: T,
  value: string,
): value is T[number] {
  return (list as readonly string[]).includes(value);
}

/** Keep only the values that belong to `list`, preserving order and de-duplicating. */
export function keepKnown<T extends readonly string[]>(
  list: T,
  values: readonly string[] | null | undefined,
): T[number][] {
  if (!values) return [];
  const seen = new Set<string>();
  const kept: T[number][] = [];
  for (const value of values) {
    if (isMemberOf(list, value) && !seen.has(value)) {
      seen.add(value);
      kept.push(value);
    }
  }
  return kept;
}
