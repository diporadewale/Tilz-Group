import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import { defineConfig } from "drizzle-kit";

// drizzle-kit does not load .env itself, and this config runs with lib/db as the
// working directory, so a repo-root .env would otherwise be invisible. Load it
// explicitly (Node's built-in loader, no dotenv dependency) while still letting
// a real environment variable win, which is what CI and Vercel provide.
const rootEnv = resolve(dirname(fileURLToPath(import.meta.url)), "../../.env");
if (!process.env.DATABASE_URL && existsSync(rootEnv)) {
  process.loadEnvFile(rootEnv);
}

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set.\n" +
      "  • Copy .env.example to .env at the repo root and fill in DATABASE_URL, or\n" +
      "  • export it for this command: DATABASE_URL='postgres://…' pnpm --filter @workspace/db run push\n" +
      "Use the POOLED connection string (Neon: the '-pooler' host).",
  );
}

export default defineConfig({
  // Relative (forward-slash) path resolved from this package dir. Avoids the
  // backslash globs that path.join(__dirname, …) produces on Windows, which
  // drizzle-kit fails to match ("No schema files found").
  schema: "./src/schema/index.ts",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL,
  },
});
