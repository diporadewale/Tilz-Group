import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// On Vercel each serverless instance gets its own pool, so cap it at a single
// connection to avoid exhausting Postgres. Use a pooled DATABASE_URL (PgBouncer
// / Neon-pooler / Supabase transaction pooler) in that environment. Long-running
// hosts (local, Replit) keep the normal default.
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: process.env.VERCEL ? 1 : 10,
  idleTimeoutMillis: 10_000,
});
export const db = drizzle(pool, { schema });

export * from "./schema";
