import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const auditNotesTable = pgTable("audit_notes", {
  id: serial("id").primaryKey(),
  adminId: integer("admin_id").notNull(),
  // Plain text with a TypeScript-level constraint, not a Postgres enum, so
  // widening this needs no migration. `buyer` was added when profile
  // rejections started recording their reason here.
  entityType: text("entity_type", { enum: ["user", "seller", "buyer", "document", "readiness"] }).notNull(),
  entityId: integer("entity_id").notNull(),
  note: text("note").notNull(),
  action: text("action"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAuditNoteSchema = createInsertSchema(auditNotesTable).omit({ id: true, createdAt: true });
export type InsertAuditNote = z.infer<typeof insertAuditNoteSchema>;
export type AuditNote = typeof auditNotesTable.$inferSelect;
