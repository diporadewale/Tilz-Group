import { pgTable, text, serial, timestamp, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const buyerProfilesTable = pgTable(
  "buyer_profiles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    companyName: text("company_name").notNull(),
    description: text("description"),
    country: text("country").notNull(),
    city: text("city"),
    website: text("website"),
    interestedCategories: text("interested_categories").array().notNull().default([]),
    preferredOrigins: text("preferred_origins").array().notNull().default([]),
    annualBudget: text("annual_budget"),
    status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  // Looked up by owner on every authenticated request; the admin queue and the
  // seller-side match query filter on status.
  (t) => [
    index("buyer_profiles_user_id_idx").on(t.userId),
    index("buyer_profiles_status_idx").on(t.status),
  ],
);

export const insertBuyerProfileSchema = createInsertSchema(buyerProfilesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertBuyerProfile = z.infer<typeof insertBuyerProfileSchema>;
export type BuyerProfile = typeof buyerProfilesTable.$inferSelect;
