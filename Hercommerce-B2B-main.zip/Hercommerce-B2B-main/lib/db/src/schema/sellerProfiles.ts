import { pgTable, text, serial, timestamp, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sellerProfilesTable = pgTable(
  "seller_profiles",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    companyName: text("company_name").notNull(),
    description: text("description"),
    country: text("country").notNull(),
    city: text("city"),
    website: text("website"),
    categories: text("categories").array().notNull().default([]),
    annualRevenue: text("annual_revenue"),
    employeeCount: text("employee_count"),
    exportMarkets: text("export_markets").array().notNull().default([]),
    certifications: text("certifications").array().notNull().default([]),
    logoUrl: text("logo_url"),
    status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
    // Denormalised copy of readiness_tiers.tier. This is the column the
    // directory, matches and quote rows render. Kept in sync by the readiness
    // helper in the API server; never write it directly.
    readinessTier: text("readiness_tier", { enum: ["bronze", "silver", "gold", "platinum"] }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  // The directory filters on country/status/tier and searches company_name;
  // profile lookups by owner happen on every authenticated request.
  (t) => [
    index("seller_profiles_user_id_idx").on(t.userId),
    index("seller_profiles_status_idx").on(t.status),
    index("seller_profiles_country_idx").on(t.country),
    index("seller_profiles_readiness_tier_idx").on(t.readinessTier),
    // GIN so the `categories @> ARRAY[...]` containment filter can use an index.
    index("seller_profiles_categories_idx").using("gin", t.categories),
  ],
);

export const insertSellerProfileSchema = createInsertSchema(sellerProfilesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSellerProfile = z.infer<typeof insertSellerProfileSchema>;
export type SellerProfile = typeof sellerProfilesTable.$inferSelect;
