import {
  pgTable,
  text,
  integer,
  timestamp,
  index,
} from "drizzle-orm/pg-core";

// DB-backed sessions. The primary key is an opaque random token that is also
// the value of the httpOnly session cookie. Server-side rows make logout and
// "sign out everywhere" real (delete the row) and survive Vercel's stateless
// serverless model.
export const sessionsTable = pgTable(
  "sessions",
  {
    id: text("id").primaryKey(),
    userId: integer("user_id").notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [index("sessions_user_id_idx").on(t.userId)],
);

export type Session = typeof sessionsTable.$inferSelect;
