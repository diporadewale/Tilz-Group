import { pgTable, text, serial, timestamp, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const documentsTable = pgTable(
  "documents",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    documentType: text("document_type", {
      enum: ["business_registration", "tax_certificate", "export_license", "product_catalog", "quality_certificate", "other"],
    }).notNull(),
    fileName: text("file_name").notNull(),
    fileUrl: text("file_url").notNull(),
  // Verification documents are uploaded to a private blob store and can only be
  // read through GET /documents/:id/file, which checks ownership. Rows created
  // before that change point at public blobs and stay readable by URL, so the
  // download route has to know which kind it is holding. Defaults to "public"
  // so existing rows describe themselves honestly rather than claiming a
  // privacy they never had.
  storageAccess: text("storage_access", { enum: ["public", "private"] })
    .notNull()
    .default("public"),
    notes: text("notes"),
    status: text("status", { enum: ["pending", "approved", "rejected"] }).notNull().default("pending"),
    rejectionReason: text("rejection_reason"),
    verifiedAt: timestamp("verified_at", { withTimezone: true }),
    verifiedBy: integer("verified_by"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  // Every document read is scoped by owner; the admin queue filters on status.
  (t) => [
    index("documents_user_id_idx").on(t.userId),
    index("documents_status_idx").on(t.status),
  ],
);

export const insertDocumentSchema = createInsertSchema(documentsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documentsTable.$inferSelect;
