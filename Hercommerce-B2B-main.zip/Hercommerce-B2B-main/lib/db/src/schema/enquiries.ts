import { pgTable, text, serial, timestamp, integer, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// Thread header. `message`/`replyMessage` are retained for the first exchange of
// pre-threading enquiries; new conversation turns live in enquiryMessagesTable.
export const enquiriesTable = pgTable(
  "enquiries",
  {
    id: serial("id").primaryKey(),
    buyerId: integer("buyer_id").notNull(),
    sellerId: integer("seller_id").notNull(),
    subject: text("subject").notNull(),
    message: text("message").notNull(),
    replyMessage: text("reply_message"),
    status: text("status", { enum: ["open", "replied", "closed"] }).notNull().default("open"),
    repliedAt: timestamp("replied_at", { withTimezone: true }),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  },
  // The inbox is scoped to the caller's buyer or seller profile and filtered by
  // status.
  (t) => [
    index("enquiries_buyer_id_idx").on(t.buyerId),
    index("enquiries_seller_id_idx").on(t.sellerId),
    index("enquiries_status_idx").on(t.status),
  ],
);

// One turn in an enquiry conversation. `senderId` -> users.id.
export const enquiryMessagesTable = pgTable(
  "enquiry_messages",
  {
    id: serial("id").primaryKey(),
    enquiryId: integer("enquiry_id").notNull(),
    senderId: integer("sender_id").notNull(),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("enquiry_messages_enquiry_id_idx").on(t.enquiryId)],
);

export const insertEnquirySchema = createInsertSchema(enquiriesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertEnquiry = z.infer<typeof insertEnquirySchema>;
export type Enquiry = typeof enquiriesTable.$inferSelect;
export type EnquiryMessage = typeof enquiryMessagesTable.$inferSelect;
