import {
  pgTable,
  text,
  serial,
  integer,
  timestamp,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// A buyer's sourcing request. `buyerId` -> buyerProfiles.id. `category` drives
// which exporters see it in their RFQ market.
export const rfqsTable = pgTable(
  "rfqs",
  {
    id: serial("id").primaryKey(),
    buyerId: integer("buyer_id").notNull(),
    title: text("title").notNull(),
    category: text("category"),
    description: text("description").notNull(),
    quantity: text("quantity"),
    unit: text("unit"),
    targetPrice: text("target_price"),
    // Null only when there is no target price; the API requires it otherwise.
    targetCurrency: text("target_currency"),
    destinationCountry: text("destination_country"),
    status: text("status", { enum: ["open", "closed"] }).notNull().default("open"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("rfqs_buyer_id_idx").on(t.buyerId),
    index("rfqs_category_idx").on(t.category),
    index("rfqs_status_idx").on(t.status),
  ],
);

// An exporter's quote in response to an RFQ. `sellerId` -> sellerProfiles.id.
export const rfqQuotesTable = pgTable(
  "rfq_quotes",
  {
    id: serial("id").primaryKey(),
    rfqId: integer("rfq_id").notNull(),
    sellerId: integer("seller_id").notNull(),
    // Legacy free text ("$4.10/kg FOB Lagos") from before quotes were
    // structured. Nullable now: new quotes use the columns below and leave this
    // empty. Old rows keep displaying exactly what the seller wrote, because a
    // string like that cannot be parsed back into its parts without guessing.
    price: text("price"),
    // A plain number as text, matching products.price_min/price_max, validated
    // by lib/numeric on the way in. Currency, unit and Incoterm are what make
    // two quotes comparable; the named place stays free text.
    unitPrice: text("unit_price"),
    currency: text("currency"),
    unit: text("unit"),
    incoterm: text("incoterm"),
    incotermPlace: text("incoterm_place"),
    leadTime: text("lead_time"),
    message: text("message"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("rfq_quotes_rfq_id_idx").on(t.rfqId),
    index("rfq_quotes_seller_id_idx").on(t.sellerId),
  ],
);

export const insertRfqSchema = createInsertSchema(rfqsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertRfq = z.infer<typeof insertRfqSchema>;
export type Rfq = typeof rfqsTable.$inferSelect;
export type RfqQuote = typeof rfqQuotesTable.$inferSelect;
