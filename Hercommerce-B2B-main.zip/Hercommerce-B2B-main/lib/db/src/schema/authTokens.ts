import {
  pgTable,
  text,
  serial,
  timestamp,
  integer,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// Single-use, expiring tokens for email verification and password reset. Only
// the sha256 hash of the token is stored, so a DB leak can't be used to verify
// or reset accounts. The raw token lives only in the emailed link.
export const authTokensTable = pgTable(
  "auth_tokens",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    tokenHash: text("token_hash").notNull(),
    type: text("type", { enum: ["email_verify", "password_reset"] }).notNull(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    usedAt: timestamp("used_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    uniqueIndex("auth_tokens_token_hash_idx").on(t.tokenHash),
    index("auth_tokens_user_id_idx").on(t.userId),
  ],
);

export type AuthToken = typeof authTokensTable.$inferSelect;
