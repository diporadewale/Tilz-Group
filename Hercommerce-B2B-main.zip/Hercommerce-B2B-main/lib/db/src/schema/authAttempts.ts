import { pgTable, text, serial, timestamp, index } from "drizzle-orm/pg-core";

// Login, registration and password reset accepted unlimited attempts. scrypt
// makes each password guess expensive, which blunts brute force against one
// account, but nothing stopped credential stuffing across many accounts, and
// forgot-password could be pointed at someone's inbox to flood it and burn the
// Resend quota.
//
// Backed by Postgres rather than memory on purpose: on Vercel each request may
// run in a different function instance, so an in-process counter would reset
// constantly and silently enforce nothing. This is one of the cases where the
// serverless model turns a normal solution into a no-op.
//
// One row per attempt rather than a counter, so a window can be evaluated at
// any width without a scheduled reset, and so a burst is still visible after
// the fact. Rows are pruned opportunistically on write.
export const authAttemptsTable = pgTable(
  "auth_attempts",
  {
    id: serial("id").primaryKey(),
    // "login" | "register" | "forgot-password" | "reset-password"
    action: text("action").notNull(),
    // Lowercased email where the request names one, else "". Paired with ip so
    // one attacker cannot spread across accounts, and one account cannot be
    // locked out from a single hostile IP without also throttling that IP.
    identifier: text("identifier").notNull(),
    ip: text("ip").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    // Every read is "count rows for this key since T", so the window scan is an
    // index range rather than a table scan on a table that only ever grows.
    index("auth_attempts_action_identifier_created_idx").on(
      table.action,
      table.identifier,
      table.createdAt,
    ),
    index("auth_attempts_action_ip_created_idx").on(table.action, table.ip, table.createdAt),
  ],
);

export type AuthAttempt = typeof authAttemptsTable.$inferSelect;
