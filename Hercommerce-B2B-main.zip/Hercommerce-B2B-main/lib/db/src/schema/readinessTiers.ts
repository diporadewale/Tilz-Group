import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const readinessTiersTable = pgTable("readiness_tiers", {
  id: serial("id").primaryKey(),
  sellerId: integer("seller_id").notNull().unique(),
  tier: text("tier", { enum: ["bronze", "silver", "gold", "platinum"] }).notNull().default("bronze"),
  score: integer("score").notNull().default(0),
  documentsVerified: integer("documents_verified").notNull().default(0),
  documentsRequired: integer("documents_required").notNull().default(3),
  adminOverride: boolean("admin_override").notNull().default(false),
  adminNote: text("admin_note"),
  overriddenBy: integer("overridden_by"),
  overriddenAt: timestamp("overridden_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertReadinessTierSchema = createInsertSchema(readinessTiersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertReadinessTier = z.infer<typeof insertReadinessTierSchema>;
export type ReadinessTier = typeof readinessTiersTable.$inferSelect;
