import {
  pgTable,
  text,
  serial,
  integer,
  timestamp,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

// A buyer's review of an exporter. One per (seller, buyer). `sellerId` ->
// sellerProfiles.id, `buyerId` -> buyerProfiles.id.
export const reviewsTable = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    sellerId: integer("seller_id").notNull(),
    buyerId: integer("buyer_id").notNull(),
    rating: integer("rating").notNull(),
    comment: text("comment"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("reviews_seller_buyer_idx").on(t.sellerId, t.buyerId),
    index("reviews_seller_id_idx").on(t.sellerId),
  ],
);

export type Review = typeof reviewsTable.$inferSelect;
export const ratingSchema = z.number().int().min(1).max(5);
