import {
  pgTable,
  text,
  serial,
  integer,
  timestamp,
  index,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// A product a seller lists in the catalogue. Belongs to a seller PROFILE
// (sellerProfiles.id). Prices are stored as text to allow ranges / "Negotiable"
// without numeric/float friction; moq (minimum order quantity) is numeric.
export const productsTable = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    sellerId: integer("seller_id").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    category: text("category"),
    imageUrl: text("image_url"),
    priceMin: text("price_min"),
    priceMax: text("price_max"),
    currency: text("currency").notNull().default("USD"),
    unit: text("unit"),
    moq: integer("moq"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (t) => [
    index("products_seller_id_idx").on(t.sellerId),
    index("products_category_idx").on(t.category),
  ],
);

export const insertProductSchema = createInsertSchema(productsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof productsTable.$inferSelect;
