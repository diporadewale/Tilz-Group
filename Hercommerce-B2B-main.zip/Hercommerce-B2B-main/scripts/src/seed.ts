import {
  db,
  usersTable,
  sellerProfilesTable,
  buyerProfilesTable,
  documentsTable,
  readinessTiersTable,
  enquiriesTable,
  auditNotesTable,
} from "@workspace/db";
import { inArray, like, or } from "drizzle-orm";

// Demo rows are tagged with a `seed_` clerkId prefix so re-seeding only
// replaces demo data and leaves real registered accounts untouched.
async function clearPreviousSeed() {
  const seedUsers = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(like(usersTable.clerkId, "seed_%"));
  const userIds = seedUsers.map((u) => u.id);
  if (!userIds.length) return;

  const sps = await db
    .select({ id: sellerProfilesTable.id })
    .from(sellerProfilesTable)
    .where(inArray(sellerProfilesTable.userId, userIds));
  const bps = await db
    .select({ id: buyerProfilesTable.id })
    .from(buyerProfilesTable)
    .where(inArray(buyerProfilesTable.userId, userIds));
  const spIds = sps.map((s) => s.id);
  const bpIds = bps.map((b) => b.id);

  await db.delete(auditNotesTable).where(inArray(auditNotesTable.adminId, userIds));

  const enqConds = [];
  if (spIds.length) enqConds.push(inArray(enquiriesTable.sellerId, spIds));
  if (bpIds.length) enqConds.push(inArray(enquiriesTable.buyerId, bpIds));
  if (enqConds.length) {
    await db
      .delete(enquiriesTable)
      .where(enqConds.length === 1 ? enqConds[0] : or(...enqConds));
  }

  if (spIds.length) {
    await db
      .delete(readinessTiersTable)
      .where(inArray(readinessTiersTable.sellerId, spIds));
  }
  await db.delete(documentsTable).where(inArray(documentsTable.userId, userIds));
  await db.delete(sellerProfilesTable).where(inArray(sellerProfilesTable.userId, userIds));
  await db.delete(buyerProfilesTable).where(inArray(buyerProfilesTable.userId, userIds));
  await db.delete(usersTable).where(inArray(usersTable.id, userIds));
}

type Tier = "bronze" | "silver" | "gold" | "platinum";
const TIER_SCORE: Record<Tier, number> = {
  bronze: 0,
  silver: 40,
  gold: 80,
  platinum: 100,
};

const SELLERS: Array<{
  slug: string;
  firstName: string;
  lastName: string;
  companyName: string;
  description: string;
  country: string;
  city: string;
  website: string;
  categories: string[];
  annualRevenue: string;
  employeeCount: string;
  exportMarkets: string[];
  certifications: string[];
  tier: Tier;
  status: "approved" | "pending";
}> = [
  {
    slug: "afrofresh",
    firstName: "Kwame",
    lastName: "Asante",
    companyName: "AfroFresh Organics",
    description:
      "Premium organic produce and dried fruits from West Africa, certified fair-trade and USDA organic. We supply European and Asian wholesalers with mango, pineapple, and a rotating seasonal range.",
    country: "Nigeria",
    city: "Lagos",
    website: "https://afrofresh.example.ng",
    categories: ["Organic Produce", "Dried Fruits", "Spices"],
    annualRevenue: "$2M - $5M",
    employeeCount: "50-100",
    exportMarkets: ["Germany", "Netherlands", "United Kingdom", "Japan"],
    certifications: ["USDA Organic", "Fair Trade", "ISO 22000"],
    tier: "gold",
    status: "approved",
  },
  {
    slug: "sahara",
    firstName: "Fatima",
    lastName: "El-Amin",
    companyName: "Sahara Premium Grains",
    description:
      "North Africa's leading exporter of ancient grains, quinoa, teff, and farro grown in the Atlas Mountain foothills and milled to order.",
    country: "Morocco",
    city: "Marrakech",
    website: "https://saharagrains.example.ma",
    categories: ["Grains", "Organic Produce", "Health Foods"],
    annualRevenue: "$1M - $2M",
    employeeCount: "20-50",
    exportMarkets: ["France", "Germany", "Japan", "United States"],
    certifications: ["EU Organic", "GlobalGAP"],
    tier: "silver",
    status: "approved",
  },
  {
    slug: "accra-cocoa",
    firstName: "Abena",
    lastName: "Mensah",
    companyName: "Accra Cocoa Collective",
    description:
      "A farmer-owned cooperative exporting single-origin cocoa beans, nibs, and couverture. Direct-trade, traceable to farm, and Rainforest Alliance certified.",
    country: "Ghana",
    city: "Accra",
    website: "https://accracocoa.example.gh",
    categories: ["Cocoa", "Confectionery", "Organic Produce"],
    annualRevenue: "$5M - $10M",
    employeeCount: "100-250",
    exportMarkets: ["Belgium", "Switzerland", "United States", "Japan"],
    certifications: ["Rainforest Alliance", "Fair Trade", "ISO 22000", "HACCP"],
    tier: "platinum",
    status: "approved",
  },
  {
    slug: "zanzibar-spice",
    firstName: "Juma",
    lastName: "Khalfan",
    companyName: "Zanzibar Spice Traders",
    description:
      "Hand-harvested cloves, cardamom, vanilla, and black pepper from the spice islands. Sun-dried, hand-graded, and packed for specialty food importers.",
    country: "Tanzania",
    city: "Zanzibar City",
    website: "https://zanzibarspice.example.tz",
    categories: ["Spices", "Botanicals", "Health Foods"],
    annualRevenue: "$1M - $2M",
    employeeCount: "20-50",
    exportMarkets: ["United Arab Emirates", "India", "Germany", "United States"],
    certifications: ["EU Organic", "Fair Trade"],
    tier: "gold",
    status: "approved",
  },
  {
    slug: "addis-coffee",
    firstName: "Selam",
    lastName: "Tesfaye",
    companyName: "Addis Coffee Union",
    description:
      "Washed and natural Arabica from Yirgacheffe and Sidamo, cupping 86+. Cooperative-sourced with full traceability and Q-graded lots available year-round.",
    country: "Ethiopia",
    city: "Addis Ababa",
    website: "https://addiscoffee.example.et",
    categories: ["Coffee", "Beverages"],
    annualRevenue: "$5M - $10M",
    employeeCount: "100-250",
    exportMarkets: ["United States", "South Korea", "Germany", "Australia"],
    certifications: ["Fair Trade", "EU Organic", "Rainforest Alliance"],
    tier: "platinum",
    status: "approved",
  },
  {
    slug: "nile-cotton",
    firstName: "Omar",
    lastName: "Hassan",
    companyName: "Nile Cotton Mills",
    description:
      "Extra-long-staple Egyptian cotton, raw lint, combed yarn, and greige fabric. Vertically integrated from ginning to weaving for apparel and home-textile buyers.",
    country: "Egypt",
    city: "Cairo",
    website: "https://nilecotton.example.eg",
    categories: ["Textiles", "Cotton", "Apparel"],
    annualRevenue: "$10M+",
    employeeCount: "250-500",
    exportMarkets: ["Italy", "Turkey", "India", "United States"],
    certifications: ["OEKO-TEX", "BCI", "ISO 9001"],
    tier: "silver",
    status: "approved",
  },
  {
    slug: "cape-vine",
    firstName: "Thandiwe",
    lastName: "Nkosi",
    companyName: "Cape Vine Exports",
    description:
      "Award-winning Stellenbosch wines and premium table grapes. Cold-chain logistics and EU-compliant labelling for retail and on-trade buyers.",
    country: "South Africa",
    city: "Cape Town",
    website: "https://capevine.example.za",
    categories: ["Wine", "Beverages", "Fresh Fruit"],
    annualRevenue: "$2M - $5M",
    employeeCount: "50-100",
    exportMarkets: ["United Kingdom", "Netherlands", "China", "Canada"],
    certifications: ["WIETA", "GlobalGAP", "BRCGS"],
    tier: "gold",
    status: "approved",
  },
  {
    slug: "rift-valley",
    firstName: "Njeri",
    lastName: "Wanjiku",
    companyName: "Rift Valley Floriculture",
    description:
      "Year-round cut flowers and ornamental plants, roses, lisianthus, and foliage, flown fresh to European and Asian auctions.",
    country: "Kenya",
    city: "Nairobi",
    website: "https://riftvalleyflora.example.ke",
    categories: ["Floriculture", "Horticulture"],
    annualRevenue: "Under $1M",
    employeeCount: "10-20",
    exportMarkets: ["Netherlands", "Japan"],
    certifications: [],
    tier: "bronze",
    status: "pending",
  },
];

async function seed() {
  console.log("Seeding demo data (additive, real accounts preserved)…");
  await clearPreviousSeed();

  const [admin] = await db
    .insert(usersTable)
    .values({
      clerkId: "seed_admin_001",
      email: "admin@originance.co",
      firstName: "Amara",
      lastName: "Diallo",
      role: "admin",
      status: "approved",
      emailVerified: true,
    })
    .returning();

  const sellerRecords: Array<{ profileId: number; userId: number; tier: Tier; status: string }> = [];

  for (let i = 0; i < SELLERS.length; i++) {
    const s = SELLERS[i];
    const [user] = await db
      .insert(usersTable)
      .values({
        clerkId: `seed_seller_${String(i + 1).padStart(3, "0")}`,
        email: `${s.slug}@example.com`,
        firstName: s.firstName,
        lastName: s.lastName,
        role: "seller",
        status: s.status === "approved" ? "approved" : "pending",
        emailVerified: true,
      })
      .returning();

    const [profile] = await db
      .insert(sellerProfilesTable)
      .values({
        userId: user.id,
        companyName: s.companyName,
        description: s.description,
        country: s.country,
        city: s.city,
        website: s.website,
        categories: s.categories,
        annualRevenue: s.annualRevenue,
        employeeCount: s.employeeCount,
        exportMarkets: s.exportMarkets,
        certifications: s.certifications,
        status: s.status,
        readinessTier: s.tier,
      })
      .returning();

    const required = 3;
    const verified =
      s.tier === "platinum" ? 5 : s.tier === "gold" ? 4 : s.tier === "silver" ? 2 : 0;
    await db.insert(readinessTiersTable).values({
      sellerId: profile.id,
      tier: s.tier,
      score: TIER_SCORE[s.tier],
      documentsVerified: verified,
      documentsRequired: required,
      adminOverride: false,
    });

    sellerRecords.push({ profileId: profile.id, userId: user.id, tier: s.tier, status: s.status });
  }

  // A couple of buyers so the demo has the other side of the marketplace.
  const [buyer1User] = await db
    .insert(usersTable)
    .values({
      clerkId: "seed_buyer_001",
      email: "buyer1@example.com",
      firstName: "Hans",
      lastName: "Müller",
      role: "buyer",
      status: "approved",
      emailVerified: true,
    })
    .returning();
  const [buyer1] = await db
    .insert(buyerProfilesTable)
    .values({
      userId: buyer1User.id,
      companyName: "Alpha Trade GmbH",
      description:
        "Leading German wholesale importer specialising in organic and specialty food products from Africa and Asia.",
      country: "Germany",
      city: "Hamburg",
      website: "https://alphatrade.example.de",
      interestedCategories: ["Organic Produce", "Dried Fruits", "Grains", "Cocoa"],
      preferredOrigins: ["Nigeria", "Ghana", "Ethiopia", "Morocco"],
      annualBudget: "$5M+",
      status: "approved",
    })
    .returning();

  // A sample enquiry against the first seller for inbox realism.
  await db.insert(enquiriesTable).values({
    buyerId: buyer1.id,
    sellerId: sellerRecords[0].profileId,
    subject: "Bulk order inquiry, dried mango and pineapple",
    message:
      "Hello, we are interested in your dried fruit range for our Q3 procurement cycle. Could you share pricing for 5-tonne minimum orders and confirm lead time to Hamburg?",
    status: "open",
  });

  // One verified document + one pending, for the admin review queue.
  await db.insert(documentsTable).values({
    userId: sellerRecords[0].userId,
    documentType: "business_registration",
    fileName: "afrofresh_biz_reg.pdf",
    fileUrl: "/sample-document.pdf",
    status: "approved",
    verifiedBy: admin.id,
    verifiedAt: new Date(),
  });
  await db.insert(documentsTable).values({
    userId: sellerRecords[sellerRecords.length - 1].userId,
    documentType: "business_registration",
    fileName: "rift_valley_reg.pdf",
    fileUrl: "/sample-document.pdf",
    status: "pending",
  });

  const approved = sellerRecords.filter((s) => s.status === "approved").length;
  console.log("Seed complete.");
  console.log(`  Sellers: ${SELLERS.length} (${approved} approved, ${SELLERS.length - approved} pending)`);
  console.log(`  Buyers: 1 · Admin: 1 · Enquiries: 1 · Documents: 2`);
  process.exit(0);
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
