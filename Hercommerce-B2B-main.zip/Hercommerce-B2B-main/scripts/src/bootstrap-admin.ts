import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomBytes, scrypt } from "node:crypto";
import { promisify } from "node:util";

const scryptAsync = promisify(scrypt);

// MUST match artifacts/api-server/src/lib/password.ts:
// stored format `scrypt:<saltHex>:<hashHex>`, scrypt(password, saltHex, 64).
async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16).toString("hex");
  const derived = (await scryptAsync(password, salt, 64)) as Buffer;
  return `scrypt:${salt}:${derived.toString("hex")}`;
}

// Promote (or create) an admin account. Usage:
//   ADMIN_EMAIL=you@example.com ADMIN_PASSWORD=secret \
//   pnpm --filter @workspace/scripts run bootstrap-admin
async function main() {
  const email = (process.env.ADMIN_EMAIL || "").toLowerCase().trim();
  const password = process.env.ADMIN_PASSWORD || "";
  if (!email || !password) {
    console.error("Set ADMIN_EMAIL and ADMIN_PASSWORD environment variables.");
    process.exit(1);
  }

  const passwordHash = await hashPassword(password);
  const [existing] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email));

  if (existing) {
    await db
      .update(usersTable)
      .set({ role: "admin", status: "approved", emailVerified: true, passwordHash })
      .where(eq(usersTable.id, existing.id));
    console.log(`Promoted existing user ${email} to admin and set password.`);
  } else {
    await db.insert(usersTable).values({
      email,
      passwordHash,
      firstName: "Admin",
      role: "admin",
      status: "approved",
      emailVerified: true,
    });
    console.log(`Created admin account ${email}.`);
  }
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
